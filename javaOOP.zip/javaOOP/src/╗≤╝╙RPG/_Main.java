package 상속RPG;

public class _Main {

	public static void main(String[] args) {
		Game g=new Game();
		g.run();
	}
	
	
}
