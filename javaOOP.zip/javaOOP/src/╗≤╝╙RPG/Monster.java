package 상속RPG;

public class Monster extends Unit{

	String[] names= {"늑대","박쥐","좀비"};
	String[] attack= {"할퀴기","음파공격","물어뜯기"};
	int idx;
	
	public Monster(int hp, int power, String name) {
		super(hp, power, name);
	}
	 Monster init(int idx) {
		 Monster m =null;
		this.idx = idx;
		return new Monster(35, 5, names[idx]);
	}
}
