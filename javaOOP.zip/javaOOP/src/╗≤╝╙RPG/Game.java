package 상속RPG;

import java.util.Random;
import java.util.Scanner;

public class Game {

	Scanner s=new Scanner(System.in);
	Random r=new Random();
	
	final int BOSS = 9;
	final int MONSTER =8;
	final int SIZE = 10;
	
	int map[];
	Player player;
	int px;
	void init() {
		map = new int[SIZE];
		player= new Player(100, 10, "전사");
		map[3] = MONSTER;
		map[5] = MONSTER;
		map[7] = MONSTER;
		map[SIZE-1] = BOSS;
	}
	
	void printGameMap() {
		for(int game : map) {
			if(game == px) {
				System.out.print("[옷]");
			}
			else if(game == 0) {
				System.out.print("[ ]");
			}else if(game == MONSTER) {
				System.out.print("[M]");
			}else {
				System.out.print("[B]");
			}
		}
	}
	
	void movePlayer() {
		mainMenu();
		int sel=s.nextInt();
		if(sel==0) {return;}
		if(sel==1) {px++;}
		if(sel==2) {}
	}
	
	int mainMenu() {
		System.out.println("[0]종료[1]한칸이동[2]체력회복");
		int num=s.nextInt();
		if(num<= 0 || num>2) return 0;
		else return num;
	}
	
	void battleMonster() {
		System.out.println("========= [ 전투 ]==========");
		boolean turn = false;
		if(turn) {
			System.out.println("[플레이어 차례]");
			System.out.println("[1]공격 [2]스킬");
		}else {
			System.out.println("[몬스터 차례]");
		}
	}
	
	void run() {
		init();
		while(true) {
			printGameMap();
			movePlayer();
		}
	}
	
	
}
