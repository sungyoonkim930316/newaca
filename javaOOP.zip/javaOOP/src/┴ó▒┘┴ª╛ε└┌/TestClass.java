package 접근제어자;

class Parents {
	int x;
	// 생성자 단축키 : alt + shift + s, o
	void parentMethod() {
		System.out.println("부모 메서드 호출");
	}
	
}

class Childs extends Parents {
	int y;
	
	@Override
	void parentMethod() {
		// 오버라이딩 하기 전의 부모 원본의 메서드를 출력
		super.parentMethod();
		System.out.println(this.y + ", " + super.x);
		System.out.println("부모 메서드 오버라이딩함!!!");
	}
	
	void childMethod() {
		System.out.println("자식 메서드 호출");
	}
	
}

//public class Ex {
//	public static void main(String[] args) {
//		
//		Childs ch = new Childs();
//		ch.parentMethod();
//		
//	}
//}

public class TestClass {

}
