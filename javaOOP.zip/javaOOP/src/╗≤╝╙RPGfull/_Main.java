package 상속RPGfull;

public class _Main {
	public static void main(String[] args) {

		Game game = new Game();
		game.run();
	}

}
