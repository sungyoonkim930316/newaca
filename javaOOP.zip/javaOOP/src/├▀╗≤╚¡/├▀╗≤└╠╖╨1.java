package 추상화;

public class 추상이론1 {

	public static void main(String[] args) {

		
		
	}

}
