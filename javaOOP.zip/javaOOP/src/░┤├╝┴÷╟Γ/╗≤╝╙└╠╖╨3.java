package 객체지향;

class Parent{
	void test1() {
		System.out.println("test1 호출");
	}
}
class Child extends Parent{
	
	// 오버로딩 : 같은 클래스 내부에서 같은 이름의 메서드를 사용 : 매개변수의 갯수 타입 순서 
	// 오버라이딩 : 부모클래스에 있는 메서드의 내용(구현부)만 수정하는 것 
	
	@Override
	void test1() {
		super.test1();
		System.out.println("자식에서 test1 호출");
	}
	
	// super => 부모 인스턴스의 주소값
	// super() => 부모 생성자 호출 
	
	Child(){
		super(); // 부모생성자가 먼저 호출이 되고 그다음에 자식 객체가 생성 
	}
	void test1(int num) {
		super.test1();
		System.out.println("자식에서 test1 호출");
	}
	
	void test2() {
		System.out.println("test2 호출");
	}

	@Override
	public String toString() {
		return "child 객채 ";
	}


	
	
}

public class 상속이론3 {

	public static void main(String[] args) {
		
		Child c = new Child();
		c.test1();
		c.test2();
		
	}

}