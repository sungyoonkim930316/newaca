package 객체지향;

class A2 {
	int a;
}

class B2 extends A2 {
	int b;
}

class C2 extends B2 {
	int c;
}

public class 상속이론2 {
	public static void main(String[] args) {
		/*
			클래스 한 개 당 상속은 1번만 가능하다.
			상속이 여러개 필요한 경우 줄줄이 상속해야 한다.
		 */
		
		C2 c = new C2();
		c.a = 10;
		c.b = 20;
		c.c = 30;
		
	}
}