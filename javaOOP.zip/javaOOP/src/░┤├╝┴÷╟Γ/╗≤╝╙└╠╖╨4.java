package 객체지향;

class Product{
	String name;
	int price;
	public Product(String name, int price) {
		this.name = name;
		this.price = price;
	}
	
}

class Fruit extends Product{

	String origin;
	public Fruit(String name, int price, String origin) {
		super(name, price);
		this.origin = origin;
	}
}

public class 상속이론4 {
	public static void main(String[] args) {
	
		// product 객체 생성 -> fruit 객체 생성 후에 -> 주소값 banana 지역변수 생성 
		Fruit banana = new Fruit("바나나", 3500, "필리핀");
		
	}
}