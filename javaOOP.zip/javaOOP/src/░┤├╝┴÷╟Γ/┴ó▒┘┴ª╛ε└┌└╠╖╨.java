package 객체지향;

public class 접근제어자이론 {

}
