package 객체지향;

class A1 {
	int a;
	int b;
}

// 상속 X
class B1 {
	A1 a = new A1();
	int c;
	int d;
}

// 상속 O
class C1 extends A1 {
	int e;
	int f;
}

public class 상속이론 {
	public static void main(String[] args) {
		
		/*
			# 상속
			(1) 사용법 : 자식클래스 extends(키워드) 부모클래스 {}
			(2) 상속을 받게되면 마치 본인 클래스의 변수처럼 자유롭게 사용할 수 있다.
			(3) 상속은 한번만 받을 수 있다.(단일 상속) 
			(4) 자세한 실습은 웹에서 사용할 예정이다.
	 */
	
		C1 c = new C1();
		c.a = 10;
		c.b = 20;
		
		/*
			# 상속을 받지 않고 상속과 같은 관계 만들기
			B1는 A를 상속받지 않았지만,
			내부에 변수를 따로 만들어서
			상과 받은것과 같은 상황이다.
			하지만, .을 2번 찍어야 하는 번거로움이 있다.
		 */
		
		B1 b = new B1();
		b.a.a = 10;
		b.a.b = 20;
		
	}
}