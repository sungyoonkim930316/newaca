package 클래스;

public class 기본예제1 {

	public static void main(String[] args) {

		// [문제1] 전체 합 출력
		// [정답1] 362
		
		// [문제2] 4의 배수의 합 출력
		// [정답2] 264
		
		// [문제3] 4의 배수의 개수 출력
		// [정답3] 3
		
		// [문제4] 짝수의 개수 출력
		// [정답4] 3
		
		Score s1=new Score();
		
		
		// Q1 solution
		int sum=0;
		for(int i=0;i<s1.arr.length;i++) {
			sum+=s1.arr[i];
		}
		System.out.println(sum);
		
		
		// Q2 solution
		sum=0;
		for(int i=0;i<s1.arr.length;i++) {
			if(s1.arr[i]%4==0) {
				sum+=s1.arr[i];
			}
		}
		System.out.println(sum);
		
		// Q3 solution
		int count=0;
		for(int i=0;i<s1.arr.length;i++) {
			if(s1.arr[i]%4==0) {
				count++;
			}
		}
		System.out.println(count);
		
		// Q4 solution
		count=0;
		for(int i=0;i<s1.arr.length;i++) {
			if(s1.arr[i]%2==0) {
				count++;
			}
		}
		System.out.println(count);
		
	}

}
