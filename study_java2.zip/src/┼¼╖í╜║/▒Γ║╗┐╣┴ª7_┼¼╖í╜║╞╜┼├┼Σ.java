package 클래스;

import java.util.Arrays;
import java.util.Scanner;

class Tictactoe{
	
	String[][] game=new String[3][3];
	
	int turn=1;
	int win=0;		
}

public class 기본예제7_클래스틱택토 {

	public static void main(String[] args) {

		Scanner s=new Scanner(System.in);
		Tictactoe e=new Tictactoe();
		
		int[][] temp=new int[e.game.length][e.game.length];
		
		int cnt=0;
		while(true) {
			for(int i=0;i<e.game.length;i++) {
				for(int j=0;j<e.game[i].length;j++) {
					if(e.game[i][j]==null) {e.game[i][j]="[ ]";}
					System.out.print(e.game[i][j]+" ");
				}System.out.println();
			}
			if(e.win==1||e.win==2) {System.out.printf("[player%d 승리 ]\n",e.win);break;}
			if(cnt==9){System.out.println("[ 무승부 ] ");break;}
			
			System.out.println("선택");
			int cell=s.nextInt();
			if(cell<1||cell>9) {System.err.println("err");continue;}
			
			int y=(cell-1)/3;
			int x=(cell-1)%3;
			if(temp[y][x]!=0) {y=0;x=0;cell=0;System.err.println("err");continue;}
			if(e.turn==1) {
				for(int i=0;i<e.game.length;i++) {
					for(int j=0;j<e.game[i].length;j++) {
						e.game[y][x]="[O]";temp[y][x]=1;
					}
				}e.turn=2;
			}
			else if(e.turn==2) {
				for(int i=0;i<e.game.length;i++) {
					for(int j=0;j<e.game[i].length;j++) {
						e.game[y][x]="[X]";temp[y][x]=2;
					}
				}e.turn=1;
			}
			cnt++;
			
			for(int i=0;i<e.game.length;i++) {
				if(e.game[i][0]=="[O]"&&e.game[i][1]=="[O]"&&e.game[i][2]=="[O]") {e.win=1;}
				if(e.game[i][0]=="[X]"&&e.game[i][1]=="[X]"&&e.game[i][2]=="[X]") {e.win=2;}
			}
			for(int i=0;i<e.game.length;i++) {
				if(e.game[0][i]=="[O]"&&e.game[1][i]=="[O]"&&e.game[2][i]=="[O]") {e.win=1;}
				if(e.game[0][i]=="[X]"&&e.game[1][i]=="[X]"&&e.game[2][i]=="[X]") {e.win=2;}
			}
			if(e.game[0][0]=="[O]"&&e.game[1][1]=="[O]"&&e.game[2][2]=="[O]") {e.win=1;}
            if(e.game[0][0]=="[X]"&&e.game[1][1]=="[X]"&&e.game[2][2]=="[X]") {e.win=2;}
			if(e.game[0][2]=="[O]"&&e.game[1][1]=="[O]"&&e.game[2][0]=="[O]") {e.win=1;}
			if(e.game[0][2]=="[X]"&&e.game[1][1]=="[X]"&&e.game[2][0]=="[X]") {e.win=2;}
		}
		
	}
}
