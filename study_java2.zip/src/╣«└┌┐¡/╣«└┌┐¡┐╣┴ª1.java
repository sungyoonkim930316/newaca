package 문자열;

public class 문자열예제1 {

	public static void main(String[] args) {

		// 문제 ) 사전 순으로 이름 정렬
		String[] names = { "홍길동", "김유신", "마동석", "자바킹", "서동요" };
		
		for(int i=0;i<names.length;i++) {
            for(int j=names.length-1;j>i;j--) {
                if(names[j-1].compareTo(names[j])>0) {
                    String temp=names[j];
                    names[j]=names[j-1];
                    names[j-1]=temp;
                }
            }
        }
        for(int i=0;i<names.length;i++) {
        	if(i<names.length-1) {
        		System.out.print(names[i]+", ");
        	}
        	else {System.out.print(names[i]);}
        }
		
	}

}
