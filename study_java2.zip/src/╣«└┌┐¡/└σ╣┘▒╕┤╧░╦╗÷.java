package 문자열;

public class 장바구니검색 {

	public static void main(String[] args) {

		/*
		[문제1] 
			회원별로 아이템 구매목록을 출력하시오.
		[정답1] 
			이만수(고래밥 3개 칸쵸 1개)
			김철민(고래밥 1개)
			이영희(고래밥 1개 새우깡 2개)
		
		[문제2]
			아이템별로 구입한 회원이름을 출력하시오.
		[정답2]
			고래밥(이만수 김철민 이영희)
			새우깡(이영희)
			칸쵸(이만수)
	 */
		String itemData = "1001/고래밥,1002/새우깡,1003/칸쵸";
		String userData = "3001/이만수,3002/김철민,3003/이영희";
		
		String cartData = "";
		cartData += "3001/1001\n";
		cartData += "3001/1001\n";
		cartData += "3003/1002\n";
		cartData += "3001/1001\n";
		cartData += "3001/1003\n";
		cartData += "3003/1002\n";
		cartData += "3003/1001\n";
		cartData += "3002/1001";
		
		String[] itemDiv=itemData.split(",");
		String[] userDiv=userData.split(",");
		String[] div=cartData.split("\n");
		int cnt=0;
		String userIdx="3001";
		String itemIdx="1001";
		while(true) {
			String case1="";
			int go=0;
			int sae=0;
			int kan=0;
			for(int i=0;i<div.length;i++) {
				String[] temp=div[i].split("/");
				if(temp[0].equals(userIdx)) {
					if(temp[1].equals("1001")) {go++;}
					if(temp[1].equals("1002")) {sae++;}
					if(temp[1].equals("1003")) {kan++;}
				}
				temp=null;
			}
			
			String name="";
			for(int i=cnt;i<userDiv.length;i++) {
				String[] temp=userDiv[i].split("/");
				if(temp[0].equals("3001")) {name="이만수";break;}
				else if(temp[0].equals("3002")) {name="김철민";break;}
				else if(temp[0].equals("3003")) {name="이영희";break;}
				temp=null;
			}
			case1+=name+"(";
			
			if(go!=0) {case1+="고래밥 "+go+"개 ";}
			if(sae!=0) {case1+="새우깡 "+sae+"개 ";}
			if(kan!=0) {case1+="칸쵸 "+kan+"개 ";}
			case1+=")";
			System.out.println(case1);
			
			go=0;sae=0;kan=0;
			int gao=Integer.parseInt(userIdx);
			gao++;
			userIdx=String.valueOf(gao);
			cnt++;
			if(cnt>=userDiv.length) {break;}
		}
		
		System.out.println();
		
		cnt=0;
		while(true) {
			String case2="";
			int man=0;
			int chul=0;
			int young=0;
			for(int i=0;i<div.length;i++) {
				String[] temp=div[i].split("/");
				if(temp[1].equals(itemIdx)) {
					if(temp[0].equals("3001")) {man=1;}
					if(temp[0].equals("3002")) {chul=1;}
					if(temp[0].equals("3003")) {young=1;}
				}
				temp=null;
			}
			
			String name="";
			for(int i=cnt;i<itemDiv.length;i++) {
				String[] temp=itemDiv[i].split("/");
				if(temp[0].equals("1001")) {name="고레밥";break;}
				else if(temp[0].equals("1002")) {name="새우깡";break;}
				else if(temp[0].equals("1003")) {name="칸쵸";break;}
				temp=null;
			}
			case2+=name+"(";
			
			if(man!=0) {case2+="이만수 ";}
			if(chul!=0) {case2+="김철민 ";}
			if(young!=0) {case2+="이영희 ";}
			case2+=")";
			System.out.println(case2);
			
			man=0;chul=0;young=0;
			int gao=Integer.parseInt(itemIdx);
			gao++;
			itemIdx=String.valueOf(gao);
			cnt++;
			if(cnt>=itemDiv.length) {break;}
		}
	}

}
