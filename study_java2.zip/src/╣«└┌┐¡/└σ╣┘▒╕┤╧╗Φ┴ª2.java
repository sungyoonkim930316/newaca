package 문자열;

import java.util.Scanner;

public class 장바구니삭제2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);

		String[] idList = { "qwer", "javaking", "abcd" };
		String[] pwList = { "1111", "2222", "3333" };

		int size = 3;

		int MAX_SIZE = 100;
		String[][] cartList = new String[MAX_SIZE][2];

		String[] items = { "사과", "바나나", "딸기" };

		int log = -1;
		int count = 0;
		while (true) {

			System.out.println("[MEGA MART]");
			if (log == -1) {
				System.out.println("[1]로 그 인");
			} else {
				System.out.println("[1]로그아웃");
				System.out.println("[2]쇼     핑");
				System.out.println("[3]장바구니");
				System.out.println("[4]전체 구매 목록 ");
			}
			System.out.println("[0]종     료");

			System.out.print("메뉴 선택 : ");
			int sel = sc.nextInt();

			if (sel < 0 || sel > 5) {
				System.err.println("입력오류");
			} else if (sel == 0) {
				System.out.println("프로그램 종료");
				break;
			}

			if (sel == 1 && log == -1) {
				// 로그인
				System.out.println("[ 로그인 ]");
				System.out.println(" id >> ");
				String id = sc.next();
				System.out.println(" pw >> ");
				String pw = sc.next();

				for (int i = 0; i < size; i++) {
					if (id.equals(idList[i]) && pw.equals(pwList[i])) {
						log = i;
						break;
					}
				}
				if (log == -1) {
					System.err.println("[로그인 실패]");
				} else {
					System.err.println("[로그인 성공]");
				}

			} else if (sel == 1 && log != -1) {
				// 로그아웃
				log = -1;
				System.out.println("[ 로그아웃 성공 ]");
			} else if (sel == 2 && log != -1) {
				// 쇼핑

				if (count == MAX_SIZE) {
					System.out.println("[전체 매진 - 판매 종료]");
					continue;
				}

				System.out.println("==== 쇼핑 ==== ");
				int no = 1;
				for (String item : items) {
					System.out.printf(" [%d] %s ", no, item);
					no++;
				}
				System.out.println(" [0] 종료 ");
				System.out.println();
				System.out.println(" 아이템 번호 입력 >> ");
				while (true) {
					int num = sc.nextInt();
					if (num == 0) {
						break;
					}
					if (num < 1 || num > items.length) {
						System.err.println("[ 틀린 번호 선택]");
						continue;
					}
					num--;
					System.out.println("[ " + items[num] + " 1개 장바구니에 등록]");
					cartList[count][0] = idList[log];
					cartList[count][1] = items[num];
					count++;
				}

			} else if (sel == 3 && log != -1) {
				System.out.printf("==== [%s 장바구니 ]==== \n", idList[log]);

				int itemCnt[] = new int[items.length];

				int total = 0;

				for (int i = 0; i < items.length; i++) {
					for (int k = 0; k < count; k++) {
						if (idList[log].equals(cartList[k][0]) && items[i].equals(cartList[k][1])) {
							itemCnt[i]++;
							total++;
						}
					}
				}

				if (total == 0) {

					System.out.println("[장바구니가 비었습니다]");
					continue;
				}

				System.out.printf("\t 총 장바구니[%d 개] \n", total);

				for (int i = 0; i < items.length; i++) {
					if (itemCnt[i] > 0) {
						System.out.printf("\t[%-5s][%-2d개] \n", items[i], itemCnt[i]);
					}
				}

				System.out.println("----------------");
				System.out.println("[1]아이템 삭제 [2] 전체 삭제");

				sc.nextLine();
				System.out.println("번호 입력 >> ");
				int num = sc.nextInt();

				if (num < 1 || num > 2) {
					System.err.println("[입력 오류]");
					continue;
				}

				if (num == 1) {
					while (true) {
						System.out.println("[삭제] 아이템 입력 >> ");
						// 아이템 이름으로 삭제
						String name = sc.next();
						int idx = -1;
						
						for(int i =0; i <count;i++) {
							if(name.equals(cartList[i][1])&&idList[log].equals(cartList[i][0])) {
								idx = i;
								break;
							}
						}
						
						if(idx == -1) {
							System.out.println("[없는 아이템 입니다 ]");
							continue;
						}
						
						for(int i = idx; i < count-1; i++) {
							cartList[i] = cartList[i+1];
						}
//						cartList[count-1][0] = null;
//						cartList[count-1][1] = null;
						cartList[count-1] = new String[2];
						count--;
						
						System.out.printf("[ %s 1개 장바구니에서 삭제 완료] \n" , name);
						
						break;
						
					}

				} else if (num == 2) {

					int cnt =0;
					for(int i =0; i < count; i++) {
						if(cartList[i][0].equals(idList[log])) {
							cnt++;
						}
					}
				
					
					while(cnt > 0) {
						int idx = -1;
						for(int i =0; i < count; i++) {
							if(cartList[i][0].equals(idList[log])) {
								idx = i;
								break;
							}
						}
							for(int i = idx; i < count-1; i++) {
								cartList[i] = cartList[i+1];
							}
							
							cartList[count-1] = new String[2];
							count--;
						cnt--;
					}
					System.out.println("[전체 삭제 완료 ]");
				}

			} else if (sel == 4 && log != -1) {
				// 전체목록
				System.out.println("==== 전체 구매 목록 ==== ");
				System.out.println(" 아이디 \t 아이템 \t");
				for (int i = 0; i < count; i++) {
					System.out.printf(" %s \t %s \t \n", cartList[i][0], cartList[i][1]);
				}

			} else {
				System.err.println("현재 서비스 이용 불가 ");
			}
		}
		
		
		sc.close();
		
		
		
		
		
		
		
		
		
//		// 장바구니
//		System.out.printf("==== [%s 장바구니 ]==== \n", idList[log]);
//
//		int itemCnt[] = new int[items.length];
//
//		int total = 0;
//
//		for (int i = 0; i < items.length; i++) {
//			for (int k = 0; k < count; k++) {
//				if (idList[log].equals(cartList[k][0]) && items[i].equals(cartList[k][1])) {
//					itemCnt[i]++;
//					total++;
//				}
//			}
//		}
//
//		if (total == 0) {
//			System.err.println("[장바구니가 비었습니다]");
//			continue;
//		}
//
//		System.out.printf("\t 총 장바구니[%d 개] \n", total);
//
//		for (int i = 0; i < items.length; i++) {
//			if (itemCnt[i] > 0) {
//				System.out.printf("\t[%s][%3d개] \n", items[i], itemCnt[i]);
//			}
//		}
//		
//		System.out.println("----------------");
//		System.out.println("[1]아이템 삭제 [2] 전체 삭체 ");
//		System.out.println("입력 >> ");
//		int num = sc.nextInt();
//		if (num == 1) {
//			System.out.println("[삭제] 아이템 입력");
//			// 아이템 이름으로 삭제 
//		}else if(num == 2) {
//			System.out.println("[전체 삭제 완료 ]");
//			// 본인 아이디 전체 장바구니 비우기 
//		}
		
		
	}

}
