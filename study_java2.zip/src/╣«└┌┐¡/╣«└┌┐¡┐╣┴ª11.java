package 문자열;

import java.util.Arrays;
import java.util.Scanner;

public class 문자열예제11 {

	public static void main(String[] args) {

		/*
		 * # 단어 검색
		 * 1. 단어를 입력받아 text변수 문장 속에 해당 단어가 있는지 검색한다.
		 * 2. 단어가 존재하면 true
		 *    단어가 없으면 false를 출력한다.
		 */
		
		Scanner scan = new Scanner(System.in);

		String text = "Life is too short.";
		System.out.println(text);
		text=text.substring(0,text.length()-1);
		String[] temp=text.split(" ");
		System.out.println(Arrays.toString(temp));
		
		System.out.print("검색할 단어를 입력하세요 : ");
		String word = scan.next();
		
		int cnt=0;
		for(int i=0;i<temp.length;i++) {
			if(temp[i].equalsIgnoreCase(word)) {cnt++;}
		}
		System.out.println(cnt==1);
		scan.close();
		
	}
}
