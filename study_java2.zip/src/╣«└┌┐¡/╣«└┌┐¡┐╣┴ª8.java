package 문자열;

import java.util.Arrays;

public class 문자열예제8 {

	public static void main(String[] args) {

		// 문제) 이름은 name배열에 성적은 score배열에 각각 저장 및 출력
		
//		String str = "김철수/87,이만수/42,이영희/95";
//		
//		String[] name = new String[3]; // 김철수,이만수,이영희
//		int[] score = new int[3];      // 87,42,95
//		String[] temp=new String[3];
//		
//		int s=0;
//		for(int i=0;i<name.length;i++) {
//			name[i]=str.substring(s,s+3);
//			s+=7;
//		}
//		System.out.println(Arrays.toString(name));
//		
//		s=4;
//		for(int i=0;i<temp.length;i++) {
//			temp[i]=str.substring(s,s+2);
//			s+=7;
//		}
////		System.out.println(Arrays.toString(temp));
//		for(int i=0;i<score.length;i++) {
//			score[i]=Integer.parseInt(temp[i]);
//		}
//		System.out.println(Arrays.toString(score));
		
		// 문자열 함수를 사용해서 풀어볼것
		
		String str = "김철수/87,이만수/42,이영희/95";
		
		String[] name = new String[3]; // 김철수,이만수,이영희
		int[] score = new int[3];      // 87,42,95
		
		String temp[] = str.split(",");
		int idx = 0;
		for(String str1 : temp) {
			System.out.println(str1);
			String data[] = str1.split("/");
			name[idx]=data[0];            // "87" -> 87
			score[idx] = Integer.parseInt(data[1]);
			idx++;
		}
		
		System.out.println(Arrays.toString(name));
		System.out.println(Arrays.toString(score));
		
	}

}
