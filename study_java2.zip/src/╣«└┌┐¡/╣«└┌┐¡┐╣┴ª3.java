package 문자열;

import java.util.Scanner;

public class 문자열예제3 {

	public static void main(String[] args) {

		/*
		 * # 문자열 비교
		 * . equals() 메서드 사용없이 equals 직접구현 문자의 일치여부 비교
		 * 예)
		 * 코끼리
		 * 입력 = 티라노사우루스
		 * 출력 = false
		 */
		
		Scanner sc = new Scanner(System.in);
//		String answer ="코끼리";
		char[] answer2= {'코','끼','리'}; 
		
		
//		System.out.println("코끼리 입력>> ");
//		String input = sc.next();
		
		 
		
//		System.out.println(answer.equals(input));
		
		int cnt=0;
		int err=1;
		while(true) {
			String answer ="코끼리";
			System.out.println("코끼리 입력>> ");
			String input = sc.next();
			
			if(answer.length()!=input.length()) {
				err=0;
				break;
			}
			else {
				for(int i=0;i<answer2.length;i++) {
					if(answer.charAt(i)==input.charAt(i)) {cnt++;}
				}
				if(cnt!=answer.length()) {err=0;break;}
			}
			if(err!=0) {break;}
		}
		System.out.println(err==1);
		sc.close();
	}

}
