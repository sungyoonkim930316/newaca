package 문자열;

public class 문자열예제9 {

	public static void main(String[] args) {

		// 문제) 이름은 name배열에 성적은 score배열에 각각 저장 및 출력
		
		String[] name = { "김철수", "이만수", "이영희" };
		int[] score = { 87, 42, 95 };
		
		String str = "";
		
		for(int i=0;i<name.length;i++) {
			if(i==2) str+=name[i]+"/"+String.valueOf(score[i]);
			else str+=name[i]+"/"+String.valueOf(score[i])+",";
		}
		System.out.println(str);
		
	}
}
