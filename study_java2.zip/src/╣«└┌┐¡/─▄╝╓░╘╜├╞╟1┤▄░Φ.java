package 문자열;

import java.util.Scanner;

public class 콘솔게시판1단계 {

	public static void main(String[] args) {

//		Scanner sc = new Scanner(System.in);
//
//		int count = 14; // 전체 게시글 수
//		int pageSize = 3; // 한 페이지에 보여줄 게시글 수
//		int curPageNum = 1; // 현재 페이지 번호
//		int pageCount = 0; // 전체 페이지 개수
////		int startRow = 0; // 현재 페이지의 게시글 시작 번호
//		int endRow = 0; // 현재 페이지의 게시글 마지막 번호
//		
//		
//		
//		pageCount=count/pageSize;
//		int last=count%pageSize;
//		System.out.println(pageCount);
//
//		while(true){
//			System.out.println("===자유게시판===");
//			System.out.println("엔드로우 : "+endRow);
//			System.out.println("페이지사이즈 : "+pageSize);
//			System.out.println("페이지카운트 : "+pageCount);
//			for(int i=endRow;i<pageSize;i++) {
//				System.out.println("("+(i+1)+")");
//				endRow++;
//			}
//			System.out.println("-------------");
//			System.out.println("현재 페이지 번호 : "+curPageNum);
//			System.out.println("=============");
//	    	System.out.println("[이전 1]"); // 페이지 이동
//			System.out.println("[이후 2]");
//			System.out.println("선택 >> ");
//			int choice = sc.nextInt();
//			if(choice==1) {
//				if(curPageNum==1) {endRow-=3;continue;}
//				else{
//					pageSize-=3;
//					endRow-=6;
//					curPageNum--;
//					continue;
//				}
//					
//			}
//			if(choice==2) {
//				for(int i=endRow;i<pageSize;i++) {
//					endRow++;
//				}
//				if(pageSize==count) {endRow-=last;continue;}
//				pageSize+=3;
//				if(pageSize>count) {pageSize=pageSize-(pageSize-count);}
//				curPageNum++;
//				if(curPageNum>pageCount+1) {curPageNum--;continue;}
//			}
//			if(choice==3) {break;}
//		}
//		sc.close();
		
		Scanner sc=new Scanner(System.in);

		int count=1; // 전체 게시글 수
		int pageSize=3; // 한 페이지에 보여줄 게시글 수
		int curPageNum=1; // 현재 페이지 번호
		int pageCount=0; // 전체 페이지 개수
		int startRow=0; // 현재 페이지의 게시글 시작 번호
		int endRow=0; // 현재 페이지의 게시글 마지막 번호

		pageCount=count%pageSize==0?count/pageSize:(count/pageSize)+1;

		System.out.printf("현재 보여주는 게시글 \n 총갯수  %d / 페이지 %d \n",count,pageCount);

		while(true) {
			startRow=(curPageNum-1)*pageSize;
			endRow=startRow+pageSize>count?count:startRow+pageSize;
			endRow--;

			System.out.println("스타트로우"+startRow);
			System.out.println("엔드로우"+endRow);
			System.out.printf(" 현재 게시글 번호 %d - %d \n",startRow,endRow);

			for (int i=startRow;i<=endRow;i++) {
				System.out.printf("( %d )\n",i+1);
			}
			System.out.println();

			System.out.println("[이전 1]"); // 페이지 이동
			System.out.println("[이후 2]");
			System.out.println("선택 >> ");
			int choice = sc.nextInt();

			if (choice == 1) {
				// 이전
				if (curPageNum == 1) {
					System.out.println("[페이지 번호가 없습니다]");
					continue;
				}
				curPageNum--;

			} else if (choice == 2) {
				// 이후
				if (curPageNum == pageCount) {
					System.out.println("[페이지 번호가 없습니다]");
					continue;
				}
				curPageNum++;
			}
			else {break;}

		}
		sc.close();
		
	}

}
