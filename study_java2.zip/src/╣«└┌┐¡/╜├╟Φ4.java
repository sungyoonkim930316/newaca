package 문자열;

import java.util.Scanner;

public class 시험4 {

	public static void main(String[] args) {

		/*
		# 2차원 회원관리데이터 
			[1] 번호 [2] 아이디 [3] 비밀번호 [4] 이름 
			테스트를 위해 아래 기본데이터 4개를 넣고 시작한다.
	    */

		Scanner s=new Scanner(System.in);	
		//                번호     아이디   비번       이름 
//		String[] test1 = {"1001" , "aaa" ,"aaa123" , "김철수"};
//		String[] test2 = {"1002" , "bbb" ,"bbb123" , "이민수"};
//		String[] test3 = {"1003" , "ccc" ,"ccc123" , "박영희"};
//		String[] test4 = {"1004" , "ddd" ,"ddd123" , "최민정"};		
		int cnt = 4; // 현재 맴버 수 
		String [][] mList =new String[100][4]; // 최대100명 데이타는4

//	    for(int i=0;i<mList.length;i++) {
//	    	System.out.println(Arrays.toString(mList[i]));
//	    }
		
	    String menu = "[회원관리] \n [1] 추가 [2] 삭제 [3] 수정 [4] 검색 [5] 출력 [0] 종료 \n";
		
	    int userNum=0;
	    String dbNum="1001";
	    int count=0;
	    int memCnt=0;
	    
	    
		while(true) {
			System.out.println(menu);

			int sel = s.nextInt();
			if(sel == 0) {
				break;
			}	else if(sel == 5) {
				//번호와 이름 출력 
				for(int i=0;i<memCnt;i++) {
					System.out.printf("번호 %s \t 이름 %s \n",mList[i][0],mList[i][3]);
				}
			}
			
			else if(sel == 1) {
				for(int i=0;i<mList.length;i++) {
					System.out.println("아이디를 입력 : ");
					String id = s.next();
					// 아이디 중복 검사
					if(id.equals(mList[i][1])) {System.out.println("이미 존재하는 아이디다.");continue;}
					else {mList[userNum][1]=id;break;}
				}
				
				while(true) {
					System.out.println("비밀번호를 입력 : ");
					String pwd = s.next();
					int pwdCnt=0;
					for(int i=0;i<pwd.length();i++) {
						char ch=pwd.charAt(i);
						if(48<=ch&&ch<=57) {
							pwdCnt++;
						}
					}
					if(pwdCnt==pwd.length()) {System.out.println("비밀번호는 숫자만 작성할 수 없다.");continue;}
					else {mList[userNum][2]=pwd;break;}
				}
				
				while(true) {
					System.out.println("이름을 입력 : ");
					String name = s.next();
					int nameCnt=0;
					for(int i=0;i<name.length();i++) {
						char ch=name.charAt(i);
						if(48<=ch&&ch<=57) {
							nameCnt++;
						}
					}
					if(nameCnt!=0) {System.out.println("이름을 올바르게 작성하라.");continue;}
					else {mList[userNum][3]=name;break;}
				}
				System.out.println("멤버 등록 완료. 당신의 번호는 "+dbNum);
				
				count=Integer.parseInt(dbNum);
				count++;
				mList[userNum][0]=dbNum;
				dbNum=String.valueOf(count);
				userNum++;
				memCnt++;
			}	
			else if(sel == 2) {
				// 삭제할 번호 입력받아서 삭제 => 정렬 다시 해줘야함 => 
				System.out.println("당신의 번호를 입력 : ");
				String delNum = s.next();
				int idx=-1;
				for(int i=0;i<memCnt;i++) {
					System.out.println(mList[i][0].equals(delNum)?"okay":"즐");
					if(mList[i][0].equals(delNum)) {
						idx=i;
						break;
					}
				}
				
				if (memCnt==1&&idx==0) {
					mList=null;
					continue;
				}
				String[][] delTemp=new String[100][4];
				int delIdx=0;
				for(int i=0;i<memCnt;i++) {
					if (idx!=i) {
						delTemp[delIdx] = mList[i];
						delIdx++;
					}
				}
				mList = delTemp;
				delTemp = null;
				count--;
				userNum--;
				memCnt--;
				System.out.println("제명 완료.");
			}
			else if(sel == 3) {
				// 수정 => id 와 비번 입력받고 맞으면 해당 id의 비번 혹은 이름만 수정 가능 
				System.out.println("아이디을 입력 : ");
				String id = s.next();

				int idx = -1;
				for(int i=0;i<cnt;i++) {
					if (id.equals(mList[i][1])) {idx=i;break;}
				}

				if(idx==-1) {System.err.println("[없는 아이디 ]");continue;}

				System.out.println("비밀번호 입력 : ");
				String pw=s.next();

				if(pw.equals(mList[idx][2])==false) {System.err.println("[로그인 실패]");continue;}
				s.nextLine();
				System.out.println("[1] 이름수정 [2] 비번수정");
				int select=s.nextInt();

				if(select==1) {
					System.out.println("이름을 입력 : ");
					String name=s.next();

					if(name.equals(mList[idx][3])) {System.err.println("[같은 이름 수정 불가]");continue;}

					count=0;
					for(int i=0;i<name.length();i++) {
						if(name.charAt(i)>='0'&&name.charAt(i)<='9') {count++;}
					}

					if(count>0) {System.err.println("[이름에 숫자값이 있으면 안됩니다]");continue;}
					mList[idx][3]=name;

				} 
				else if(select==2) {
					System.out.println("비밀번호을 입력 : ");
					pw=s.next();

					if(pw.equals(mList[idx][2])) {System.err.println("[다른 비번을 입력해주세요]");continue;}

					count=0;
					if(pw.length()==0) {System.err.println("[비밀번호 값 입력 해주세요 ]");continue;
					}

					for(int i=0;i<pw.length();i++) {
						if(pw.charAt(i)>='0'&&pw.charAt(i)<='9') {count++;}
					}

					if(count==pw.length()) {System.err.println("[비밀번호는 숫자만으로 할 수 없습니다]");continue;}
					mList[idx][2]=pw;
				}
			}
			else if(sel == 4) {
				// 검색 => id 검색 입력 받아서 이름 출력 
				int findCnt=0;
				int a=0;
				System.out.print("id를 입력하다 : ");
				String findId=s.next();
				for(int i=0;i<mList.length;i++) {
					if(mList[i][1].equals(findId)) {a=i;findCnt=1;break;}
				}
				if(findCnt==1) {System.out.println("당신의 이름은 "+mList[a][3]);}
				else {System.out.println("존재하지 않는 아이디.");}
			}
		}
		s.close();
		
	}

}
