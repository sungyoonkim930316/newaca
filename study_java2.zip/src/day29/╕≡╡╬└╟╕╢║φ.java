package day29;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 모두의마블 {

	public static void main(String[] args) {

		/*
		[문제]
			아래 그림을 참고해 배열을 생성하한다.
			2인용 게임으로 서로 번갈아가며 주사위를 던진다.(입력받거나 랜덤으로)
			주사위의 숫자만큼 이동하여, 3바퀴를 먼저 돌면 
			승리하는 게임이다.
			단, 이동할 때 외곽으로만 이동할 수 있다.

			p1 = 0[0바퀴]
			p2 = 0[0바퀴]
			   *    □    □    □    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p1]차례 주사위 입력(1 ~ 6) : 3
			p1 = 3[0바퀴]
			p2 = 0[0바퀴]
			   홋    □    □    솟    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p2]차례 주사위 입력(1 ~ 6) : 5
			p1 = 3[0바퀴]
			p2 = 5[0바퀴]
			   □    □    □    솟    □ 
			   □    ■    ■    ■    홋 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p1]차례 주사위 입력(1 ~ 6) : 2
			p1 = 5[0바퀴]
			p2 = 5[0바퀴]
			   □    □    □    □    □ 
			   □    ■    ■    ■    솟홋
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p2]차례 주사위 입력(1 ~ 6) : 3
			p1 = 5[0바퀴]
			p2 = 8[0바퀴]
			   □    □    □    □    □ 
			   □    ■    ■    ■    솟 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    홋
		 */
		
		Scanner s=new Scanner(System.in);
		Random r=new Random();
		
		int[][] moma=new int[5][5];
		
		int turn=1;
		int p1h=0;
		int p1v=0;
		int p2h=0;
		int p2v=0;
		int dir=0;

		while(true) {
			for(int i=0;i<moma.length;i++) {
				for(int j=0;j<moma[i].length;j++) {
					if(i>0&&i<moma[i].length-1&&j>0&&j<moma[i].length-1) {System.out.print("■  ");}
					else {
						moma[p1v][p1h]=1;
						if(moma[i][j]==1) {System.out.print("옷  ");}
						else {System.out.print("□  ");}
					}
				}System.out.println();
			}System.out.println();
			
			System.out.println("게임진행");
			String game=s.nextLine();
			moma[p1v][p1h]=0;
			int dice=r.nextInt(6)+1;
			System.out.println("주사위 눈 : "+dice);
			if(p1h+dice>moma.length-1) {
				p1h+=(moma.length-1)-p1h;
				p1v+=(p1h+dice)-(moma.length-1);
			}
			else {
				p1h+=dice;
			}
			moma[p1v][p1h]=1;
			System.out.println("p1h : "+p1h);
		}
		
		
	}

}
