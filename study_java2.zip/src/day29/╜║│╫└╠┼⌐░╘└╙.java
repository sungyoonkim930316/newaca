package day29;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 스네이크게임 {

	public static void main(String[] args) {

		/*
		 * [스네이크게임]
		 * 1. 10x10 배열을 0으로 채운다.
		 * 2. 스네이크는 1234로 표시한다.
		 * 3. 머리 상하좌우로 이동이 가능하며, 꼬리가 따라온다.
		 * 4. 자기몸하고 부딪히면, 사망한다.
		 * 5. 랜덤으로 아이템을 생성해
		 *    아이템을 먹으면 꼬리 1개가 자란다.
		 * 6. 꼬리는 최대 8개까지 증가할 수 있다.
		 */
		
		Random r=new Random();
		Scanner s=new Scanner(System.in);
		
		int size=10;
		int[][] board=new int[size][size];
		int[] snake= {1,2,3,4};
		String[] direction= {"A","D","W","S"};
		int headx=4;
		int heady=4;
		int tail=snake.length;
		int snakeIdx=0;
		
		int turn=0;
		while(true) {
//			board=new int[size][size];
			// 게임판
			if(turn==0) {
				for(int i=0;i<board.length;i++) {
					for(int j=0;j<board[i].length;j++) {
						if(i==heady&&j==headx) {
							for(int k=j;k<j+snake.length;k++) {
								board[i][k]=snake[k-j];
							}
						}
					}
					System.out.println(Arrays.toString(board[i]));
				}
				turn=1;
			}
			
			snakeIdx=0;
			
			// 명령어로 벰을 움직이다. 
			System.out.print("[전진 : space bar] [방향전환 : ADWS]");
			String move=s.nextLine();
			if(move.equalsIgnoreCase("a")) {
				headx--;
				for(int i=0;i<board.length;i++) {
					for(int j=0;j<board[i].length;j++) {
						
					}
				}
			}
			if(move.equalsIgnoreCase("d")) {
				board=new int[size][size];
				headx++;
			}
			if(move.equalsIgnoreCase("w")) {
				board=new int[size][size];
				heady--;
			}
			if(move.equalsIgnoreCase("s")) {
				board=new int[size][size];
				heady++;
			}
		}
		
		
	}
}
