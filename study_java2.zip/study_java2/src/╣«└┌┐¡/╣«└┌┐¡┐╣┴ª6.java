package 문자열;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 문자열예제6 {

	public static void main(String[] args) {

		/*
		 * # 타자연습 게임[2단계]
		 * 1. 문제를 섞는다.(shuffle)
		 * 2. 순서대로 문제를 출제하고, 문제를 다 맞추면 게임 종료
		 * 3. 단 문제를 출제할 때, 단어의 랜덤한 위치 한 곳만 *(랜덤 위치 )로 출력 
		 * 예)
		 * 문제 : mys*l
		 * 입력 : mysql	<--- 정답을 맞추면, 다음 문제 제시
		 * 문제 : *sp
		 * 입력 : jap
		 * 문제 : j*p (x) : 문제 틀릴시 별 고정 
		 * 문제 : *sp (0)
		 */
		String[] words = {"java", "mysql", "jsp", "spring"};
		String[] starTemp= {"","","",""};
		
		Random r=new Random();
		Scanner s=new Scanner(System.in);
		
		for(int i =0; i<=50; i++) {
			int idx = r.nextInt(words.length); // 0-3
			String temp = words[idx];
			words[idx] = words[0];
			words[0] = temp;
		}
		for(int i=0;i<words.length;i++) {
			int star=r.nextInt(words[i].length()-1);
			starTemp[i]=words[i].substring(0,star)+'*'+words[i].substring(star+1);
		}
		System.out.println(Arrays.toString(starTemp));
		System.out.println(Arrays.toString(words));
		
		for(int i =0; i < words.length;) {
			System.out.println(starTemp[i] +" 입력>> ");
			String input = s.next();
			if(words[i].equals(input)) {
				System.out.println("정답");
				i++;
			}else {
				System.out.println("오답");
			}
		}
		
		System.out.println("게임종료");
		s.close();
		
	}

}
