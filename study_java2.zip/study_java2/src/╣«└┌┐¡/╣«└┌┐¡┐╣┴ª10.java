package 문자열;

import java.util.Scanner;

public class 문자열예제10 {

	public static void main(String[] args) {

		/*
		 * # 문자열 속 숫자검사
		 * 예) adklajsiod
		 * 	     문자만 있다.
		 * 예) 123123
		 *    숫자만 있다.
		 * 예) dasd12312asd
		 *    문자와 숫자가 섞여있다.
		 */

		Scanner s=new Scanner(System.in);
		System.out.print("입력 : ");
		String text = s.next();
//		String text="sayun";
//		System.out.println(text.length());
//		String[] arr=new String[text.length()];
		
//		for(int i=0;i<text.length();i++) {
//			arr[i]=text.substring(i,i+1);
//		}
//		System.out.println(Arrays.toString(arr));
		
		int n=0;
		for(int i=0;i<text.length();i++) {
			char ch=text.charAt(i);
			if (48<=ch&&ch<=57) {
				n++;
			}
		}
		if(n==text.length()) {System.out.println("숫자만 있다.");}
		else if(n==0) {System.out.println("문자만 있다.");}
		else {System.out.println("문자와 숫자가 섞여있다.");}
		s.close();
		
//		for(int i=0;i<arr.length;i++) {
//			
////			if() {}
//		}
		
	}

}
