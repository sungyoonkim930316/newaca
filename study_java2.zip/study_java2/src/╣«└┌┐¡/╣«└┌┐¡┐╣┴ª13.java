package 문자열;


public class 문자열예제13 {

	public static void main(String[] args) {

		String str = "김철수/87,이만수/42,이영희/95";
		
		// 위 데이터에서 꼴등을 삭제후 다시 문자열로 변경
		
		//1) 문자열을 잘라서 배열에 저장한다.
		String[] temp=str.split(",");
		
		//2) 배열에서 꼴등을 삭제한다
		int idx = 0;
		int[] score = new int[3];  
		String[] name = new String[3];
		
		for(String str1 : temp) {
			System.out.println(str1);
			String data[] = str1.split("/");
			name[idx]=data[0];            // "87" -> 87
			score[idx] = Integer.parseInt(data[1]);
			idx++;
		}
		
		int min=score[0];
		for(int i=1;i<score.length;i++) {
			if(min>score[i]) {min=score[i];}
		}
		System.out.println(min);
		
		//3) 삭제한배열을 다시 문자열로 만든다.
		
		// str = "김철수/87,이영희/95";
		
	}

}
