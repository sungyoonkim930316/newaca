package 문자열;

import java.util.Arrays;
import java.util.Scanner;

public class 문자열예제12 {

	public static void main(String[] args) {

		/*
		 * # 단어 교체하기(replace)
		 * 1. text변수 문장 속에서 변경하고 싶은 단어를 입력받아,
		 * 2. 교체해주는 기능을 구현한다.
		 * 예)
		 * 		Life is too short.
		 * 		변경하고 싶은 단어입력 : Life
		 * 		바꿀 단어입력 : Time
		 * 
		 * 		Time is too short. // 해당 문자 출력 
		 *     // Life 이미 Time 으로 바꿨기때문에 다시 life 입력하면 못찾아야함 
		 */

		Scanner scan = new Scanner(System.in);

		String text = "Life is too short.";
		System.out.println(text);
		text=text.substring(0,text.length()-1);
		String[] temp=text.split(" ");
		System.out.println(Arrays.toString(temp));
		
		System.out.print("변경하고 싶은 단어를 입력하세요 : ");
		String word = scan.nextLine();
		
		int cnt=0;
		int idx=0;
		for(int i=0;i<temp.length;i++) {
			if(temp[i].equalsIgnoreCase(word)) {cnt=1;idx=i;}
		}
		
		if(cnt==1) {
			System.out.print("바꿀 단어를 입력하세요 : ");
			String word2 = scan.nextLine();
			for(int i=0;i<temp.length;i++) {
				if(i==idx) {temp[i]=word2;break;}
			}
			System.out.println(Arrays.toString(temp));
		}
		else System.err.println("즐");
		scan.close();
		
	}

}
