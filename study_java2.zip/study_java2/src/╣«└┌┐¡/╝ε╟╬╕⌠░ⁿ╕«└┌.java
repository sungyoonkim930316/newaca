package 문자열;

import java.util.Arrays;
import java.util.Scanner;

public class 쇼핑몰관리자 {

	public static void main(String[] args) {

		/*
		 * # 쇼핑몰 [관리자]
		 * 1. 카테고리와 아이템을 입력받아 아래의 예시와 같이 저장한다.
		 * 2. 카테고리는 각 행의 첫번째 열에 저장한다.
		 * 3. 아이템은 각 행의 두번째 열에 저장한다.
		 *    단, 아이템은 여러개를 추가할 수 있도록 슬러시(/)를 구분자로 연결해준다.
		 * 예)
		 * {
		 * 		{"과일", "사과/포도/"},
		 * 		{"과자", "홈런볼/쪼리퐁/"},
		 * 		{"음료", "콜라/"},
		 * 		{"육류", "소고기/"}
		 * 		...
		 * } 
		 */

		 String data = "과일,사과/포도\n";
		 data+="과자,홈런볼/조리퐁\n";
		 data+="음료,콜라/사이다/나랑드\n";
		 data+="육류,소고기/돼지고기/오리고기/닭고기\n";
		 
		 String[] dataArray=data.split("\n");
		 String[] category=new String[dataArray.length];
		 String[] item=new String[dataArray.length];
		 for(int i=0;i<dataArray.length;i++) {
			 String[] temp=dataArray[i].split(",");
			 category[i]=temp[0];
			 item[i]=temp[1];
		 }
//		 System.out.println(Arrays.toString(category));
//		 System.out.println(Arrays.toString(item));
		 
		 Scanner s=new Scanner(System.in);
		
		 String[][] items=new String[100][2];
		 for(int i=0;i<items.length;i++) {
		 	 items[i][0]="";
			 items[i][1]="";
		 }
		
//		 int itemCount=0;
		 int cateCount=0;
//		 String[] itemArray=new String[100];
		 
		
		 while(true) {
			 System.out.println("[관리자 모드]");
			 System.out.println("[1]카테고리 관리"); // 카데고리 추가 삭제 구현 
			 System.out.println("[2]아이템  관리"); // 아이템 추가 삭제 구현 
			 System.out.println("[3]전체품목 출력");
			
			 System.out.print(": ");
			 int sel=s.nextInt();
			
			 if(sel==1) {
				 System.out.println("카테고리 [1]추가 [2]삭제 [3]뒤로가기");
				 int ac=s.nextInt();
				 if(ac==1) {
					 System.out.println("추가할 카테고리를 입력하다.");
					 String cateAdd=s.next();
					 items[cateCount][0]=cateAdd;
					 cateCount++;
					 System.out.println("["+cateAdd+"] 카테고리 추가완료.");
				 }
				 else if(ac==2) {
					 int cateIdx=0;
					 System.out.println("삭제할 카테고리를 입력하다.");
					 String cateDel=s.next();
					 boolean cateCheck=false;
					 for(int i=0;i<cateCount;i++) {
						 if(cateDel.equals(items[i][0])) {cateIdx=i;cateCheck=true;break;}
					 }
					 if(cateCheck==true) {
						 cateCount--;
						 int a=0;
						 items[cateIdx][0]="";
						 items[cateIdx][1]="";
						 String[][] temp=new String[cateCount][2];
						 for(int i=0;i<items.length;i++) {
							 temp[a]=items[cateIdx+1];
							 items[cateIdx]=temp[a];
							 a++;
							 if(a>=cateCount-1) {break;}
						 }
					 }
				 }
				 else if(ac==3) {continue;}
				 else {System.out.println("err");}
			 }
			 
			 else if(sel==2) {
				 int cateIdx=0;
				 System.out.println("아이템 [1]추가 [2]삭제 [3]뒤로가기");
				 int ai=s.nextInt();
				 if(ai==1) {
					 System.out.println("어느 카테고리에 추가할 것인지 입력하다");
					 String cateSel=s.next();
					 boolean cateCheck=false;
					 for(int i=0;i<cateCount;i++) {
						 if(cateSel.equals(items[i][0])) {cateIdx=i;cateCheck=true;break;}
					 }
					 
					 if(cateCheck==true) {
						 System.out.println("추가할 아이템을 입력하다.");
						 String itemAdd=s.next();
						 items[cateIdx][1]+=itemAdd+"/";
						 cateIdx=0;
					 }
					 else {System.out.println("err");continue;}
				 }
				 else if(ai==2) {
					 System.out.println("어느 카테고리에서 삭제할 것인지 입력하다");
					 String cateSel=s.next();
					 boolean cateCheck=false;
					 for(int i=0;i<cateCount;i++) {
						 if(cateSel.equals(items[i][0])) {cateIdx=i;cateCheck=true;break;}
					 }
					 
					 if(cateCheck==true) {
						 System.out.println("삭제할 아이템을 입력하다.");
						 String itemDel=s.next();
						 String[] temp=items[cateIdx][1].split("/");
						 for(int i=0;i<temp.length;i++) {
							 if(temp[i].equals(itemDel)) {
								 temp[i]="";
								 break;
							 }
						 }
						 items[cateIdx][1]="";
						 for(int i=0;i<temp.length;i++) {
							 if(temp[i]!=null) {
								 items[cateIdx][1]+=temp[i]+"/";
							 }
							 else {items[cateIdx][1]+=temp[i];}
						 }
						 System.out.println(items[cateIdx][1]);
						 cateIdx=0;
					 }
					 else {System.out.println("err");continue;}
				 }
				 else if(ai==3) {continue;}
				 else {System.out.println("err");}
			 }
			 
			 else if(sel==3) {
				 for(int i=0;i<cateCount;i++) {
					 System.out.println(Arrays.toString(items[i]));
				 }
			 }
			 else if(sel==4) {
				 break;
			 }
		}
		s.close();
		 
		 
	}
}
