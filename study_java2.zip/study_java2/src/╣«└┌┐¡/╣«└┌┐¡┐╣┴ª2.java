package 문자열;

public class 문자열예제2 {

	public static void main(String[] args) {

		String jumin1 = "890101-2012932";
		String jumin2 = "040101-3012932";
		
		String[] case1=jumin1.split("-");
		String[] case2=jumin2.split("-");
		
		// 문제1) 주민1 성별 출력 -> 여성
		String gender1=case1[1].substring(0,1);
		int mf1=Integer.parseInt(gender1);
		System.out.println(mf1==2?"여성":"남성");
		
		// 문제2) 주민1 나이 출력 -> 33세(성인)
		String born1=case1[0].substring(0,2);
		int age1=122-Integer.parseInt(born1);
		System.out.print(age1+"세");
		System.out.println(age1>19?"(성인)":"(청소년)");
		
		// 문제3) 주민2 성별 출력 -> 남성
		String gender2=case2[1].substring(0,1);
		int mf2=Integer.parseInt(gender2);
		System.out.println(mf2==3?"남성":"여성");
		
		// 문제4) 주민2 나이 출력 -> 18세(청소년)
		String born2=case2[0].substring(0,2);
		int age2=22-Integer.parseInt(born2);
		System.out.print(age2+"세");
		System.out.println(age2>19?"(성인)":"(청소년)");
	}
}
