package 문자열;

import java.util.Scanner;

public class 문자열예제4 {

	public static void main(String[] args) {

		/*
		 * # 끝말잇기 게임을 만들어보세요.
		 * 
		 * 제시어 : 자전거
		 * 입력 : 거미
		 * 제시어 : 거미
		 * 입력 : 미술
		 * ...
		 
		 1. 한자리 단어 안되요 
		 2. 기러기 -> 기러기 하면안됨 
		 3. 끝을 입력 받으면 반복문 종료 
		 
		 */
		
		Scanner s=new Scanner(System.in);
		
		String start ="자전거";
		
		while(true) {
			System.out.println(start);
			System.out.println("제시어 : " + start );
			System.out.print("게임중 : ");
			String play=s.nextLine();
			
			if(play.equals("끝")) {break;}
			else {
				if(play.length()==1) {System.out.println("err");continue;}
				else if(play.charAt(0)==play.charAt(play.length()-1)) {System.out.println("err");continue;}
				else if(play.charAt(0)!=start.charAt(start.length()-1)) {System.out.println("err");continue;}
				else {start=play;}
			}
		}
		s.close();
		
		
	}
}
