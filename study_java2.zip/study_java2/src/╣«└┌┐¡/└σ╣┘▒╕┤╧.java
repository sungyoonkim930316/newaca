package 문자열;

import java.util.Arrays;
import java.util.Scanner;

public class 장바구니 {

	public static void main(String[] args) {

		/*
		[문제]
			1. 로그인 후, 쇼핑 메뉴를 선택하면
			   다음과 같은 상품 목록을 출력한다.
			   (1)사과 (2)바나나 (3)딸기
			2. 번호를 선택해 상품을 장바구니에 담는다.
			3. 로그인 회원의 아이디는 cartList배열의 0열에 저장한다.
			4. 해당 회원이 구매한 상품은 cartList배열의 1열에 저장한다.
			
				예)
					{qwer,  사과},
					{javaking,  바나나},
					{abcd,  사과},
					{qwer,  딸기},
					{qwer,  사과},
					...
			5. 장바구니 메뉴를 선택하면, 로그인 한 회원의 구매 물품만 출력한다.
				예)
					qwer = 사과, 딸기, 사과
		 */
			
		Scanner s=new Scanner(System.in);
		
		String[] idList={"qwer", "javaking", "abcd"};
		String[] pwList={"1111",     "2222", "3333"};
		
		int MAX_SIZE=100;
		String[][] cartList=new String[MAX_SIZE][2];
//		for(int i=0;i<cartList.length;i++) {
//			System.out.println(Arrays.toString(cartList[i]));
//		}
		
		String[] items={"사과", "바나나", "딸기"};
		
		int log = -1;
		int cnt=0;
		int idIdx=-1;
		int pwIdx=-1;
		int fruitIdx=-1;
		int cartCount=0;
		
		while(true) {
			System.out.println("[MEGA MART]");
			if(log==-1){
				System.out.println("[1]로 그 인");
			}
			else {
				System.out.println("[2]로그아웃");
				System.out.println("[3]쇼     핑");
				System.out.println("[4]장바구니");
			}
			System.out.println("[0]종     료");
			
			System.out.print("메뉴 선택 : ");
			int sel=s.nextInt();
			
			if(sel==1) {
				while(true) {
					System.out.println("아이디를 입력하다 : ");
					String liId=s.next();
					for(int i=0;i<idList.length;i++) {
						if(idList[i].equals(liId)) {idIdx=i;break;}
					}
					if(idIdx!=-1) {break;}
					else {System.out.println("err");continue;}
				}
				
				while(true) {
					System.out.println("패스워드를 입력하다 : ");
					String liPwd=s.next();
					for(int i=0;i<pwList.length;i++) {
						if(pwList[idIdx].equals(liPwd)) {pwIdx=i;break;}
					}
					if(pwIdx!=-1) {break;}
					else {System.out.println("err");continue;}
				}
				log=1;
			}
			else if(sel==2) {if(log==-1) {System.out.println("err");continue;}System.out.println("로그아웃완료");cartCount=0;pwIdx=-1;log=-1;}
			else if(sel==3) {
				if(log==-1) {System.out.println("err");continue;}
				while(true) {
					int exception=-1;
					System.out.println(Arrays.toString(items));
					System.out.println("물건을 고르다(quit 입력 시 쇼핑 종료) : ");
					String fruit=s.next();
					if(exception==-1&&fruit.equals("quit")) {exception=1;}
					for(int i=0;i<items.length;i++) {
						if(items[i].equals(fruit)) {fruitIdx=i;exception=1;break;}
					}
					if(exception==1) {
						if(fruitIdx!=-1){
							cartList[cnt][0]=idList[idIdx];
							cartList[cnt][1]=items[fruitIdx];
							cnt++;
							System.out.println("["+items[fruitIdx]+" 장바구니에 추가 완료.]");
							fruitIdx=-1;
							continue;
						}
						if(fruit.equals("quit")) {break;}
					}
					else {System.out.println("err");continue;}
				}
				
			}
			
			
			else if(sel==4) {
				if(log==-1) {System.out.println("err");continue;}
				System.out.print(idList[idIdx]+" = ");
				for(int i=0;i<cnt;i++) {
					if(cartList[i][0].equals(idList[idIdx])) {
						if(i==cnt-1) {System.out.print(cartList[i][1]);cartCount++;}
						else {System.out.print(cartList[i][1]+", ");cartCount++;}
					}
				}
				System.out.println();
				System.out.println(idList[idIdx]+"님의 장바구니 갯수 : "+cartCount);
				
				System.out.println("----------------");
				System.out.println("[1]아이템 삭제 [2] 전체 삭체 [3] 뒤로가기");
				System.out.println("입력 >> ");
				int num=s.nextInt();
				if(num==1) {
					while(true) {
						System.out.println("[삭제] 아이템 입력 >> ");
						// 아이템 이름으로 삭제
						String name = s.next();
						System.out.println("삭제할 갯수 입력 >> ");
						int dup=s.nextInt();
						int temp=dup;
						while(true) {
							int idx=-1;
							
							for(int i=0;i<cnt;i++) {
								if(name.equals(cartList[i][1])&&idList[idIdx].equals(cartList[i][0])) {
									idx=i;
									break;
								}
							}
							
							if(idx==-1) {System.out.println("err");continue;}
							
							for(int i=idx;i<cnt-1; i++) {cartList[i]=cartList[i+1];	}
							cartList[cnt-1]=new String[2];
							cnt--;
							cartCount--;
							dup--;
							if(dup<=0) {break;}
						}
						System.out.printf("[ %s %d개 장바구니에서 삭제 완료] \n",name,temp);
						break;
					}

				} 
				else if(num==2) {
					System.out.println("[전체 삭제 완료 ]");
					// 본인 아이디 전체 장바구니 비우기 
					int enzo=0;
					for(int i=0;i<cnt;i++) {
						if(cartList[i][0].equals(idList[idIdx])) {enzo++;}
					}
					
					while(enzo>0) {
						int idx=-1;
						for(int i=0;i<cnt;i++) {
							if(cartList[i][0].equals(idList[idIdx])) {
								idx=i;
								break;
							}
						}
						for(int i=idx;i<cnt-1;i++) {cartList[i]=cartList[i+1];}
						
						cartList[cnt-1]=new String[2];
						cnt--;
						enzo--;
						cartCount=0;
					}
					System.out.println("[전체 삭제 완료 ]");
				}
				else if(num==3) {continue;}
			}
			else if(sel==0) {System.out.println("프로그램 종료");break;}		
		}
		s.close();
		
	}

}
