package member2;

public class _MemberMain {

	public static void main(String[] args) {

		// 메인 클래스는 controller의 run 밖에 모른다 
		MemberController controller = new MemberController();
		controller.run();
		
	}

}
