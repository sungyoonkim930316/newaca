package 문자열심화;

import java.util.Arrays;
import java.util.Scanner;

public class 레벨5테스트 {

	public static void main(String[] args) {

		//[부서정보]
		//[부서번호,부서명,지역]
		String[][] departmentData = { 
				{ "10", "ACCOUNTING", "NEW YORK" }, 
				{ "20", "RESEARCH", "DALLAS" },
				{ "30", "SALES", "CHICAGO" }, 
				{ "40", "OPERATIONS", "BOSTON" }, 
			};
		// [사원정보]
		// [번호,이름,직책,상사번호,입사일,급여,커미션,부서번호]
		String[][] employeeData = { 
				{ "7369", "SMITH", "CLERK", "7902", "17-12-1980", "800", "0", "20" },
				{ "7499", "ALLEN", "SALESMAN", "7698", "20-2-1981", "1600", "300", "30" },
				{ "7521", "WARD", "SALESMAN", "7698", "22-2-1981", "1250", "500", "30" },
				{ "7566", "JONES", "MANAGER", "7839", "2-4-1981", "2975", "0", "20" },
				{ "7654", "MARTIN", "SALESMAN", "7698", "28-9-1981", "1250", "1400", "30" },
				{ "7698", "BLAKE", "MANAGER", "7839", "1-5-1981", "2850", "0", "30" },
				{ "7782", "CLARK", "MANAGER", "7839", "9-6-1981", "2450", "0", "10" },
				{ "7788", "SCOTT", "ANALYST", "7566", "13-7-1987", "3000", "0", "20" },
				{ "7839", "KING", "PRESIDENT", "NULL", "17-11-1981", "5000", "0", "10" },
				{ "7844", "TURNER", "SALESMAN", "7698", "8-9-1981", "1500", "0", "30" },
				{ "7876", "ADAMS", "CLERK", "7788", "13-7-1987", "1100", "0", "20" },
				{ "7900", "JAMES", "CLERK", "7698", "3-12-1981", "950", "0", "30" },
				{ "7902", "FORD", "ANALYST", "7566", "3-12-1981", "3000", "0", "20" },
				{ "7934", "MILLER", "CLERK", "7782", "23-1-1982", "1300", "0", "10" }
				};	
		
		// Q1) "DALLAS"에서 근무하는 사원의 이름,직급,부서번호,부서명을 조회하시오

		// Q2) ALLEN과 같은 부서에 근무하는 사원의 이름, 부서번호를 조회하시오.
		
		/*		
		   Q3) 부서별 최대 급여와 최소 급여를 구하시오.
		
		   Q4) 부서별로 급여 평균 (단, 부서별 급여 평균이 2000 이상만)
			
		   Q5) 부서번호가 30번인 사원들의 이름, 직급, 부서번호, 부서위치를 조회하시오.		
		
		   Q6) 이름에 A 가 들어가는 사원의 이름,부서명을 조회하시오.
					
		   Q7) 사원명 'JONES'가 속한 부서명을 조회하시오.

		   Q8) 10번 부서에서 근무하는 사원의 이름과 10번 부서의 부서명을 조회하시오.
		
		 */
		
		Scanner s=new Scanner(System.in);
		
		
		// Q1 solution
		System.out.print("근무지 입력 ");
		String loc=s.nextLine();
		String primaryKey="";
		for(int i=0;i<departmentData.length;i++) {
			for(int j=0;j<departmentData[i].length;j++) {
				if(departmentData[i][j].equalsIgnoreCase(loc)) {
					primaryKey=departmentData[i][0];
					i=departmentData.length;
					break;
				}
			}
		}
		
		System.out.println("문제1) "+loc+"에서 근무하는 사원");
		System.out.println("이름\t직급\t부서코드\t부서명");
		for(int i=0;i<employeeData.length;i++) {
			for(int j=0;j<employeeData[i].length;j++) {
				if(employeeData[i][employeeData[i].length-1].equalsIgnoreCase(primaryKey)) {
					System.out.print(employeeData[i][1]+"\t"+employeeData[i][2]+"\t"+employeeData[i][7]+"\t"+employeeData[i][1]+"\n");
					break;
				}
			}
		}
		
		System.out.println("=============================");
		
		// Q2 solution
		System.out.print("이름을 입력 ");
		String name=s.nextLine();
		primaryKey="";
		for(int i=0;i<employeeData.length;i++) {
			for(int j=0;j<employeeData[i].length;j++) {
				if(employeeData[i][1].equalsIgnoreCase(name)) {
					primaryKey=employeeData[i][7];
					i=employeeData.length;
					break;
				}
			}
		}
		System.out.println(primaryKey);
		System.out.println("문제2) \""+name+"\"과 같은 부서에 근무하는 사원");
		System.out.println("이름\t부서코드");
		for(int i=0;i<employeeData.length;i++) {
			for(int j=0;j<employeeData[i].length;j++) {
				if(employeeData[i][employeeData[i].length-1].equalsIgnoreCase(primaryKey)) {
					boolean check=employeeData[i][1].equalsIgnoreCase(name)?false:true;
					if(check==false) {continue;}
					else {
						System.out.print(employeeData[i][1]+"\t"+employeeData[i][7]+"\n");
						break;
					}
				}
			}
		}

		System.out.println("=============================");
		
		// Q3 solution
		
		int count=0;
		System.out.println("문제3) 부서별 최대 급여와 최소 급여");
		System.out.println("부서명\t최대 급여\t최소 급여");
		while(true) {
			String max="0";
			String min="0";
			for(int i=0;i<employeeData.length;i++) {
				if(departmentData[count][0].equals(employeeData[i][7])) {
					if(Integer.parseInt(min)==0) {
						min=employeeData[i][5];
					}
					if(Integer.parseInt(max)<Integer.parseInt(employeeData[i][5])) {
						max=employeeData[i][5];
					}
					if(Integer.parseInt(min)>Integer.parseInt(employeeData[i][5])) {
						min=employeeData[i][5];
					}
				}
			}
			
			if(min.equals("0")) {
				min="no data";
			}
			if(max.equals("0")) {
				max="no data";
			}
			System.out.print(departmentData[count][1]+"\t"+max+"\t"+min+"\n");
			count++;
			if(count>departmentData.length-1) {break;}
		}
		
		System.out.println("=============================");
		
		// Q4 solution
		
		count=0;
		System.out.println("문제4) 부서 급여 평균이 2000 ↑ 급여부서");
		System.out.println("부서명\t평균 급여");
		while(true) {
			double depCount=0;
			int sum=0;
			String max="0";
			String min="0";
			for(int i=0;i<employeeData.length;i++) {
				if(departmentData[count][0].equals(employeeData[i][7])) {
					depCount++;
					sum+=Integer.parseInt(employeeData[i][5]);
				}
			}
			double avg=sum/depCount;
			if(avg>=2000) {
				System.out.printf("%s\t%.2f\n",departmentData[count][1],avg);
			}
			count++;
			if(count>departmentData.length-1) {break;}
		}
		
		System.out.println("=============================");
		
		// Q5 solution
		
		System.out.print("부서번호를 입력");
		String depNum=s.nextLine();
		primaryKey="";
		String depLoc="";
		
		System.out.println("문제5) 부서번호가 "+depNum+"번인 사원들의 이름, 직급, 부서코드, 부서위치");
		System.out.println("이름\t직급\t부서코드\t부서위치");
		for(int i=0;i<departmentData.length;i++) {
			for(int j=0;j<departmentData[i].length;j++) {
				if(departmentData[i][j].equalsIgnoreCase(depNum)) {
					primaryKey=departmentData[i][0];
					depLoc=departmentData[i][2];
					i=departmentData.length;
					break;
				}
			}
		}
		for(int i=0;i<employeeData.length;i++) {
			for(int j=0;j<employeeData[i].length;j++) {
				if(employeeData[i][7].equalsIgnoreCase(primaryKey)) {
					System.out.print(employeeData[i][1]+"\t"+employeeData[i][2]+"\t"+primaryKey+"\t"+depLoc+"\n");
					break;
				}
			}
		}
		
		System.out.println("=============================");
		
		// Q6 solution
		
		primaryKey="";
		String depName="";
		System.out.println("문제6) 이름에 A가 들어가는 사원의 이름, 부서명을 조회하시오");
		System.out.println("이름\t부서명");
		for(int i=0;i<employeeData.length;i++) {
			for(int j=0;j<employeeData[i][1].length()-1;j++) {
				if(employeeData[i][1].charAt(j)=='A') {
					primaryKey=employeeData[i][7];
					for(int k=0;k<departmentData.length;k++) {
						if(primaryKey.equals(departmentData[k][0])) {
							depName=departmentData[k][1];
							break;
						}
					}
					System.out.print(employeeData[i][1]+"\t"+depName+"\n");
					break;
				}
			}
		}

		System.out.println("=============================");
		
		// Q7 solution
		
		System.out.println("사원명을 입력하다 ");
		name=s.nextLine();
		primaryKey="";
		System.out.println("문제7) 사원명 '"+name+"'가 속한 부서명을 조회");
		System.out.println("이름\t부서명");
		for(int i=0;i<employeeData.length;i++) {
			if(employeeData[i][1].equalsIgnoreCase(name)) {
				primaryKey=employeeData[i][7];
				for(int j=0;j<departmentData.length;j++) {
					if(primaryKey.equals(departmentData[j][0])) {
						depName=departmentData[j][1];
						break;
					}
				}
				System.out.print(employeeData[i][1]+"\t"+depName+"\n");
				break;
			}
		}

		System.out.println("=============================");
		
		// Q8 solution
		
		System.out.println("부서번호를 입력하다 ");
		primaryKey=s.nextLine();
		System.out.println("문제8) "+primaryKey+"번 부서에서 근무하는 사원의 이름과 "+primaryKey+"번 부서의 부서명을 조회");
		System.out.println("이름\t부서명");
		for(int i=0;i<employeeData.length;i++) {
			if(employeeData[i][7].equals(primaryKey)) {
				for(int j=0;j<departmentData.length;j++) {
					if(primaryKey.equals(departmentData[j][0])) {
						depName=departmentData[j][1];
						break;
					}
				}
				System.out.println(employeeData[i][1]+"\t"+depName);
			}
		}

		System.out.println("=============================");
		
		// Q9 solution
		
		String[] birth=new String[employeeData.length-1];
		System.out.print("년도를 입력하다");
		String year=s.next();
		System.out.println("문제9) "+year+"년생 사원의 이름과 직책과 부서위치 조회");
		System.out.println("이름\t직책\t부서위치");
		for(int i=0;i<employeeData.length;i++) {
			birth=employeeData[i][4].split("-");
			if(birth[2].equals(year)) {
				primaryKey=employeeData[i][7];
				for(int j=0;j<departmentData.length;j++) {
					if(primaryKey.equals(departmentData[j][0])) {
						loc=departmentData[j][2];
					}
				}
				System.out.println(employeeData[i][1]+"\t"+employeeData[i][2]+"\t"+loc);
			}
		}

		System.out.println("=============================");
		
		
		
		
		
		
		
		
		
		
	}

}
