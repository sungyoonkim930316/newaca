package day34;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 지뢰찾기 {

	public static void main(String[] args) {

		
		Scanner s=new Scanner(System.in);
		Random r=new Random();
		/*
		 지뢰찾기 
		1. 현재 위치에 지뢰 매핑하기
		2.  지뢰 매핑시 매설 가능 지뢰 수 입력 받아서 셋팅
		3. 깃발 위치 입력 받기 
		4. 모든 지뢰 위치값이랑 깃발값이 같으면 게임 승리
		5. 지뢰 선택시 게임 종료
		*/


		int game[][] = new int[5][5];
		for(int i=0;i<game.length;i++) {
			for(int j=0;j<game[i].length;j++) {
				game[i][j]=-1;
			}
		}
		int[][] temp=new int[game.length][game.length]; 

		int mineCnt=0;
		int setting=0;
		int loseCnt=0;
		int mine=0;
		
		System.out.println("타이머 시작");

		long beforeTime = System.currentTimeMillis(); //코드 실행 전에 시간 받아오기 : 밀리세컨드 단위 1초 ==  1000
		for(int z =0; z < 1000000;z++){
			
			while(true) {
				if(loseCnt==1) {System.err.println("[BOOM~♣♣!]");}
				
				// 게임판
				for(int i=0;i<game.length;i++) {
					for(int j=0;j<game[i].length;j++) {
						if(game[i][j]==11) {System.out.print("[♨]");}
						else if(game[i][j]==12) {System.out.print("[¶]");}
						else if(game[i][j]!=-1&&game[i][j]!=9&&game[i][j]!=11) {System.out.print("["+game[i][j]+"]");}
						else if(game[i][j]==0) {System.out.print("["+temp[i][j]+"]");} 
						else {System.out.print("[ ]");}
					} System.out.println();
				}
				
				// 지뢰 밟으면 페배
				if(loseCnt==1) {
					System.out.println();
					System.out.println("[지뢰 폭발 => 패베]");
					for(int i=0;i<game.length;i++) {
						System.out.println(Arrays.toString(temp[i]));
					}
					break;
				}
				
				// 지뢰가 없으면 승리
				if(mine!=0&&mineCnt==mine) {
					System.out.println();
					System.out.println("[★승리.★]");
					for(int i=0;i<game.length;i++) {
						System.out.println(Arrays.toString(temp[i]));
					}
					break;
				}
				
				// 랜덤한 위치에 마인 생성
				if(setting==0) {
					System.out.println("매설할 지뢰의 갯수를 입력하다.");
					int mineLimitation=s.nextInt();
					if(mineLimitation<=0||mineLimitation>game.length*game.length) {System.err.println("err");continue;}
					mine=mineLimitation;
					while(true) {
						int minex=r.nextInt(game.length-1);
						int miney=r.nextInt(game.length-1);
						if(game[miney][minex]==-1) {
							game[miney][minex]=9;
							mineCnt++;
						}
						if(mineCnt==mineLimitation) break;
					}
					System.out.println("[지뢰 매설 완료.]");
					mineCnt=0;
					for(int i=0;i<temp.length;i++) {
						for(int j=0;j<temp[i].length;j++) {temp[i][j]=game[i][j];}
					}
					setting++;
					continue;
				}
				
				
				// 플레이
				System.out.println("[누를 칸의 y인덱스좌포를 입력하다]");
				int playy=s.nextInt();
				System.out.println("[누를 칸의 x인덱스좌포를 입력하다]");
				int playx=s.nextInt();
				
				System.out.println("[1 누르다][2 깃발을 설치하다][3 깃발을 치우다][4 항복 후 정답공개]");
				int flagOrPush=s.nextInt();
				
				
				// 예왜처리
				if(playy>game.length-1||playy<0||playx>game.length-1||playx<0) {System.err.println("err");continue;}
				if(flagOrPush>4||flagOrPush<1) {System.err.println("err");continue;}
				
				// 누르다
				if(flagOrPush==1) {
					int[] x={-1,0,1,-1,1,-1,0,1};
					int[] y={-1,-1,-1,0,0,1,1,1};
					int tx=0; 
					int ty=0;
					int cnt=0;
					for(int i=0;i<game.length;i++) {
						for(int j=0;j<game[i].length;j++) {
							if(game[playy][playx]==9) {game[playy][playx]=11;loseCnt++;}
							else if(game[playy][playx]==-1) {
								for (int k=0;k<x.length;k++) {
									tx=playx+x[k];
									ty=playy+y[k];
									if(tx>-1&&ty>-1&&tx<game.length&&ty<game.length){	
										if(temp[ty][tx]==9) {cnt++;}
									}
								}	
								game[playy][playx]=cnt;
							}
						}
					}
				}
				// 깃발을 설치하다
				else if(flagOrPush==2) {
					if(game[playy][playx]!=-1&&game[playy][playx]!=9) {System.err.println("이미 눌러진 블록.");continue;}
					else{
						game[playy][playx]=12;
						if(temp[playy][playx]==9) mineCnt++;
						System.out.println("[깃발 설치 완료.]");
					}
				}
				// 깃발을 치우다
				else if(flagOrPush==3) {
					if(game[playy][playx]!=12) {System.err.println("깃발이 존재하지 않는다.");}
					else {
						if(temp[playy][playx]==9) {
							game[playy][playx]=9;
							mineCnt--;
						}
						else game[playy][playx]=-1;
						System.out.println("[깃발 제거 완료.]");
					}
				}
				else {
					for(int i=0;i<game.length;i++) {
						System.out.println(Arrays.toString(temp[i]));
					}
					break;
				}
			}
			
			break;
		}
		long afterTime = System.currentTimeMillis(); // 코드 실행 후에 시간 받아오기
		double secDiffTime = (afterTime - beforeTime) / 1000.0; //두 시간에 차 계산

		System.out.println("타이머 끝 : " + secDiffTime);
		
		
		
		s.close();
		
	}
}
