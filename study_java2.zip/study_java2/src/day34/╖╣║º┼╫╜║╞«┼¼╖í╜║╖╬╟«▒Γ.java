package day34;

class DefInfo {
	int deNo1;
	String deName;
	String loc;
}

class EmInfo {
	int no;
	String name;
	String title;
	int supNo;
	String date;
	int sal;
	int com;
	int deNo2;
}

public class 레벨테스트클래스로풀기 {

	public static void main(String[] args) {

		String deData="";
		deData+="10/ACCOUNTING/NEW YORK\n";
		deData+="20/RESEARCH/DALLAS\n";
		deData+="30/SALES/CHICAGO\n";
		deData+="40/OPERATION/BOSTON";
		
		String emData="";
		emData+="7369/SMITH/CLERK/7902/17-12-1980/800/0/20\n";
		emData+="7499/ALLEN/SALESMAN/7698/20-2-1981/1600/300/30\n";
		emData+="7521/WARD/SALESMAN/7698/22-2-1981/1250/500/30\n";
		emData+="7566/JONES/MANAGER/7839/2-4-1981/2975/0/20\n";
		emData+="7654/MARTIN/SALESMAN/7698/28-9-1981/1250/1400/30\n";
		emData+="7698/BLAKE/MANAGER/7839/1-5-1981/2850/0/30\n";
		emData+="7782/CLARK/MANAGER/7839/9-6-1981/2450/0/10\n";
		emData+="7788/SCOTT/ANALYST/7566/13-7-1987/3000/0/20\n";
		emData+="7839/KING/PRESIDENT/NULL/17-11-1981/5000/0/10\n";
		emData+="7844/TURNER/SALESMAN/7698/8-9-1981/1500/0/30\n";
		emData+="7876/ADAMS/CLERK/7788/13-7-1987/1100/0/20\n";
		emData+="7900/JAMES/CLERK/7698/3-12-1981/950/0/30\n";
		emData+="7902/FORD/ANALYST/7566/3-12-1981/3000/0/20\n";
		emData+="7934/MILLER/CLERK/7782/23-1-1982/1300/0/10";
		
		String[] temp1=deData.split("\n");
		String[] temp2=emData.split("\n");
		int size1=temp1.length;
		int size2=temp2.length;
		DefInfo[] defList=new DefInfo[size1];
		EmInfo[] emList=new EmInfo[size2];
		
		int idx=0;
		for(DefInfo def:defList) {
			String[] info=temp1[idx].split("/");
			def=new DefInfo();
			def.deNo1=Integer.parseInt(info[0]);
			def.deName=info[1];
			def.loc=info[2];
			defList[idx]=def;
			idx++;
		}
//		System.out.println(defList[1].deNo1+" "+defList[1].deName+" "+defList[1].loc);
		
		idx=0;
		for(EmInfo em:emList) {
			String[] info=temp2[idx].split("/");
			em=new EmInfo();
			em.no=Integer.parseInt(info[0]);
			em.name=info[1];
			em.title=info[2];
			if(info[3].equalsIgnoreCase("NULL")) em.supNo=0;
			else em.supNo=Integer.parseInt(info[3]);
			em.date=info[4];
			em.sal=Integer.parseInt(info[5]);
			em.com=Integer.parseInt(info[6]);
			em.deNo2=Integer.parseInt(info[7]);
			emList[idx]=em;
			idx++;
		}
//		System.out.println(emList[8].no+" "+emList[8].name+" "+emList[8].title+" "+
//				emList[8].supNo+" "+emList[8].date+" "+emList[8].sal+" "+
//				emList[8].com+" "+emList[8].deNo2);
		
		// 문제 1) # "DALLAS"에서 근무하는 사원의 이름,직급,부서번호,부서명을 조회하시오
		
		String primaryKey="";
		System.out.println("Q1");
		System.out.println(" [DALLAS에서 근무하는 사원 정보]");
		System.out.println("이름\t직급\t부서번호\t부서명");
		System.out.println("=============================");
		int finder=0;
		for(int i=0;i<defList.length;i++) {
			if(defList[i].loc.equalsIgnoreCase("dallas")) {
				finder=i;
				primaryKey=String.valueOf(defList[i].deNo1);
			}
		}
		for(int i=0;i<emList.length;i++) {
			if(emList[i].deNo2==Integer.parseInt(primaryKey)) {
				System.out.println(emList[i].name+"\t"+emList[i].title+"\t"+primaryKey+"\t"+defList[finder].deName);
			}
			
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 2) # ALLEN과 같은 부서에 근무하는 사원의 이름, 부서번호를 조회하시오.
		System.out.println("Q2");
		System.out.println("[ALLEN과 같은 부서에서 근무하는 사원 정보]");
		System.out.println("이름\t\t부서번호");
		System.out.println("=============================");
		finder=0;
		for(int i=0;i<emList.length;i++) {
			if(emList[i].name.equalsIgnoreCase("allen")) {
				finder=i;
				primaryKey=String.valueOf(emList[i].deNo2);
			}
		}
		for(int i=0;i<emList.length;i++) {
			if(emList[i].deNo2==Integer.parseInt(primaryKey)) {
				if(emList[i].name.equalsIgnoreCase("allen")) continue;
				System.out.println(emList[i].name+"\t\t"+primaryKey);
			}
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 3) 부서별 최대 급여와 최소 급여를 구하시오.
		System.out.println("Q3");
		System.out.println("[부서별 최대 급여와 최소 급여]");
		System.out.println("부서명  \t  최소 급여  \t  최대 급여");
		System.out.println("=============================");
		
		int cnt=0;
		while(true) {
			int max=0;
			int min=0;
			for(int i=0;i<emList.length;i++) {
				if(defList[cnt].deNo1==emList[i].deNo2) {
					if(min==0) min=emList[i].sal;
					if(max<emList[i].sal) max=emList[i].sal;
					if(min>emList[i].sal) min=emList[i].sal;
				}
			}
			if(min==0) min=0;
			if(max==0) max=0;
			System.out.println(defList[cnt].deName+"  \t"+max+"  \t"+min+"\n");
			cnt++;
			if(cnt>defList.length-1) break;
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 4) 부서별로 급여 평균 (단, 부서별 급여 평균이 2000 이상만)
		System.out.println("Q4");
		System.out.println("[부서 급여 평균이 2000+인 부서]");
		System.out.println("부서명\t\t평균 급여");
		System.out.println("=============================");
		
		cnt=0;
		while(true) {
			double depCnt=0;
			int sum=0;
			int max=0;
			int min=0;
			for(int i=0;i<emList.length;i++) {
				if(defList[cnt].deNo1==emList[i].deNo2) {
					depCnt++;
					sum+=emList[i].sal;
				}
			}
			double avg=sum/depCnt;
			if(avg>=2000) {System.out.printf("%s\t\t%.2f\n",defList[cnt].deName,avg);}
			cnt++;
			if(cnt>defList.length-1) break;
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 5) 부서번호가 30번인 사원들의 이름, 직급, 부서번호, 부서위치를 조회하시오.
		System.out.println("Q5");
		System.out.println("[부서번호가 30번인 사원들의 이름, 직급, 부서코드, 부서위치]");
		System.out.println("이름\t직급\t부서코드\t부서위치");
		System.out.println("=============================");
		
		primaryKey="";
		String depLoc="";
		for(int i=0;i<defList.length;i++) {
			if(defList[i].deNo1==30) {
				depLoc=defList[i].loc;
			}
		}
		for(int i=0;i<emList.length;i++) {
			if(emList[i].deNo2==30) {
				System.out.print(emList[i].name+"\t"+emList[i].title+"\t"+emList[i].deNo2+"\t"+depLoc+"\n");
			}
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 6) 이름에 A 가 들어가는 사원의 이름,부서명을 조회하시오.
		System.out.println("Q6");
		System.out.println("[이름에 A가 들어가는 사원의 이름, 부서명을 조회하시오]");
		System.out.println("이름\t\t부서명");
		System.out.println("=============================");

		int x=0;
		String depName="";
		for(int i=0;i<emList.length;i++) {
			for(int j=0;j<emList[i].name.length()-1;j++) {
				if(emList[i].name.charAt(j)=='A') {
					x=emList[i].deNo2;
					for(int k=0;k<defList.length;k++) {
						if(x==defList[k].deNo1) {depName=defList[k].deName;break;}
					}
					System.out.println(emList[i].name+"\t\t"+depName+"\n");
					break;
				}
			}
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 7) 사원명 'JONES'가 속한 부서명을 조회하시오.
		System.out.println("Q7");
		System.out.println("[사원명 'JONES'가 속한 부서명을 조회하시오]");
		System.out.println("이름\t\t부서명");
		System.out.println("=============================");
		
		x=0;
		for(int i=0;i<emList.length;i++) {
			if(emList[i].name.equalsIgnoreCase("jones")) {
				x=emList[i].deNo2;
				for(int j=0;j<defList.length;j++) {
					if(x==defList[j].deNo1) {depName=defList[j].deName;break;}
				}
				System.out.print(emList[i].name+"\t\t"+depName+"\n");
				break;
			}
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 8) 10번 부서에서 근무하는 사원의 이름과 10번 부서의 부서명을 조회하시오.
		System.out.println("Q8");
		System.out.println("[10번 부서에서 근무하는 사원의 이름과 10번 부서의 부서명을 조회하시오]");
		System.out.println("이름\t\t부서명");
		System.out.println("=============================");
		
		for(int i=0;i<emList.length;i++) {
			if(emList[i].deNo2==10) {
				for(int j=0;j<defList.length;j++) {
					if(defList[j].deNo1==10) {depName=defList[j].deName;break;}
				}
				System.out.println(emList[i].name+"\t\t"+depName);
			}
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
		// 문제 9) 1987년생의사원의 이름과 직책과 부서명 조회
		System.out.println("Q9");
		System.out.println("[1987년생의사원의 이름과 직책과 부서명 조회]");
		System.out.println("이름  \t직책  \t부서위치");
		System.out.println("=============================");
		
		String[] birth=new String[emList.length-1];
		for(int i=0;i<emList.length;i++) {
			birth=emList[i].date.split("-");
			if(birth[2].equals("1987")) {
				x=emList[i].deNo2;
				for(int j=0;j<defList.length;j++) {
					if(x==defList[j].deNo1) {depLoc=defList[j].loc;}
				}
				System.out.println(emList[i].name+"  \t"+emList[i].title+"  \t"+depLoc);
			}
		}
		System.out.println("-=-=-=-=-=-=-=-=-=-=-=-=-=-=-");
		System.out.println();
		
	}

}
