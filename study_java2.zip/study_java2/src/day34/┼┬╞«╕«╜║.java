package day34;

import java.util.Random;
import java.util.Scanner;

public class 태트리스 {

	public static void main(String[] args) {

		// Getting old man after run this code, and make your own tetris game
		
		int sy=20;
		int sx=10;
		int[][] map=new int[sy][sx];
		Random ran=new Random();
		Scanner s=new Scanner(System.in);		
		int[][][] tList= {
				{
					{0,2,0},
				    {0,2,0},	
				    {0,2,0},
				},
				{				
				    {3,3},	
				    {0,3},				
				},
				{				
				    {4,0},	
				    {4,4},
				},
				{				
				    {5,5},	
				    {5,5},				
				},										
		};			
		int[][] tetris = 
				{
				 {0,0,0},
			     {0,0,0},	
			     {0,0,0}
				};	
		boolean blockNew=true;
		int y=0;
		int x=4;
		int size=0;
		while(true) {			
			if(blockNew) {
				int r=ran.nextInt(tList.length);			
				size=tList[r].length;
				for(int i=0;i<size;i++) {
					for(int j=0;j<size;j++) {
						tetris[i][j]=tList[r][i][j];
						map[y+i][x+j]=tetris[i][j];
					}
				}				
				blockNew=false;
			}					
			for(int i=0;i<sy;i++) {
				for(int j=0;j<sx;j++) {
				    if(map[i][j]==1) System.out.print("[■]");
				    else if(map[i][j] == 0) System.out.print("[□]");
				    else System.out.print("[▦]");
				}
				System.out.println();
			}
			System.out.println("-------------------------------");
			System.out.println("[1.left][2.right][3.down][4.turn]");
			int sel=s.nextInt();
			if(sel==0) break;
			else if(sel==1) {
				for(int i=0;i<size;i++) {
					for(int j=0;j<size;j++) {
						if(tetris[i][j]>1) map[y+i][x+j]=0;
					}
				}
				x-=1;
				for(int i=0;i<size;i++) {
					for(int j=0;j<size;j++) {
						if(tetris[i][j]>1) map[y+i][x+j]=tetris[i][j];
					}
				}				
			}
			else if(sel==2) {	
				for(int i=0;i<size;i++) {
					for(int j=0;j<size;j++) {
						if(tetris[i][j]>1) map[y+i][x+j]=0;
					}
				}
				x+=1;
				for(int i=0;i<size;i++) {
					for(int j=0;j<size;j++) {
						if(tetris[i][j]>1) map[y+i][x+j]=tetris[i][j];
					}
				}		
			}
			else if(sel==3) {			
				while(true) {
					boolean check=false;				
					int mx=x;
					int my=y;
					my+=size;
					for(int i=0;i<size;i++) {
						if(my>=sy) check=true;
					}
			
					if(check==true) {
						for(int i=0;i<size;i++) {
							for(int j=0;j<size;j++) {
								if(j<0||j>=sx) continue;
								if(tetris[i][j]>1) map[y+i][x+j]=1;
							}
						}		
						y=0;
						x=4;
						blockNew=true;
						break;
					}
					
					check=false;
					mx=x;
					my=y;
					my+=1;
					for(int i=0;i<size;i++) {
						for(int j=0;j<size;j++) {
							if(j<0||j>=sx) continue;
							if(mx+j<0||mx+j>=sx) continue;
							if(map[my+i][mx+j]==1&&tetris[i][j]>1) check=true;break;
						}
						if(check==true) break;
					}
					if(check==true) {
						for(int i=0;i<size;i++) {
							for(int j=0;j<size;j++) {
								if(tetris[i][j]>1) map[y+i][x+j]=1;
							}
						}		
						y=0;
						x=4;
						blockNew=true;
						break;
					}	
					
					for(int i=0;i<size;i++) {
						for(int j=0;j<size;j++) {
							if(tetris[i][j]>1) map[y+i][x+j]=0;
						}
					}
					y+=1;
					for(int i=0;i<size;i++) {
						for(int j=0;j<size;j++) {
							if(tetris[i][j]>1) map[y+i][x+j]=tetris[i][j];
						}
					}		
				}			
			}
			else if(sel == 4) {
					
			}
			
		}
		
		
	}
}
