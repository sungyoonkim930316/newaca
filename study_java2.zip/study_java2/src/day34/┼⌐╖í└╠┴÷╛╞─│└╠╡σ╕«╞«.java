package day34;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 크래이지아캐이드리트 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		Random r=new Random();

		// 게임판 최초 세팅
		int size=7;
		int[][] map=new int[size][size];
		int bazziy=3;
		int bazzix=3;
		int setting=0;
		
		int icnt=1;
		
		int[][] bLoc=new int [icnt][2];	//이거 널로 주고 해보기
		int bcnt=0;
		
		while(true) {
			// 캐릭터 위치
			map[bazziy][bazzix]=2;
			
			// 폭탄 위치
			for(int i=0;i<bLoc.length;i++) {
				map[bLoc[i][0]][bLoc[i][1]]=9;
			}
			
			// 랜덤한 위치에 벽 생성
			if(setting==0) {
				int walls=0;
				while(true) {
					int wallx=r.nextInt(size);
					int wally=r.nextInt(size);
					if(map[wally][wallx]==0) {
						map[wally][wallx]=3;
						walls++;
					}
					if(walls==20) break;
				}
				setting=1;
			}
			
			// 게임판
			for(int i=0;i<map.length;i++) {
				for(int j=0;j<map[i].length;j++) {
					if(map[i][j]==2) {System.out.print("[B]");}
					else if(map[i][j]==3) {System.out.print("[■]");}
					else if(map[i][j]==4) {System.out.print("[★]");}
					else if(map[i][j]==9) {System.out.print("[⊙]");}
					else {System.out.print("[ ]");}
				}System.out.println();
			}
			
			// 진행 현황
//			for(int i=0;i<map.length;i++) {
//				System.out.println(Arrays.toString(map[i]));
//			}
			
			System.out.println("[캐릭터를 조작하다]");
			System.out.printf("[W] 위로 이동 [S] 아래쪽으로 이동 [A] 왼쪽으로 이동 [D] 오른쪽으로 이동 [Q] 폭탄설치 [R] 폭파\n");
			String menu=s.nextLine();

			// 배찌 현위치 제거
			map[bazziy][bazzix]=0;
			
			
			
			// 예외처리
			boolean check=menu.equalsIgnoreCase("w")||menu.equalsIgnoreCase("s")||menu.equalsIgnoreCase("a")||menu.equalsIgnoreCase("d")||menu.equalsIgnoreCase("q")||menu.equalsIgnoreCase("r")?true:false;
			if(check==false) {System.err.println("err");continue;}
			
			// 플레이
			if(check==true) {
				if(menu.equalsIgnoreCase("w")) {
					if(bazziy>0&&map[bazziy-1][bazzix]!=3) {bazziy--;}
				}
				else if(menu.equalsIgnoreCase("s")) {
					if(bazziy<map.length-1&&map[bazziy+1][bazzix]!=3) {bazziy++;}
				}
				else if(menu.equalsIgnoreCase("a")) {
					if(bazzix>0&&map[bazziy][bazzix-1]!=3) {bazzix--;}
				}
				else if(menu.equalsIgnoreCase("d")) {
					if(bazzix<map.length-1&&map[bazziy][bazzix+1]!=3) {bazzix++;}
				}
				else if(menu.equalsIgnoreCase("q")) {
					// 이전 배찌 위치에 폭탄을 심다.
//					map[bazziy][bazzix]=9;
					
					bLoc[icnt-1][0]=bazziy;
					bLoc[icnt-1][1]=bazzix;
					System.out.println("[폭탄 설치 완료.]");
				}
				else if(menu.equalsIgnoreCase("r")) {
					// 폭탄이 터지다
					
					// 폭탄 히스토리없앰
				}
			}
			
			
		}
		
		
	}
}
