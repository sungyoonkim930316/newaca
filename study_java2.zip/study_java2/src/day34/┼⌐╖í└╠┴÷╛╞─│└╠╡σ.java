package day34;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 크래이지아캐이드 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		Random r=new Random();

		/*
		 * # 크레이지 아케이드
		 * 1. 맵의 크기는 7 x 7 이다. 
		 * 2. 상(1)하(2)좌(3)우(4)로 이동이 가능하며,
		 *    폭탄설치(5), 폭파(6)로 설정한다. 
		 * 3. 벽(3), 플레이어(2), 폭탄(9), 아이템(4)로 설정한다.
		 * 4. 단, 폭탄이 설치된 순서대로 터져야 하며,
		 *    폭파 시 십자가 형태로 터진다.
		 * 5. 벽 파괴시 아이템이 랜덤하게 생성되어,
		 *    아이템을 먹으면 설치할 수 있는 폭탄의 개수가 증가된다.
		 */
		
		int size=7;
		int[][] map=new int[size][size];
		int bazziy=3;
		int bazzix=3;
		int[] bag=null;
		int bagsize=0;
		
		int wallLimitation=0;
		int wallCheck=0;
		
		int bc=0;
		int[][] temp=new int[size][size];
		
		int[][] yx=new int[10000][2];
		int history=0;
		
		while(true) {
			bagsize=bag==null?0:bag.length;
			// 캐릭터 위치
			map[bazziy][bazzix]=2;
			
			if(history!=0&&bag!=null) {
				map[yx[history-1][0]][yx[history-1][1]]=bag[0];
			}
			System.out.println("가방");
			System.out.println(Arrays.toString(bag));
			
			// 랜덤한 위치에 벽 생성
			if(wallCheck==0) {
				while(true) {
					int wallx=r.nextInt(size);
					int wally=r.nextInt(size);
					if(map[wally][wallx]==0) {
						map[wally][wallx]=3;
						wallLimitation++;
					}
					if(wallLimitation==20) break;
				}
				wallCheck=1;
			}
			
			for(int i=0;i<map.length;i++) {
				System.out.println(Arrays.toString(map[i]));
			}
			
			for(int i=0;i<map.length;i++) {
				for(int j=0;j<map[i].length;j++) {
					if(map[i][j]==2) {System.out.print("[B]");}
					else if(map[i][j]==3) {System.out.print("[■]");}
					else if(map[i][j]==4) {System.out.print("[★]");}
					else if(map[i][j]==9) {System.out.print("[⊙]");}
					else {System.out.print("[ ]");}
				}System.out.println();
			}
			
			System.out.println("[캐릭터를 조작하다]");
			System.out.printf("[W] 위로 이동 [S] 아래쪽으로 이동 [A] 왼쪽으로 이동 [D] 오른쪽으로 이동 [Q] 폭탄설치 [R] 폭파\n");
			String menu=s.nextLine();

			// 게임판 초기화
//			for(int i=0;i<map.length;i++) {
//				for(int j=0;j<map[i].length;j++) {
//					map[i][j]=0;
//				}
//			}
			// 배찌 현위치 제거
			map[bazziy][bazzix]=0;
			
			
			
			// 예외처리
			boolean check=menu.equalsIgnoreCase("w")||menu.equalsIgnoreCase("s")||menu.equalsIgnoreCase("a")||menu.equalsIgnoreCase("d")||menu.equalsIgnoreCase("q")||menu.equalsIgnoreCase("r")?true:false;
			if(check==false) {System.err.println("err");continue;}
			
			// 플레이
			if(check==true) {
				if(menu.equalsIgnoreCase("w")) {
					if(bazziy>0&&map[bazziy-1][bazzix]!=3) {bazziy--;}
				}
				else if(menu.equalsIgnoreCase("s")) {
					if(bazziy<map.length-1&&map[bazziy+1][bazzix]!=3) {bazziy++;}
				}
				else if(menu.equalsIgnoreCase("a")) {
					if(bazzix>0&&map[bazziy][bazzix-1]!=3) {bazzix--;}
				}
				else if(menu.equalsIgnoreCase("d")) {
					if(bazzix<map.length-1&&map[bazziy][bazzix+1]!=3) {bazzix++;}
				}
				else if(menu.equalsIgnoreCase("q")) {
					// 이전 배찌 위치에 폭탄을 심다.
					yx[history][0]=bazziy;
					yx[history][1]=bazzix;
					history++;
					
					// 가방 늘림
					if(bag==null) {bag=new int[1];}
					else {
						int[] tempor=new int[bagsize+1];
						for(int i=0;i<bagsize;i++) {tempor[i]=bag[i];}
						bag=tempor;
						temp=null;
					}
					bag[bagsize]=9;
					
					System.out.println("[폭탄 설치 완료.]");
					bc++;
				}
				else if(menu.equalsIgnoreCase("r")) {
					if(bc==0) {System.out.println("설치된 폭탄이 없다.");continue;}
					// 폭탄이 터지다
					map[yx[0][0]][yx[0][1]]=0;
					for(int i=0;i<map.length;i++) {
						if(map[i][yx[0][1]]==3) {
							int item=r.nextInt(3)+1;
							if(item==3) {map[i][yx[0][1]]=4;}
						}
						if(map[yx[0][0]][i]==3) {
							int item=r.nextInt(3)+1;
							if(item==3) {map[yx[0][0]][i]=4;}
						}
					}
					for(int i=0;i<map.length;i++) {
						if(map[i][yx[0][1]]==3) {map[i][yx[0][1]]=0;}
						if(map[yx[0][0]][i]==3) {map[yx[0][0]][i]=0;}
					}
					
					// 가방 줄임
					int[] tempor=new int[bagsize-1];
					int tidx=0;
					for(int i=0;i<bagsize;i++) {
						if (i!=0) {
							tempor[tidx]=bag[i];
							tidx++;
						}
					}
					bag=tempor;
					tempor=null;
					
					// 폭탄 히스토리없앰
					for(int i=0;i<history-1;i++) {
						yx[i]=yx[i+1];
					}
					yx[history-1]=new int[2];
					history--;
					bc--;
				}
			}
//			for(int i=0;i<yx.length;i++) {
//				System.out.println(Arrays.toString(yx[i]));
//			}
			System.out.println("히스토리 : "+history);
			
		}
		
		
		
		
		
	}

}
