package day34;

import java.util.Arrays;

public class mineptc {

	public static void main(String[] args) {

//		int[][] mine = {
//				{0,9,0,9},
//			    {9,0,9,0},
//			    {9,9,9,0},
//			    {0,0,9,0}
//		    };
//			
//		for(int i =0; i< mine.length;i++) {
//			for(int k =0; k < mine[i].length;k++) {
//	
//				int dir =0; 
//				int cnt =0;
//				while(mine[i][k]==0) {
//					
//					int y = i;
//					int x = k;
//					//System.out.printf("x = %d y = %d dir =%d \n" , x , y, dir);
//					if (dir == 0) {// 북쪽
//						y--;
//					} else if (dir == 1) {// 동쪽
//						x++;
//					} else if (dir == 2) {// 남쪽
//						y++;
//					} else if (dir == 3) {// 서쪽
//						x--;
//					} else if (dir == 4) {// 북서쪽
//						y--;
//						x++;
//					} else if (dir == 5) {// 북동쪽
//						y--;
//						x++;
//					} else if (dir == 6) {// 남동쪽
//						y++;
//						x++;
//					} else if (dir == 7) {// 남서쪽
//						y++;
//						x--;
//					}else {
//						mine[i][k] = cnt;
//						break;
//					}
//					dir++;
//					
//					if(x <0 || y < 0 || x>= mine.length || y>= mine.length) {
//						continue;
//					}
//					
//					if(mine[y][x] == 9) {
//						cnt++;
//					}
//					
//				}
//				
//			}
//	
//		}
//		
//		for(int i =0; i< mine.length;i++) {
//			System.out.println(Arrays.toString(mine[i]));
//		}
		
		
		
		
		
		int [][]mine =	{
				{0,9,0,9},
			    {9,0,9,0},
			    {9,9,9,0},
			    {0,0,9,0}
		};
		
		int[] x={-1,0,1,-1,1,-1,0,1};
		int[] y={-1,-1,-1,0,0,1,1,1};
		int k=0;
		int tx=0 ; 
		int ty=0;
		int cnt=0;
		
		for(int i=0;i<mine.length;i++) {
			for(k=0;k<mine[i].length;k++) {
				int mod=-1;
				if(mine[i][k]==0) {
					mod=1;
				}
				if(mod==1) {
					cnt=0;
					for (int m=0;m< x.length; m++) {
						 tx=k+x[m];
						 ty=i+y[m];
						 if(tx>-1&&ty>-1&&tx<mine.length&&ty<mine.length){	
							 if(mine[ty][tx] == 9) {
								System.out.println(i+" "+k);
								System.out.println("="+tx+" "+ty);
								cnt++;
							 }
						 }
					}	
						mine[i][k] = cnt;
				}
			}
		}
		for(int i=0;i<mine.length;i++) {
			System.out.println(Arrays.toString(mine[i]));
		}
		
	}

}
