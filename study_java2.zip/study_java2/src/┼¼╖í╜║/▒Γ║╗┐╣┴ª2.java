package 클래스;

import java.util.Arrays;
import java.util.Scanner;

//기본메모리그림3 에 있는 sample03 클래스를 이용하세요 
//class Sample03 {
//	int[] hakbun = {1001, 1002, 1003, 1004, 1005};
//	int[] score  = {  92,   38,   87,  100,   11};
//}


public class 기본예제2 {

	public static void main(String[] args) {

		// 문제1) scores배열에 1~100점 사이의 정수를 5개 저장
		// 예 1) 92, 38, 87,100, 11

		// 문제2) 전교생의 총점과 평균 출력
		// 예 2) 총점(251) 평균(50.2)

		// 문제3) 성적이 60점 이상이면 합격. 합격생 수 출력
		// 예 3) 2명

		// 문제4) 인덱스를 입력받아 성적 출력
		// 정답4) 인덱스 입력 : 1 성적 : 11점

		// 문제5) 성적을 입력받아 인덱스 출력
		// 정답5) 성적 입력 : 11 인덱스 : 1

		// 문제6) 학번을 입력받아 성적 출력
		// 정답6) 학번 입력 : 1003 성적 : 92점

		// 문제7) 학번을 입력받아 성적 출력
		// 단, 없는학번 입력 시 예외처리
		// 예 7)
		// 학번 입력 : 1002 성적 : 11점
		// 학번 입력 : 1000 해당학번은 존재하지 않습니다.

		// 문제8) 1등학생의 학번과 성적 출력
		// 정답8) 1003번(92점)
		
		Scanner s=new Scanner(System.in);
		Sample03 a=new Sample03();
		
		int[] scores=new int[5];
		int[] hakbuns=new int[5];
		
		// Q1 solution
		System.out.println("Q1");
		scores=a.score;
		hakbuns=a.hakbun;
		System.out.println(Arrays.toString(scores));
		
		// Q2 solution
		System.out.println("Q2");
		int sum=0;
		for(int i=0;i<scores.length;i++) {
			sum+=scores[i];
		}
		double avg=sum/scores.length;
		System.out.println("[총점 : "+sum+"][평군 : "+avg+"]");
		
		// Q3 solution
		System.out.println("Q3");
		int passCnt=0;
		for(int i=0;i<scores.length;i++) {
			if(scores[i]>=60) {passCnt++;}
		}
		System.out.println("[합격자 수 : "+passCnt+"명]");
		
		// Q4 solution
		System.out.println("Q4");
		System.out.print("인덱스를 입력하다 : ");
		int idx=s.nextInt();
		for(int i=0;i<scores.length;i++) {
			if(i==idx) {System.out.println("[인댁스 "+i+"번 학생의 점수는 "+scores[i]+"점]");break;}
		}
		
		// Q5 solution
		System.out.println("Q5");
		System.out.print("성적을 입력하다 : ");
		int jumsoo=s.nextInt();
		for(int i=0;i<scores.length;i++) {
			if(jumsoo==scores[i]) {System.out.println("["+jumsoo+"점 받은 학생의 인댁스넘버는 "+i+"번]");break;}
		}
		
		// Q6 solution
		System.out.println("Q6");
		System.out.print("학번을 입력하다 : ");
		int stuNum=s.nextInt();
		for(int i=0;i<hakbuns.length;i++) {
			if(stuNum==hakbuns[i]) {System.out.println("[학번이 "+stuNum+"인 학생의 점수는 "+scores[i]+"점]");break;}
		}
		
		// Q7 solution
		System.out.println("Q7");
		int check=1;
		System.out.print("학번을 입력하다 : ");
		stuNum=s.nextInt();
		for(int i=0;i<hakbuns.length;i++) {
			if(stuNum==hakbuns[i]) {check=2;}
		}
		if(check==2) {
			for(int i=0;i<hakbuns.length;i++) {
				if(stuNum==hakbuns[i]) {System.out.println("[학번이 "+stuNum+"인 학생의 점수는 "+scores[i]+"점]");break;}
			}
		}
		else {System.err.println("err");}
		
		// Q8 solution
		System.out.println("Q8");
		int max=0;
		idx=0;
		for(int i=0;i<scores.length;i++) {
			if(scores[i]>max) {idx=i;max=scores[i];}
		}
		System.out.println("[1등 학생의 학번은 "+hakbuns[idx]+"이고 점수는"+max+"점이다.]");
	}

}