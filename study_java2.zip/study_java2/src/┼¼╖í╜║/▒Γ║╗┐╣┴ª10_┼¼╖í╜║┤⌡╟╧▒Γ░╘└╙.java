package 클래스;

/*
 * # 더하기 게임
 * 1. 1부터 10 사이의 랜덤한 값을 중복 없이 game 배열에 6개 저장한다.
 * 2. 6개의 배열의 인덱스를 0부터 5사이의 랜덤 값 3개를 중복 없이 선택해 
       그 인덱스의 값 의 합을 출력한다. 
 * 3. 사용자는 중복없이 3개의 인덱스를 골라 그 합을 맞추는 게임이다.
*  예)  4, 7, 5, 3, 2, 9  //   문제:  14   ==> 인덱스 3개를 골라서 합을 맞추면된다.  
    정답)  3,4,5 (여러가지 경우의 수가 나올수는있다)
 */

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class AddingGame{
	int[] game = new int[6];
	int[] idx = new int[3];
	int[] myIdx = new int[3];	
	int total = 0;
}

public class 기본예제10_클래스더하기게임 {

	public static void main(String[] args) {

		Random r=new Random();
		AddingGame g=new AddingGame();
		Scanner s=new Scanner(System.in);
		
		for(int i=0;i<g.game.length;i++) {
			g.game[i]=r.nextInt(10)+1;
			for(int j=0;j<i;j++) {
				if(g.game[i]==g.game[j]) {i--;break;}
			}
		}
		
		for(int i=0;i<g.idx.length;i++) {
			g.idx[i]=r.nextInt(5);
			for(int j=0;j<i;j++) {
				if(g.idx[i]==g.idx[j]) {i--;break;}
			}
		}
		System.out.println(Arrays.toString(g.game));
		System.out.println(Arrays.toString(g.idx));
		int ans=0;
		for(int i=0;i<g.idx.length;i++) {
			ans+=g.game[g.idx[i]];
		}
		System.out.println(ans+"은(는) 위 배열에서 뭐랑 뭐랑 뭐를 합한 숫자인가");
		
		int a=0;
		int b=0;
		int[] temp=new int[g.myIdx.length+1];
		while(true) {
			System.out.print("인댁스를 입력하다 "+(a+1)+")");
			int num=s.nextInt();
			if(num>5||num<0) {System.out.println("err");continue;}
			
			int check=0;
			if(a==0) {g.myIdx[a]=num;a++;}
			else {
				for(int i=0;i<a;i++) {
					if(num==g.myIdx[i]) {check=1;}
				}
				if(check!=0) {System.out.println("err");continue;}
				else {g.myIdx[a]=num;a++;}
			}
			if(a==3) {break;}
		}
		
		int sum=0;
		for(int i=0;i<g.idx.length;i++) {
			sum+=g.game[g.myIdx[i]];
		}
		
		System.out.println(ans==sum?"정답.":"오답.");
	}

}
