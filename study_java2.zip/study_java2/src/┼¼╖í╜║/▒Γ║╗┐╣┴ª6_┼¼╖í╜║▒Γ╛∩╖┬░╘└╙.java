package 클래스;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

/*
 * # 기억력 게임 : 클래스 + 변수
 * 1. front 배열 카드 10장을 섞는다.
 * 2. front 배열에서 같은 카드를 골라 카드의 위치를 입력한다.
 * 3. 선택한 2장의 카드가 같은 카드이면, back 배열에 표시한다.
 * 4. 모든 카드가 뒤집히면(back배열의 0이 사라지면) 게임은 종료된다. 
 */

class MemoryGame{
	String[] front = {"O", "O","□", "□", "■", "■", "☎", "☎", "♠", "♠"};
	String[] back = new String[10];
	
	int cnt = 0;		// 정답을 맞춘 횟수
}

public class 기본예제6_클래스기억력게임 {

	public static void main(String[] args) {

		MemoryGame m=new MemoryGame();
		Scanner s=new Scanner(System.in);
		Random r=new Random();
		
		String temp="";
		for(int i=0;i<50;i++) {
			int shuf=r.nextInt(9);
			temp=m.front[0];
			m.front[0]=m.front[shuf];
			m.front[shuf]=temp;
		}
//		System.out.println(Arrays.toString(m.front));
		
		int[] card=new int[m.front.length];
		while(true) {
			int cIdx=0;
			for(String i:m.front) {
				if(card[cIdx]==0) {System.out.print("[ ]");}
				else {System.out.print("["+i+"]");}
				cIdx++;
			}
			System.out.println();
			
			int cardFlip=0;
			int a=0;
			int b=0;
			while(true) {
				System.out.print("인댁스를 입력하여 카드를 뒤집다.");
				int flip=s.nextInt();
				if(flip>9||flip<0) {System.err.println("err");continue;}
				if(card[flip]!=0) {System.err.println("err");continue;}
				
				cIdx=flip;
				card[cIdx]=1;
				cardFlip++;
				if(cardFlip==1) {a=cIdx;}
				if(cardFlip==2) {b=cIdx;}
				cIdx=0;
				for(String i:m.front) {
					if(card[cIdx]==0) {System.out.print("[ ]");}
					else {System.out.print("["+i+"]");}
					cIdx++;
				}
				System.out.println();
				if(cardFlip==2) {
					if(m.front[a].equals(m.front[b])) {m.back[a]="checked";m.back[b]="checked";m.cnt+=2;}
					else {card[a]=0;card[b]=0;}
					break;
				}
			}
			System.out.println("===============================");
			System.out.println();
			
			if(m.back.length==m.cnt) {break;}
		}
	}

}
