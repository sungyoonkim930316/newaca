package 클래스;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class Game1to50{
	final int SIZE = 25;	
	int[] front = new int[SIZE];
	int[] back  = new int[SIZE];	
}

public class 기본예제8_클래스1to50 {

	public static void main(String[] args) {

		Random r=new Random();
		Scanner s=new Scanner(System.in);
		Game1to50 g=new Game1to50();
		
		int idx=0;
		int[] check=new int[g.SIZE];
		while(idx!=g.SIZE) {
			int num=r.nextInt(g.SIZE)+1;
			if(check[num-1]==1) {continue;}
			check[num-1]=1;
			g.front[idx]=num;
			idx++;
		}
		
		idx=0;
		check=new int[g.SIZE];
		while(idx!=g.SIZE) {
			int num=r.nextInt(g.SIZE)+g.SIZE+1;
			if(check[num-g.SIZE-1]==1) {continue;}
			check[num-g.SIZE-1]=1;
			g.back[idx]=num;
			idx++;
		}
		
		int play=1;
		int cnt=0;
		
		System.out.println("타이머 시작");

		long beforeTime = System.currentTimeMillis(); //코드 실행 전에 시간 받아오기 : 밀리세컨드 단위 1초 ==  1000
		for(int k =0; k < 1000000;k++){
			while(true) {
				for(int i=0;i<g.front.length;i++) {
					System.out.printf("[%2d] ",g.front[i]);
					if(i>0&&i%5==4) {System.out.println();}
				}
				
				System.out.println("블럭을 찍다");
				int cell=s.nextInt();
				for(int i=0;i<g.front.length;i++) {
					if(g.front[cell-1]==play) {
						g.front[cell-1]=g.back[cell-1];
						g.back[cell-1]=0;
						play++;
					}
					else {break;}
				}
				System.out.println(play);
				
				for(int i=0;i<g.front.length;i++) {
					if(g.front[i]==0) {cnt++;}
				}
				if(cnt<25) {cnt=0;}
				else {System.out.println("게임종로");break;}
			}
			break;
		}
		long afterTime = System.currentTimeMillis(); // 코드 실행 후에 시간 받아오기
		double secDiffTime = (afterTime - beforeTime) / 1000.0; //두 시간에 차 계산

		System.out.println("타이머 끝 : " + secDiffTime);
		
		
		
	}

}
