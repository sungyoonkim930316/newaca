package 클래스;

import java.util.Arrays;
import java.util.Scanner;

class GameLadder {
	int ladder[][] = {
		{ 0, 0, 0, 0, 0 }, 
		{ 1, 1, 0, 1, 1 }, 
		{ 0, 0, 0, 0, 0 }, 
		{ 0, 0, 1, 1, 0 }, 
		{ 1, 1, 0, 1, 1 },
		{ 0, 1, 1, 0, 0 }, 
		{ 0, 0, 1, 1, 0 },
		{ 0, 0, 0, 1, 1 }, 
		{ 0, 0, 0, 0, 0 } 
	};

	int x = 0;
	int y = 0;
	String[] menu = { "죠스떡볶이", "CU편의점라면", "마라탕", "김밥천국", "명인만두" };
}

// System.out.print(" │ ");
// System.out.print("─┤ ");
// System.out.print(" ├─");

public class 기본예제9_클래스사다리 {

	public static void main(String[] args) {

		GameLadder g=new GameLadder();
		Scanner s=new Scanner(System.in);
		
		System.out.println("사다리 게임");
		for(int i=0;i<g.ladder.length;i++) {
			for(int j=0;j<g.ladder[i].length;j++) {
				int[] check=new int[2];
				if(g.ladder[i][j]==0) {System.out.print(" │ ");}
				if(g.ladder[i][j]==1) {
					check[0]=j<=0?-1:g.ladder[i][j-1];
					check[1]=j>=g.ladder[i].length-1?-1:g.ladder[i][j+1];
					if(check[0]==1) {System.out.print("─┤ ");}
					else if(check[1]==1) {System.out.print(" ├─");}
				}
				
			}System.out.println();
		}
		
		int cnt=0;
		for(int i=0;i<g.menu.length;i++) {
			if(g.menu[i].length()>cnt) {cnt=g.menu[i].length();}
		}
		
		String[][] vert=new String[cnt][g.menu.length];
		int wordCnt=0;
		for(int i=0;i<vert.length;i++) {
			for(int j=0;j<vert[i].length;j++) {
				if(g.menu[j].length()>wordCnt) {
					vert[i][j]=String.valueOf((g.menu[j].charAt(wordCnt)))+" ";
				}
				else {vert[i][j]="  ";;}
				System.out.print(vert[i][j]+" ");
			}
			wordCnt++;
			System.out.println();
		}
		System.out.println();
		System.out.print("시작점 인댁스를 입력하다");
		int start=s.nextInt();
		if(start>4||start<0) {System.err.println("err");}
		
		for(int i=0;i<g.ladder.length-1;i++) {
			int[] check=new int[2];
			if(g.ladder[i+1][start]==1) {
				check[0]=start<=0?-1:g.ladder[i+1][start-1];
				check[1]=start>=g.ladder[i].length-1?-1:g.ladder[i+1][start+1];
				if(check[0]==1) {start--;}
				else if(check[1]==1) {start++;}
			}
		}
		System.out.println("오늘밥 : "+g.menu[start]+" ");
		s.close();
		
	}

}
