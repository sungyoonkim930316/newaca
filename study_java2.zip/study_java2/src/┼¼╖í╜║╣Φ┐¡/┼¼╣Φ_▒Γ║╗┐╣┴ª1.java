package 클래스배열;

import java.util.Arrays;

//class Student{
//int number;
//String id;
//String pw;
//String name="무명이";
//int score;
//}

public class 클배_기본예제1 {

	public static void main(String[] args) {

//		String data = "";
//		data += "1001,qwer,1234,김철민,10\n";
//		data += "1002,asdf,2345,우중현,3\n";
//		data += "1003,zxcv,3456,이만수,30";
//		
//		String[] temp=data.split("\n");
//		
//		String studentList[][] = new String[3][5];
//		for(int i=0;i<3;i++) {
//			String[] temp2=new String[1];
//			temp2[0]=temp[i];
//			studentList[i]=temp2;
//		}
//		for(int i=0;i<studentList.length;i++) {
//			System.out.println(Arrays.toString(studentList[i]));
//		}
//		
//	    // stList 클래스배열에 데이터를 넣고 1등 출력 
//		
//		Student[] stList = new Student[3];
//		for(int i=0;i<stList.length;i++) {
//			Student st=new Student();
//			st.number=Integer.parseInt(studentList[i][0]);
//			st.id=studentList[i][1];
//			st.pw=studentList[i][2];
//			st.name=studentList[i][3];
//			st.score=Integer.parseInt(studentList[i][4]);
//			stList[i]=st;
//		}
//		
//		for(int i=0;i<stList.length;i++) {
//			System.out.println("학번 : "+stList[i].number);
//			System.out.println("id : "+stList[i].id);
//			System.out.println("pw : "+stList[i].pw);
//			System.out.println("이름 : "+stList[i].name);
//			System.out.println("점수 : "+stList[i].score);
//			System.out.println("=================");
//		}
		
		String data = "";
		// info  0      1    2   3   4
		data += "1001,qwer,1234,김철민,10\n";
		data += "1002,asdf,2345,우중현,3\n";
		data += "1003,zxcv,3456,이만수,30";
		
	    // stList 클래스배열에 데이터를 넣고 1등 출력 
		
//		System.out.println(data);
		
		String temp[] = data.split("\n");
		System.out.println(temp.length);
//		System.out.println(temp[0]);
		
		int size = temp.length;
		Student[] stList = new Student[size];
		
		for(int i =0; i< temp.length;i++) {
			String info[] = temp[i].split(","); // [1001, qwer, 1234, 김철민, 10]
			System.out.println(Arrays.toString(info));
			
			// 학생을 만든다
			Student s = new Student();
			// 학생에 데이터 넣어주고 
			s.number = Integer.parseInt(info[0]);
			s.id = info[1];
			s.pw = info[2];
			s.name = info[3];
			s.score = Integer.parseInt(info[4]);
			// 만든 학생을 학생배열에 넣어준다
			stList[i] = s;
			
		}
		System.out.println(Arrays.toString(stList));
		System.out.println(stList[0].score);
		System.out.println();
		int max = 0;
		int maxIdx =0;
		
		for(int i =0; i <size; i++) {
			if(max < stList[i].score) {
				max = stList[i].score;
				maxIdx = i;
			}
		}
		
//		int idx =0;
//		for(Student s : stList) {
//			// System.out.println(s.name);
//			if(max < s.score) {
//				max = s.score;
//				maxIdx = idx;
//			}
//			idx++;
//		}
		System.out.println(max);
		
		System.out.println("1등 학생 = " + stList[maxIdx].name);
		
//		for(Student s : stList) {
//			if(max == s.score) {
//				System.out.println("1등 학생 = " + s.name);
//				break;
//			}
//		}
		
		
	}

}