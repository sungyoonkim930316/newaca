package 클래스배열;

import java.util.Arrays;
import java.util.Scanner;

class Subject{
	int stuNum; // 학번 Student 클래스의 number 랑 같은 값 
	String name;// 과목 이름 
	int score; // 과목 점수
	int rank;// 그 과목 등수 
}

public class 클배_기본예제_2 {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);	
		
		// 기존에 있는 Student 클래스 학번 이름 점수(총합 )
		String studentSample = "1001/이만수\n";
		studentSample += "1002/김철만\n";		
		studentSample += "1003/오수정\n";
		
		String subjectSample = "";
		subjectSample += "1001/국어/100/0\n";
		subjectSample += "1001/수학/32/0\n";
		subjectSample += "1002/국어/23/0\n";
		subjectSample += "1002/수학/35/0\n";
		subjectSample += "1002/영어/46/0\n";
		subjectSample += "1003/수학/60/0";	
		
		//문제1) 위 샘플문자열들을 각각 해당 클래스배열에 저장후 출력		
		
		String temp[]=studentSample.split("\n");
		int size=temp.length;
		Student[] stList=new Student[size];
		
		for(int i=0;i<size;i++) {
			String[] info=temp[i].split("/");
			System.out.println(Arrays.toString(info));
			
			Student s=new Student();
			s.number=Integer.parseInt(info[0]);
			s.name=info[1];
//			s.score=Integer.parseInt(info[4]);
			stList[i]=s;
		}
		
		
//		for(int i=0;i<size;i++) {
//			String[] info=temp[i].split("/");
//			System.out.println(Arrays.toString(info));
//			
//			stList[i] =new Student();
//			stList[i].number=Integer.parseInt(info[0]);
//			stList[i].name=info[1];
////			s.score=Integer.parseInt(info[4]);
//		}
		System.out.println("=====================");
		
		temp=subjectSample.split("\n");
		size=temp.length;
		Subject[] subList=new Subject[size];
		for(int i=0;i<size;i++) {
			String info[]=temp[i].split("/");
			System.out.println(Arrays.toString(info));
			
			Subject sub = new Subject();
			sub.stuNum=Integer.parseInt(info[0]);
			sub.name=info[1];
			sub.score=Integer.parseInt(info[2]);
			sub.rank=Integer.parseInt(info[3]);
			subList[i]=sub;
		}
		System.out.println("=====================");
		
		
		//문제1) 점수가 59점이하인 과목은 전부 삭제후 다시 문자열로 저장후 출력 
		int cnt=0;
		for(int i=0;i<subList.length;i++) {
			if(subList[i].score<60) {subList[i]=null;}
			else cnt++;
		}
		String ans="";
		for(int i=0;i<subList.length;i++) {
			if(subList[i]!=null) {
				ans+=subList[i].stuNum+"/"+subList[i].name+"/"+subList[i].score+"/"+subList[i].rank+"\n";
			}
		}
		System.out.println(ans);
		
	}

}