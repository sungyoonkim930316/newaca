package 클래스배열;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 클배_기본예제2 {

	public static void main(String[] args) {

		int max=10;
		Student[] stList=new Student[max];
		for(int i=0;i<max;i++) {
			stList[i]=new Student();
		}
		int cnt=0; // 현재 생성한 학생 숫자 
		
		Scanner s=new Scanner(System.in);
		Random r=new Random();
		
		String studentList[][] = new String[max][];
		
		while(true) {
//			cnt=stList==null?0:stList.length;
			int num=1001+cnt;
			System.out.println("[1]학생추가 [2]학생삭제 [3]수정 [4]검색 [5] 전체출력 [0]종료");
			
			int sel=s.nextInt();
			if(sel==0) {
				break;
			}
			else if(sel==1) {
				// 추가
				// 최대학번 + 1 로 자동으로 학번값 넣어주기 : 학번은 입력받지 않는다
				// 이름 아이디(중복 금지) 비번 점수(30-100 랜덤하게 가져오기 )
				Student st = new Student();
				System.out.print("아이디");
				String id=s.next();
				st.id=id;
				System.out.print("비밀번호");
				String pwd=s.next();
				st.pw=pwd;
				System.out.print("이름");
				String name=s.next();
				st.name=name;
				st.number=num;
				st.score=r.nextInt(71)+30;
				stList[cnt]=st;
				System.out.println(stList[cnt]);
				cnt++;
				
				System.out.println("학생 추가 완료");
			}
			else if(sel==2) {
				// 삭제 아이디 검색해서 삭제
				System.out.println("삭제할 아이디 입력");
				String del=s.next();
				System.out.println(stList[0].id);
				for(int i =0;i<max-1;i++) {
					if(del.equals(stList[i].id)) {
						stList[i]=stList[i+1];
					}
				}
				cnt--;
			}
			else if(sel==3) {
				// 수정 학번으로 검색 => 점수 수정
				System.out.println("점수 수정할 학번 입력");
				int upd=s.nextInt();
				for(int i =0;i<max;i++) {
					if(upd==stList[i].number) {
						System.out.println(stList[i].score);
						System.out.println("점수 수정");
						int newScore=s.nextInt();
						stList[i].score=newScore;
						System.out.println("수정완료");
						System.out.println(stList[i].score);
					}
				}
			}
			else if(sel==4) {
				//검색 ->  이름으로 검색 , 학번 점수 출력 (동명이인 일경우까지 생각)
				System.out.println("이름 입력");
				String name=s.next();
				for(int i =0;i<max;i++) {
					if(name.equals(stList[i].name)) {
						System.out.println(stList[i].number);
						System.out.println(stList[i].score);
					}
				}
			}
			else if(sel==5) {
				for(int i=0;i<cnt;i++) {
					System.out.println(stList[i].number);
					System.out.println(stList[i].id);
					System.out.println(stList[i].pw);
					System.out.println(stList[i].name);
					System.out.println(stList[i].score);
				}
			}
		}
		
	}

}
