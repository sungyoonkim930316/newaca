package 클래스배열;

import java.util.Arrays;
import java.util.Scanner;

public class 클배_기본예제4 {

	public static void main(String[] args) {

		Scanner scan=new Scanner(System.in);
		
		String stuData = "1001/이만수\n";
		stuData += "1002/김철만\n";		
		stuData += "1003/오수정\n";
		
		String subData = "";
		subData += "1001/국어/100\n";
		subData += "1001/수학/32\n";
		subData += "1002/국어/23\n";
		subData += "1002/수학/35\n";
		subData += "1002/영어/46\n";
		subData += "1003/수학/60";	
		
		String[] temp=stuData.split("\n");
		String[] temp2=subData.split("\n");
		int size=temp.length;
		int size2=temp2.length;
		Student[] stList=new Student[size];
		Subject[] subList=new Subject[size2];
		
		int idx=0;
		for(Student stu:stList) {
			String[] info=temp[idx].split("/");
			stu=new Student();
			stu.number=Integer.parseInt(info[0]);
			stu.name=info[1];
			stList[idx]=stu;
			idx++;
		}
		
		idx=0;
		for(Subject sub:subList) {
			String[] info=temp2[idx].split("/");
			sub=new Subject();
			sub.stuNum=Integer.parseInt(info[0]);
			sub.name=info[1];
			sub.score=Integer.parseInt(info[2]);
			sub.rank=0;
			subList[idx]=sub;
			idx++;
		}
		
		for(int i=0;i<stList.length;i++) {
			int sum=0;
			for(int j=0;j<subList.length;j++) {
				if(stList[i].number==subList[j].stuNum) {sum+=subList[j].score;}
			}
			stList[i].score=sum;
		}
		
		
		while(true) {
			System.out.println("[0] 종료 ");
			System.out.println("[1] 학생 정보 출력 ");
			System.out.println("[2] 과목 정보 출력 ");
			System.out.println("[3] 과목별 랭킹 저장 ");
			System.out.println("[4] 과목별 랭킹 + 이름 출력");
			System.out.println("[5] 과목별 랭킹 1등의 이름 과목 점수 출력 ");
			System.out.println("[6] 학생별 평균 점수 높은순으로 이름 점수 출력 ");
			
			int sel=scan.nextInt();
			if(sel==0) {
				break;
			}
			else if(sel==1) {
				System.out.println("학번  이름  총점");
				System.out.println("===============");
				for(int i=0;i<stList.length;i++) {
					System.out.println(stList[i].number+" "+stList[i].name+" "+stList[i].score);
				}
				System.out.println("===============");
			}
			else if(sel==2) {
				System.out.println("학번  과목 점수 렝킹");
				System.out.println("===============");
				for(int i=0;i<subList.length;i++) {
					System.out.println(subList[i].stuNum+" "+subList[i].name+" "+subList[i].score+" "+subList[i].rank);
				}
				System.out.println("===============");
			}
			else if(sel==3) {
				
				for(int i=0;i<subList.length;i++) {
					int rank=1;
					for(int j=0;j<subList.length;j++) {
						if(subList[i].name.equals(subList[j].name)) {
							if(subList[i].score<subList[j].score) rank++;
						}
					}
					subList[i].rank=rank;
				}
				System.out.println("렝킹등록 완료.");
				
			}
			else if(sel==4) {
				System.out.println("학번\t과목\t점수\t랭킹\t이름");
				System.out.println("=====================================");
				for(int i=0;i<subList.length;i++) {
					int hak=0;
					for(int j=0;j<stList.length;j++) {
						if(subList[i].stuNum==stList[j].number) {hak=j;}
					}
					System.out.print(subList[i].stuNum+"\t"+subList[i].name+"\t"+subList[i].score+"\t"+subList[i].rank+"\t");
					System.out.println(stList[hak].name);
				}
				
			}
			else if(sel==5) {
				System.out.println("학번\t과목\t점수\t랭킹\t이름");
				System.out.println("=====================================");
				for(int i=0;i<subList.length;i++) {
					if(subList[i].rank==1) {
						int hak=0;
						for(int j=0;j<stList.length;j++) {
							if(subList[i].stuNum==stList[j].number) {hak=j;}
						}
						System.out.print(subList[i].stuNum+"\t"+subList[i].name+"\t"+subList[i].score+"\t"+subList[i].rank+"\t");
						System.out.println(stList[hak].name);
					}
				}
				
			}
			else if(sel==6) {
				System.out.println("학번\t이름\t총점\t평군점수");
				System.out.println("=====================================");
				for(int i=0;i<stList.length;i++) {
					double cnt=0;
					for(int j=0;j<subList.length;j++) {
						if(stList[i].number==subList[j].stuNum) {
							cnt++;
						}
					}
					System.out.print(stList[i].number+"\t"+stList[i].name+"\t"+stList[i].score+"\t");
					System.out.printf("%.2f\n",stList[i].score/cnt);
				}
			}
		}
		
	}

}
