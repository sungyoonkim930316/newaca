package day35;

import java.util.Arrays;
import java.util.Scanner;

public class 클배장바구니2 {

	public static void main(String[] args) {

String[] userIdList = {"aaa" , "bbb" , "ccc"};
		
		String[] itemNameList={"사과" , "칸초" , "귤" , "감"};
		int [] itemPriceList={10000, 2000, 6500, 3300};
		
		String[] cartUserIdList={"aaa" , "ccc" , "aaa" , "bbb" , "aaa" ,"ccc"};
		String[] cartItemNameList={"칸초" , "귤" , "칸초" , "사과" , "감" ,"사과"};
		
		// 우저 리스트에 값넣음
		User[] userList=new User[userIdList.length];
		for(int i=0;i<userList.length;i++) {userList[i]=new User();userList[i].id=userIdList[i];}
		
		// 아이템 리스트에 값넣음
		Item[] itemList=new Item[itemNameList.length];
		for(int i=0;i<itemList.length;i++) {itemList[i]=new Item();itemList[i].name=itemNameList[i];itemList[i].price=itemPriceList[i];}
		
		// 카트 리스트에 값 넣음
		Cart[] cartList=new Cart[cartUserIdList.length];
		for(int i=0;i<cartList.length;i++) {cartList[i]=new Cart();cartList[i].userId=cartUserIdList[i];cartList[i].itemName=cartItemNameList[i];}
		
		Scanner s=new Scanner(System.in);
		
		while(true) {
			System.out.println("[0] 종료\n"
					+ "[1] 전체출력\n"
					+ "[2] 회원 aaa가 주문한 각 아이템이름과 가격들을 출력 \n"
					+ "[3] 카트내용을 전부출력(회원 별 아이템 전체와 아이템 가격을 출력)\n"
					+ "[4] 주문한 아이템 갯수가 가장많은 회원출력\n"
					+ "[5] 주문한 아이템 총액이 가장큰 회원출력");
			int sel=s.nextInt();
			if(sel==0) {
				break;
			} 
			else if(sel==1) {
				System.out.println("userList========");
				for(int i=0;i<userList.length;i++) {System.out.print("["+userList[i].id+"]");}
				System.out.println("\n\nitemList========");
				for(int i=0;i<itemList.length;i++) {System.out.print("["+itemList[i].name+"]");System.out.println("["+itemList[i].price+"]");}
				System.out.println("\ncartList========");
				for(int i=0;i<cartList.length;i++) {System.out.print("["+cartList[i].userId+"]");System.out.println("["+cartList[i].itemName+"]");}
				System.out.println();
			} 
			else if(sel==2) {
				System.out.println("회원 aaa가 주문한 각 아이템이름과 가격들 ");
				String pk="";
				for(int i=0;i<userList.length;i++) {
					if(userList[i].id.equalsIgnoreCase("aaa")) pk=userList[i].id;
				}
				
				for(int i=0;i<cartList.length;i++) {
					if(cartList[i].userId.equalsIgnoreCase(pk)) {
						int itemPrice=0;
						for(int j=0;j<itemList.length;j++) {
							if(cartList[i].itemName.equals(itemList[j].name)) itemPrice=itemList[j].price;
						}
						System.out.println("아이탬"+(i+1)+" : "+cartList[i].itemName+"\t"+itemPrice+"원");
					}
				}
			} 
			else if(sel==3) {
				System.out.println("================");
				for(int i=0;i<userList.length;i++) {
					String pk=userList[i].id;
					System.out.println("회원 "+pk+"의 장바구니");
					System.out.println("----------------");
					for(int j=0;j<cartList.length;j++) {
						if(cartList[j].userId.equalsIgnoreCase(pk)) {
							int itemPrice=0;
							for(int k=0;k<itemList.length;k++) {
								if(cartList[j].itemName.equals(itemList[k].name)) itemPrice=itemList[k].price;
							}
							System.out.println(cartList[j].itemName+"\t"+itemPrice+"원");
						}
					}
					System.out.println("================");
				}
				
			} 
			else if(sel==4) {
				int max=0;
				int idx=0;
				for(int i=0;i<userList.length;i++) {
					String pk=userList[i].id;
					int cnt=0;
					for(int j=0;j<cartList.length;j++) {
						if(cartList[j].userId.equalsIgnoreCase(pk)) cnt++;
					}
					if(max<cnt) {idx=i;max=cnt;}
				}
				System.out.println("가장 많은 아이템을 주문한 회원 : "+userList[idx].id);
			} 
			else if(sel==5) {
				int max=0;
				int idx=0;
				for(int i=0;i<userList.length;i++) {
					String pk=userList[i].id;
					int priceSum=0;
					for(int j=0;j<cartList.length;j++) {
						if(cartList[j].userId.equalsIgnoreCase(pk)) {
							for(int k=0;k<itemList.length;k++) {
								if(itemList[k].name.equals(cartList[j].itemName)) priceSum+=itemList[k].price;
							}
						}
					}
					if(max<priceSum) {idx=i;max=priceSum;}
				}
				System.out.println("주문한 아이템 총액이 가장큰 회원 : "+max+"원어치 주문한 "+userList[idx].id);
			}
		}
		
	}

}
