package day35;

class User{
	String id;
}

class Item{
	String name;
	int price;
}

class Cart{
	String userId;
	String itemName;
}

public class 클배장바구니1 {

	public static void main(String[] args) {

		String data1 = "qwer/asdf/zxcv";
		String data2 = "새우깡,1200/감자깡,3200/고구마깡,2100";
		String data3 = "qwer,새우깡/qwer,고구마깡/asdf,감자깡/qwer,새우깡/zxcv,새우깡";

		
	
		// [문제] 문자열을 각각의 클래스배열에 저장하고, 회원별로 구매한 상품 총 금액을 출력하시오.
		// 유저리스트
		String[] temp=data1.split("/");
		int size=temp.length;
		User[] userList=new User[size];
		
		for(int i=0;i<userList.length;i++) {
			User us=new User();
			us.id=temp[i];
			userList[i]=us;
		}
		
		// 아이템리스트
		temp=data2.split("/");
		size=temp.length;
		Item[] itemList=new Item[size];
		
		for(int i=0;i<itemList.length;i++) {
			String[] info=temp[i].split(",");
			Item it=new Item();
			it.name=info[0];
			it.price=Integer.parseInt(info[1]);
			itemList[i]=it;
		}
		
		// 카트리스트
		temp=data3.split("/");
		size=temp.length;
		Cart[] cartList=new Cart[size];
		
		for(int i=0;i<cartList.length;i++) {
			String[] info=temp[i].split(",");
			Cart ct=new Cart();
			ct.userId=info[0];
			ct.itemName=info[1];
			cartList[i]=ct;
		}
		
		
		int cnt=0;
		String ans="";
		for(int i=0;i<userList.length;i++) {
			for(int j=0;j<cartList.length;j++) {
				if(userList[i].id.equals(cartList[j].userId)) {
					for(int k=0;k<itemList.length;k++) {
						if(cartList[j].itemName.equals(itemList[k].name)) {
							cnt+=itemList[k].price;
						}
					}
				}
			}
			ans+=userList[i].id+"("+cnt+"), ";
			cnt=0;
		}
		
		// [정답] qwer(4500), asdf(3200), zxcv(1200)
		System.out.println(ans.substring(0,ans.length()-2));
		
	}

}
