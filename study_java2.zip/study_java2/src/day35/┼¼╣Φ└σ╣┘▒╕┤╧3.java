package day35;

import java.util.Arrays;
import java.util.Scanner;

public class 클배장바구니3 {

	public static void main(String[] args) {
		
		// 221216 회원 가입 탈퇴 찐빠나는중
		
		String[] userIdList={"admin" , "bbb" , "ccc"};
		
		String[] itemNameList={"사과" , "칸초" , "귤" , "감"};
		int [] itemPriceList={10000, 2000, 6500, 3300};
		
			
		int max=5;
		User[] userList=new User[max];
		int userSize=0;
		
		for(int i=0;i<userIdList.length;i++) {
			userList[i]=new User();
			userList[i].id=userIdList[i];
			userSize+=1;
			System.out.println(userList[i].id);
		}
		
		Item[] itemList=new Item[max];
		int itemSize=0;
		for(int i=0;i<itemNameList.length;i++) {
			itemList[i]=new Item();
			itemList[i].name=itemNameList[i];
			itemList[i].price=itemPriceList[i];
			itemSize+=1;
		}
		
		
		Cart[] cartList=new Cart[max];
		int cartSize=0;
		
		Scanner s=new Scanner(System.in);
		while(true) {
			System.out.println("[0] 종료 [1] 로그인 [2] 회원가입 ");
			int sel=s.nextInt();
			if(sel==0) break;
			else if(sel==1) {
				System.out.print("[로그인] 아이디 입력 : ");				
				String id=s.next();
				
				boolean idCheck=false;
				for(int i=0;i<userSize; i++) {
					if(id.equals(userList[i].id)) idCheck=true;
				}
				
				if(idCheck==false) {System.out.println("[로그인실패]");continue;}
				
				if(id.equals("admin")) {					
					while(true) {
						System.out.println("[관리자메뉴]");
						System.out.println("[0] 로그아웃 [1] 아이템 추가 [2] 아이템 삭제");
						sel=s.nextInt();
						if(sel==0) break;
						else if(sel==1) {
							itemList[itemSize]=new Item();
							System.out.println("추가할 아이템을 입력하다 : ");
							itemList[itemSize].name=s.next();
							System.out.println("추가한 아이템의 가격을 입력하다 : ");
							itemList[itemSize].price=s.nextInt();
							System.out.println("추가완료.");
							itemSize++;
						}
						else if(sel==2) {
							System.out.println("삭제할 아이템을 입력하다 : ");
							String del=s.next();
							int idx=0;
							boolean err=false;
							for(int i=0;i<itemList.length;i++) if(del.equals(itemList[i].name)) {idx=i;err=true;}
							if(err==false) {System.err.println("err");continue;}
							else {
								for(int i=idx;i<itemList.length-1;i++) {
									itemList[i]=itemList[i+1];
								}
								itemList[itemSize-1]=new Item();
								itemSize--;
							}
						}
					}
					
				}
				else {
					while(true) {
						System.out.println("[" + id + " 로그인]");
						System.out.println("[쇼핑메뉴]");
						System.out.println("[0] 로그아웃 [1] 쇼핑 [2] 주문확인 [3] 탈퇴");
						sel=s.nextInt();
						if(sel==0) break;
						else if(sel==1) {}
						else if(sel==2) {}
						else if(sel==3) {
							int idx=0;
							for(int i=0;i<userSize-1;i++) {
								if(id.equals(userList[i].id)) idx=i;
							}
							for(int i=idx;i<userList.length-1;i++) {
								userList[i]=userList[i+1];
							}
							userList[userSize-1]=new User();
							userSize--;
							System.out.println("회원탈퇴 칸료");
							for(int i=0;i<userSize;i++) {
								System.out.println(userList[i].id);
							}
							break;
						}
					}
				}			
			}
			else if(sel==2) {
				userList[userSize]=new User();
				System.out.println("가입할 아이디를 입력하다 : ");
				userList[userSize].id=s.next();
				System.out.println("회원가입 완료.");
				userSize++;
			}
			
			
		}
		
		
		
		
	}
}


