package movie;


public class _TicketMain {
	public static void main(String[] args) {
		TicketController controller = new TicketController();
		controller.init();
		controller.run();
	}
}
