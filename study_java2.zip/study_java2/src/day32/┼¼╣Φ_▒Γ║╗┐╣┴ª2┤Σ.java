package day32;

import java.util.Random;
import java.util.Scanner;

class Student{
	int number;
	String id;
	String pw;
	String name="무명이";
	int score;
}

public class 클배_기본예제2답 {

	public static void main(String[] args) {

		int max = 10;
		Student[] stList = new Student[max]; // 학생 객체 10개 들어가는 방만 만듬 => 학생객체 생성 안한상태
		int cnt = 0; // 현재 생성한 학생 숫자

		Scanner sc = new Scanner(System.in);
		Random rd = new Random();

		while (true) {

//			if (cnt > 0) {
//				System.out.printf("%-10s %-10s %-10s %-10s %-10s \n", "학번", "id", "pw", "이름", "점수");
//				for (Student s : stList) {
//					if (s == null) {
//						break;
//					}
//					System.out.printf("%-10d %-10s %-10s %-13s %-10d \n", s.number, s.id, s.pw, s.name, s.score);
//				}
//
//				System.out.println("====================");
//			}
			System.out.println("[1]학생추가 [2]학생 삭제 [3]수정 [4]검색 [5] 전체출력 [0]종료");

			int sel = sc.nextInt();
			if (sel == 0) {
				break;
			} else if (sel == 1) {
				// 추가
				if (cnt == max) {
					System.out.println("학생 전부 추가 완료");
					continue;
				}
				int num = 0;
				if (cnt == 0) {
					num = 1001;
				} else {
					// 최대학번 + 1 로 자동으로 학번값 넣어주기 : 학번은 입력받지 않는다
					// num = stList[cnt-1].number +1;

//					for(int i =0; i < cnt; i++) {
//						if(num < stList[i].number) {
//							num = stList[i].number;
//						}
//					}

					for (Student s : stList) {
						if (s == null) {
							break;
						}

						if (num < s.number) {
							num = s.number;
						}
					}

					num += 1;

				}

				// 학생 객체 생성
				Student s = new Student();
				s.number = num;

				System.out.println("이름 >> ");
//				String name = sc.next();
//				s.name = name; 
				s.name = sc.next();

				// 아이디(중복 금지)
				while (true) {
					System.out.println("ID >> ");
					String id = sc.next();

					boolean check = true;
					for (Student stu : stList) {
						if (stu == null) {
							break;
						}
						if (id.equals(stu.id)) {
							check = false;
							break;
						}
					}

					if (check) {
						s.id = id;
						break;
					}

				}

				// 비번
				System.out.println("PW >> ");
				s.pw = sc.next();

				// 점수(30-100 랜덤하게 가져오기 )

				s.score = rd.nextInt(71) + 30;

				stList[cnt] = s;
				cnt++;
				System.out.println("학생 추가 완료 ");

			} else if (sel == 2 && cnt > 0) {

				// 삭제 아이디 검색해서 삭제
				System.out.println("삭제할 아이디를 입력하세요");
				System.out.println("id >> ");
				String id = sc.next();
				int idx = -1;
				for (int i = 0; i < cnt; i++) {
					if (id.equals(stList[i].id)) {
						idx = i;
						break;
					}
				}

				if (idx == -1) {
					System.out.println("없는 아이디입니다");
					continue;
				}

				for (int i = idx; i < cnt - 1; i++) {
					stList[i] = stList[i + 1];
				}
				stList[cnt - 1] = null;
				cnt--;
				System.out.println("학생 삭제 완료 ");
			} else if (sel == 3 && cnt > 0) {
				// 수정 학번으로 검색 => 점수 수정
				System.out.println("수정할 학번을 입력하세요");
				int num = sc.nextInt();

				int idx = -1;
				for (int i = 0; i < cnt; i++) {
					if (num == stList[i].number) {
						idx = i;
						break;
					}
				}

				if (idx == -1) {
					System.out.println("없는 학번입니다");
					continue;
				}
				System.out.println("수정할 점수을 입력하세요");
				int score = sc.nextInt();

				if (score < 0 || score > 100) {
					System.out.println("점수오류");
					continue;
				}

				if (score == stList[idx].score) {
					System.out.println("다른 점수를 입력하세요");
					continue;
				}

				stList[idx].score = score;

				System.out.println("점수 수정 완료 ");

			} else if (sel == 4 && cnt > 0) {
				// 검색 -> 이름으로 검색 , 학번 점수 출력 (동명이인 일경우까지 생각)
				System.out.println("검색할 이름을 입력하세요 ");
				System.out.println("이름 >> ");

				String name = sc.next();
				boolean check = false;
				for (Student stu : stList) {
					if (stu == null) {
						break;
					}
					if (name.equals(stu.name)) {
						check = true;
						System.out.printf("%s ==> %d : %d점 \n", name, stu.number, stu.score);
					}

				}

				if (check == false) {
					System.out.println("이름이 존재하지 않습니다");
				}

			} else if (sel == 5 && cnt > 0) {

				System.out.printf("%-10s %-10s %-10s %-10s %-10s \n", "학번", "id", "pw", "이름", "점수");

				for (Student s : stList) {
					if (s == null) {
						break;
					}
					// 학생 객체가 있을때만 밑에 부분 실행

					System.out.printf("%-10d %-10s %-10s %-13s %-10d \n", s.number, s.id, s.pw, s.name, s.score);
				}
			} else {
				if (sel < 0 || sel > 5) {
					System.out.println("번호 입력 오류 ");
				}
				if (cnt == 0) {
					System.out.println("학생 데이터가 존재하지않습니다 ");
				}
			}
		}
		
	}

}
