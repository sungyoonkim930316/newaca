package day32;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 小코반 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		Random r=new Random();

		/*
		 * # 소코반
		 * 1. 캐릭터가 공을 움직여 골대에 넣으면 종료되는 게임이다.
		 * 2. 벽의 개수를 입력받아 벽을 설치한다.
		 * 3. 공과 골대 그리고 캐릭터의 위치 값을 입력받아 설치한다.
		 * 4. 벽(9), 공(3), 캐릭터(2) 그리고 골대(7)의 설치가 끝나면 본격적으로 게임이 시작된다.
		 * 5. 캐릭터튼 상하좌우로 이동이 가능해 이동하면서 공을 밀어내어 골대에 넣어야 한다.
		 * 
		 * 0 0 0 0 0 0 0 
		 * 0 0 0 9 9 0 0 
		 * 0 0 0 0 0 0 9 
		 * 0 0 0 0 0 0 0  
		 * 0 0 2 3 7 9 0 
		 * 0 0 0 0 0 0 0  
		 * 9 0 0 0 0 0 0
		 * 
		 * 상(1)하(2)좌(3)우(4) 입력 : 4
		 * 
		 * 0 0 0 0 0 0 0 
		 * 0 0 0 9 9 0 0 
		 * 0 0 0 0 0 0 9 
		 * 0 0 0 0 0 0 0  
		 * 0 0 0 2 3 9 0 
		 * 0 0 0 0 0 0 0  
		 * 9 0 0 0 0 0 0
		 * 
		 * 게임종료
		 */
		int size=7;
		int[][] map = new int[size][size];
		int setting=0;
		int my=3;
		int mx=3;
		int by=3;
		int bx=5;
		int win=0;
				
		
		while(true) {
			
			map[my][mx]=2;
			map[by][bx]=3;
			
			// 게임 세팅
			if(setting==0) {
				while(true) {
					int postx=r.nextInt(size-1);
					int posty=r.nextInt(size-1);
					if(map[posty][postx]==0) {map[posty][postx]=7;break;}
				}
				int wallCnt=0;
				while(true) {
					int wallx=r.nextInt(size-1);
					int wally=r.nextInt(size-1);
					if(map[wally][wallx]==0) {map[wally][wallx]=9;wallCnt++;}
					if(wallCnt==3) break;
				}
				setting=1;
			}
			
			// 게임판 출력
			System.out.println("=====================");
			for(int i=0;i<map.length;i++) {
				System.out.println(Arrays.toString(map[i]));
			}
			System.out.println("=====================");
			
			if(win==1) {System.err.println("[꼬오오오로로로로로로롤~~★]");break;}
			
			System.out.println("[이동하다 : ADWS]");
			String play=s.next();
			
			// 게임판 초기화
			for(int i=0;i<size;i++) {
				for(int j=0;j<size;j++) {
					if(map[i][j]!=9&&map[i][j]!=7&&map[i][j]!=3) {
						map[i][j]=0;
					}
				}
			}
			
			if(play.equalsIgnoreCase("d")) {
				if(mx==size-1||bx==size-1) {continue;}
				if(map[my][mx+1]==9||map[my][mx+1]==7) {continue;}
				mx++;
				if(map[my][mx]==3) {
					if(map[by][bx+1]==9) {continue;}
					else if(map[by][bx+1]==7) {bx++;win=1;}
					else bx++;
				}
			}
			if(play.equalsIgnoreCase("a")) {
				if(mx==0||bx==0) {continue;}
				if(map[my][mx-1]==9||map[my][mx-1]==7) {continue;}
				mx--;
				if(map[my][mx]==3) {
					if(map[by][bx-1]==9) {continue;}
					else if(map[by][bx-1]==7) {bx--;win=1;}
					else bx--;
				}
			}
			if(play.equalsIgnoreCase("w")) {
				if(my==0||by==0) {continue;}
				if(map[my-1][mx]==9||map[my-1][mx]==7) {continue;}
				my--;
				if(map[my][mx]==3) {
					if(map[by-1][bx]==9) {continue;}
					else if(map[by-1][bx]==7) {by--;win=1;}
					else by--;
				}
			}
			if(play.equalsIgnoreCase("s")) {
				if(my==size-1||by==size-1) {continue;}
				if(map[my+1][mx]==9||map[my+1][mx]==7) {continue;}
				my++;
				if(map[my][mx]==3) {
					if(map[by+1][bx]==9) {continue;}
					else if(map[by+1][bx]==7) {by++;win=1;}
					else by++;
				}
			}

			
		}
		
	}
}
