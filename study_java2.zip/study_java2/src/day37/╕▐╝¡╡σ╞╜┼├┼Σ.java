package day37;

import java.util.Arrays;
import java.util.Scanner;

class TicTacToe{
	
	
	Scanner s=new Scanner(System.in);
	
	String[][] game=new String[3][3];
	
	int turn=1;
	int win=0;		// 1[turn1승리] 2[turn2승리]
	int cnt=0;
	
	/*View=======================================================================*/
	void showGame() {
		for(int i=0;i<game.length;i++) {
			for(int j=0;j<game[i].length;j++) {
				if(game[i][j].equals("")) System.out.print("[ ]");
				else System.out.print("["+game[i][j]+"]");
			}
			System.out.println();
		}
	}
	
	/*Functions==================================================================*/
	void setGame() {
		for(int i=0;i<game.length;i++) {
			for(int j=0;j<game[i].length;j++) game[i][j]="";
		}
	}
	
	void choiceIdx() {
		System.out.println("1번부터 9번까지의 Cell중 하나를 선택하다.");
		int cell=s.nextInt();
		if(cell>9||cell<1) {System.err.println("1번부터 9번까지의 넘버를 입력해야한다.");return;}
		
		int y=(cell-1)/3;
		int x=(cell-1)%3;
		
		if(game[y][x].equals("")) {
			if(turn==1) game[y][x]="O";
			else game[y][x]="X";
		}
		else {
			System.err.println("이미 선택된 Cell이다.");return;
		}
		
		turn=turn==1?2:1;
		cnt++;
	}
	
	void exitWidth() {
		for(int i=0;i<game.length;i++) {
			if(game[i][0]!="") {
				if(game[i][0]==game[i][1]&&game[i][1]==game[i][2]) {
					turn=turn==1?2:1;
					win=turn;
				}
			}
		}
	}
	void exitHeight() {
		for(int i=0;i<game.length;i++) {
			if(game[0][i]!="") {
				if(game[0][i]==game[1][i]&&game[1][i]==game[2][i]) {
					turn=turn==1?2:1;
					win=turn;
				}
			}
		}
	}
	void exitCross() {
		if(game[0][0]!=""&&game[0][2]!="") {
			if(game[0][0]==game[1][1]&&game[1][1]==game[2][2] || game[0][2]==game[1][1]&&game[1][1]==game[2][0]) {
				turn=turn==1?2:1;
				win=turn;
			}
		}
	}
	
	/*Run========================================================================*/
	void run() {
		
		// game배열을 공백 문자열(" ")로 초기화
		setGame();
		
		while(true) {
			showGame();
			// 게임 종료
			if(win!=0) {System.out.println(win==1?"player1 승리":"player2 승리");break;}
			if(cnt==9) {System.out.println("무승부");break;}
			
			choiceIdx();
			
			exitWidth();
			exitHeight();
			exitCross();
		}
		
	}
}

public class 메서드틱택토 {

	public static void main(String[] args) {
		TicTacToe tic = new TicTacToe();
		tic.run();
	}

}
