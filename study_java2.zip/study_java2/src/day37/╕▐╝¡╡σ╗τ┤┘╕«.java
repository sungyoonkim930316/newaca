package day37;

import java.util.Arrays;
import java.util.Scanner;

class LadderGame {

	Scanner s=new Scanner(System.in);

	int[][] ladder={ 
			{ 0, 0, 0, 0, 0 }, 
			{ 1, 2, 0, 1, 2 }, 
			{ 0, 1, 2, 0, 0 }, 
			{ 0, 0, 0, 1, 2 }, 
			{ 0, 1, 2, 0, 0 },
			{ 1, 2, 0, 0, 0 }, 
			{ 0, 0, 0, 1, 2 }, 
			{ 0, 0, 0, 0, 0 } 
	};

	int xIdx=0;
	int yIdx=0;
	
	/*View=======================================================================================*/
	void showLadder() {
		for(int i=0;i<ladder.length;i++) {
			for(int j=0;j<ladder[i].length;j++) {
				if(ladder[i][j]==0) System.out.print(" │ ");
				else if(ladder[i][j]==1) System.out.print(" ├─");
				else System.out.print("─┤ ");
			}System.out.println();
		}
	}
	
	String setMenu(int a) {
		String[] menu={"불백","라멘","구내식당","맥날","짬뽕"};
		System.out.println(Arrays.toString(menu));
		return menu[a];
	}
	
	/*Functions==================================================================================*/
	int moveLadder(int a) {
		yIdx=0;
		xIdx=a;
		
		for(int i=0;i<ladder.length;i++) {
			if(ladder[i][xIdx]==1) xIdx++;
			else if(ladder[i][xIdx]==2) xIdx--;
		}
		return xIdx;
	}
	
	/*Exceptions=================================================================================*/
	boolean isNumber(int a) {
		return a>4||a<0?false:true;
	}
	
	
	void run() {

		showLadder();

		xIdx=0;
		yIdx=0;

		// 사다리 선택하기
		System.out.print("번호를 선택하세요(1~5) : ");
		yIdx=s.nextInt()-1;
		// 입력번호 우효성 체크
		isNumber(yIdx);
		

		// 사다리 이동하기
//		moveLadder(yIdx);
		int idx=moveLadder(yIdx);
//		setMenu(0); // 메뉴설정하기 : 메뉴는 본인이 먹고싶은걸로 정하세요


		System.out.println("오늘의 점심 메뉴는 " + setMenu(idx) + " 입니다~!!!");

	}
}

public class 메서드사다리 {

	public static void main(String[] args) {
		LadderGame lg = new LadderGame();
		lg.run();
	}

}
