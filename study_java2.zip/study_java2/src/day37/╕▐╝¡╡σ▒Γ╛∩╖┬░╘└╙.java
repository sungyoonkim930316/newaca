package day37;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class MemoryGame{
	
	Scanner s=new Scanner(System.in);
	Random r=new Random();
	
	int[] front={1, 1, 2, 2, 3, 3, 4, 4, 5, 5};
	int[] back=new int[10];
	int[] card=new int[front.length];
	
	int cnt=0;		// 정답을 맞춘 횟수
	
	void shuffle() {
		int temp=0;
		for(int i=0;i<50;i++) {
			int num=r.nextInt(front.length);
			temp=front[0];
			front[0]=front[num];
			front[num]=temp;
		}
	}
	
	int showBackCards() {
		int cIdx=0;
		for(int i:front) {
			if(card[cIdx]==0) {System.out.print("[ ]");}
			else {System.out.print("["+i+"]");}
			cIdx++;
		}
		System.out.println();
		return cIdx;
	}
	
	int choiceCard() {
		int flip=getInputInt("카드넘버를");
		isCard(flip);
		return flip;
	}
	
	void printCard() {
		
	}
	
	void run() {
		
		// 셔플(카드 섞기)
		shuffle();
		
		while(true) {
			
			// 뒷면 카드
			int cIdx=showBackCards();
			int cardFlip=0;
			int a=0;
			int b=0;
			while(true) {
				// 카드 선택하기
				int flip=choiceCard();
				cIdx=flip;
				card[cIdx]=1;
				cardFlip++;
				if(cardFlip==1) {a=cIdx;}
				if(cardFlip==2) {b=cIdx;}
				cIdx=0;
				for(int i:front) {
					if(card[cIdx]==0) {System.out.print("[ ]");}
					else {System.out.print("["+i+"]");}
					cIdx++;
				}
				System.out.println();
				
				if(cardFlip==2) {
					if(front[a]==front[b]) {back[a]=1;back[b]=1;cnt+=1;}
					else {card[a]=0;card[b]=0;}
					break;
				}
			}
			System.out.println("===============================");
			System.out.println();
			// 카드 출력
//			printCard();
			
			// 종료하기
			if(cnt==5) {System.out.println("게임 종료");break;}			
			
		}
	}
	
	/*예외처리*/
	void isCard(int num) {
		if(num>9||num<0) {System.err.println("err");return;}
		if(card[num]!=0) {System.err.println("err");return;}
	}
	
	int getInputInt(String msg) {
		System.out.print(msg);
		System.out.print(" 입력하다 ");
		return s.nextInt();
	}
}

public class 메서드기억력게임 {

	public static void main(String[] args) {

		MemoryGame mg = new MemoryGame();
		mg.run();
		
	}

}
