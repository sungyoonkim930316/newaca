package day37;


import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class WordGame{
	Random r=new Random();
	String[] wordList ={"java" , "spring" , "jsp" , "android" , "php"};
	boolean[] checkList;
	int count;
	
	/*Function=========================================================================*/
	void reset() {
		String[] temp=new String[wordList.length];
		for(int i=0;i<50;i++) {
			int sf=r.nextInt(wordList.length-1);
			temp[0]=wordList[0];
			wordList[0]=wordList[sf];
			wordList[sf]=temp[0];
		}
	}
	
	String getWord(int cnt) {
		return wordList[cnt];
	}
	
	boolean checkWord(String a, int cnt) {
		if(a.equals(wordList[cnt])) {System.out.println("[정답.]\n");return true;}
		else {System.err.println("[오답.]\n");return false;}
	}
	
	boolean getGameEnd(int cnt) {
		if(cnt>=5) return true;
		else return false;
	}
	
	void printGameEnd() {
		System.out.println("[★CLEAR★]\n");
	}
	
}

public class 메서드타자게임 {

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		WordGame w=new WordGame();
	
		while(true) {
			System.out.println("타자연습게임");
			System.out.println("1)게임 0)종료");
			int sel=s.nextInt();
			if(sel==1) {
				w.reset();
				int cnt=0;
				while(true) {
					System.out.println(w.count+") 단어를 맞춰보세요.");
					System.out.println("["+w.getWord(cnt)+"]");
					System.out.print("입력하다 : ");
					String word=s.next();
					if(w.checkWord(word,cnt)==true) cnt++;
					if(w.getGameEnd(cnt)) {
						w.printGameEnd();
						break;
					}
				}
			}
			else if(sel==2) break;
		}
		
		
		
	}
}
