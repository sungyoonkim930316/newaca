package day37;

import java.util.Random;
import java.util.Scanner;

class NumberGame{
	
	// 심화는 격파까지 구현하시오 
	Scanner s = new Scanner(System.in);
	Random r=new Random();
	int[] move = {0, 0, 0, 0, 8, 0, 0, 0, 0, 0};
	int pidx = 4;
	
	int setting=0;
	
	/*View=======================================================================*/
	void printPlay() {
		for(int i:move) {
			if(i==8)System.out.print("옷");
			else if(i==9) System.out.print("[]");
			else System.out.print("__");
		}
		System.out.println();
	}
	void showMenu() {
		String gameMenu="";
		gameMenu+="[1] 왼쪽\t";
		gameMenu+="[2] 오른쪽\n";
		gameMenu+="[3] 게임 종료.";
		System.out.print(gameMenu);
	}
	
	/*Functions==================================================================*/
	void settingWalls() {
		for(int i=0;i<2;i++) {
			int wall=r.nextInt(move.length-1);
			if(move[wall]==0) move[wall]=9;
		}
		setting++;
	}
	
	void moveLeft() {
		boolean c=pidx>0&&move[pidx-1]==9 || pidx==0&&move[move.length-1]==9;
		if(c) eitherWay();
		
		else if(!c) {
			move[pidx]=0;
			if(pidx==0) {pidx=move.length-1;}
			else pidx--;
			move[pidx]=8;
		}
		else return;
	}
	void moveRight() {
		move[pidx]=0;
		if(pidx==move.length-1) pidx=0;
		else pidx++;
		move[pidx]=8;
	}
	boolean eitherWay() {
		boolean check=true;
		
		for(int i:move) {
			if(i==8)System.out.print("옷");
			else if(i==9) System.out.print("[]");
			else System.out.print("__");
		}
		System.out.println();
		
		System.out.println("[벽이 있다.]");
		String gameMenu="";
		gameMenu+="[3] 파괴하다.  ";
		gameMenu+="[4] 가만히있다.\n";
		System.out.print(gameMenu);
		int sel=s.nextInt();
		
		if(sel==3) check=true;
		if(sel==4) check=false;
		return check;
	}
	
	/*Tools======================================================================*/
	
	/*Exceptions=================================================================*/
	boolean isNumber(int num) {
		if(num>3||num<0) return false;
		else return true;
	}
	
	/*Nintendo===================================================================*/
    void run() {
    	
    	
 		while(true) {
 			// 벽 설치
 			if(setting==0) settingWalls();
 			
			// 게임화면 출력
			printPlay();
			System.out.println();
			// 메뉴 출력
			showMenu();
			// 메뉴 선택
			System.out.print(" : ");
			int choice=s.nextInt();
			if(isNumber(choice)==true) {
				// 좌로 이동
				if(choice==1) {
					moveLeft();
				}
				// 우로 이동
				else if(choice==2) {
					moveRight();
				}
				// 종료
				else if(choice==3) {
					System.out.println("게임 종료");
					break;
				}
			}
			else {System.err.println("입력오류");continue;}
			
		}
 		
 		
	}
    
    
}

public class 메서드숫자이동 {

	public static void main(String[] args) {

		NumberGame g=new NumberGame();
		g.run();
		
	}

}
