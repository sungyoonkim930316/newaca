package day37;

import java.util.Arrays;
import java.util.Scanner;

class Theater {

	int[] seat = new int[10];
	Scanner scan = new Scanner(System.in);
	String name = ""; // 영화관 이름
	int cnt = 0; // 예매 수
	int money = 0; // 매출액
	
	/*View=========================================================================================*/
	// 좌석 현황
	void showSeat() {
		System.out.println("\t  [ 좌석현황 ]");
		for(int i:seat) {
			if(i==0) System.out.print("[_]");
			else System.out.print("[X]");
		}
		System.out.println();
		System.out.println(" 1  2  3  4  5  6  7  8  9  10");
	}
	// 메뉴 출력
	void showMenu() {
		System.out.println("==============================");
		String menu="";
		menu+="[1] 예매하기\n";
		menu+="[2] 종료하기";
		System.out.println(menu);
	}
	void showSales() {
		money=cnt*15000;
		System.out.println("매출액 : "+money);
	}
	
	/*Functions====================================================================================*/
	void choiceSeat() {
		if(cnt>seat.length-1) {System.err.println("예매할 좌석이 없다.");return;}
		int seatNum=getInputInt("예매할 좌석 번호를");
		if(checkSeat(seatNum)==true) {
			seat[seatNum-1]=1;
			System.out.println("["+seatNum+"번 좌석 예매 완료.]");
			cnt++;
		}
	}
	
	/*Exceptions===================================================================================*/
	boolean checkSeat(int num) {
		boolean check=true;
		if(num>10||num<1) {System.err.println("좌석 입력오류");check=false;return check;}
		for(int i=0;i<seat.length;i++) {
			if(seat[num-1]==1) {
				System.err.println("이미 예매된 좌석이다.");
				check=false;
				break;
			}
		}
		return check;
	}
	/*Tool=========================================================================================*/
	int getInputInt(String msg) {
		 Scanner s=new Scanner(System.in);
		 System.out.print(msg);
		 System.out.print(" 입력하다 ");
		 return s.nextInt();
	 }
}

public class 메서드좌석예매 {

	public static void main(String[] args) {
		
		Scanner s=new Scanner(System.in);
		Theater megabox=new Theater();
		megabox.name="메가박스";

		while (true) {
			megabox.showSeat();
			// 메뉴 출력
			megabox.showMenu();

			// 메뉴 선택하기
			System.out.print("메뉴 선택 : ");
			int choice=s.nextInt();

			// 예매하기
			if(choice==1) {
				megabox.choiceSeat();
			}
			// 종료하기
			else if(choice==2) {
				// 매출 현황 출력하기
				megabox.showSales();

				System.out.println("프로그램 종료");
				break;
			}
		}

	}

}
