package day37;

import java.util.Arrays;
import java.util.Scanner;

class BankNoReturn {

	Scanner scan = new Scanner(System.in);

	String name = "";

	String[] arAcc = { "1111", "2222", "3333", "", "" };
	String[] arPw = { "1234", "2345", "3456", "", "" };
	int[] arMoney = { 87000, 34000, 17500, 0, 0 };

	int count = 3;
	int loginCheck = -1;
	
	
	String curAcc="";

	// 리턴안쓰므로 해서 생긴변수
	int checkDelete;
	int checkAccount;
	int checkPassword;
	
	String[][] member=new String[count][3];
	
	
	/*View=========================================================================================*/
	void showMember() {
		member=new String[count][3];
		System.out.println("[계좌   비밀번호\t잔액]");
		System.out.println("===================");
		for(int i=0;i<count;i++) {
			member[i][0]=arAcc[i];
			member[i][1]=arPw[i];
			member[i][2]=String.valueOf(arMoney[i]);
			System.out.println(Arrays.toString(member[i]));
		}
		System.out.println("===================");
	}
	
	int showMenu(int log) {
		String menu="";
		if(log==-1) {
			menu="";
			menu+="[1] 회원가입\n";
			menu+="[2] 로그인";
		}
		else if(log==1) {
			menu="";
			menu+="[1] 로그아웃\n";
			menu+="[2] 회원탈퇴\n";
			menu+="[3] 입금\n";
			menu+="[4] 이체";
		}
		System.out.println(menu);
		return log;
	}
	
	/*Functions====================================================================================*/
	// 회원가입
	void joinMember() {
		if(count>4) {System.err.println("풀방");return;}
		System.out.println("[ 회원 가입 ]");
		String acc=getInputString("가입할 계좌를");
		String pwd=getInputString("패스워드를");
		
		if(isMember(acc)==true) {
			arAcc[count]=acc;
			arPw[count]=pwd;
			System.out.println("["+acc+" 계좌 등록 완료.]");
			count++;
		}
		else {System.err.println("이미 가입된 계좌.");return;}
	}
	
	// 회원탈퇴
	int delMember(int log) {
		if(count==0) {System.err.println("삭제할 계좌가 없다.");}
		System.out.println("[ 회원 탈퇴 ]");
		int idx=0;
		while(true) {
			String pwd=getInputString("패스워드를");
			for(int i=0;i<count;i++) {
				if(member[i][0].equals(curAcc)) idx=i;
			}
			if(member[idx][1].equals(pwd)) break;
			else System.err.println("비밀번호 입력 오류.");
		}
		for(int i=idx;i<count-1;i++) {
			arAcc[i]=arAcc[i+1];
			arPw[i]=arPw[i+1];
			arMoney[i]=arMoney[i+1];
		}
		arAcc[count-1]="";
		arPw[count-1]="";
		arMoney[count-1]=0;
		System.out.println("["+curAcc+"계좌 회원탈퇴 완료.]");
		count--;
		curAcc="";
		log=-1;
		return log;
	}
	
	// 로그인
	int login(int log) {
		System.out.println("[ 로그인 ]");
		String acc=getInputString("계좌를");
		
		if(isAcc(acc)==true) {
			while(true) {
				String pwd=getInputString("패스워드를");
				int idx=0;
				for(int i=0;i<count;i++) {
					if(member[i][0].equals(acc)) idx=i;
				}
				if(member[idx][1].equals(pwd)) break;
				else System.err.println("비밀번호 입력 오류.");
			}
			System.out.println("["+acc+" 계좌 로그인완료.]");
			curAcc=acc;
			log=1;
		}
		else {System.err.println("없는 아이디");}
		return log;
	}
	
	// 로그아웃
	int logOut(int log) {
		log=-1;
		System.out.println("[로그아웃 완료.]");
		curAcc="";
		return log;
	}
	
	// 입금
	void income() {
		int money=getInputInt("입금할 금액을");
		int idx=0;
		for(int i=0;i<count;i++) {
			if(member[i][0].equals(curAcc)) idx=i;
		}
		arMoney[idx]+=money;
		System.out.println("["+money+"원 입금 완료.]");
	}
	
	// 이체
	void trans() {
		String acc=getInputString("이체할 계좌를");
		
			int money=getInputInt("이체할 금액을");
			int idx=0;
			for(int i=0;i<count;i++) {
				if(member[i][0].equals(curAcc)) idx=i;
			}
			if(money>arMoney[idx]) {System.err.println("이체 실패 : 잔액이 부족하다.");return;}
			else arMoney[idx]-=money;
			
			idx=0;
			for(int i=0;i<count;i++) {
				if(member[i][0].equals(acc)) idx=i;
			}
			arMoney[idx]+=money;
			System.out.println("["+acc+"계좌로 "+money+"원 이채 완료.]");
	}
	
	/*Exceptions===================================================================================*/
	// 계좌중복 체크 
	boolean isMember(String acc) {
		boolean check=true;
		for(int i=0;i<member.length;i++) {
			if(acc.equals(member[i][0])) {check=false;break;}
		}
		return check;
	}
	
	// 계좌 찾기
	boolean isAcc(String acc) {
		boolean check=false;
		for(int i=0;i<member.length;i++) {
			if(acc.equals(member[i][0])) {check=true;break;}
		}
		return check;
	}
	
	
	/*Tool=========================================================================================*/
	// 스트링 입력
	String getInputString(String msg) {
		 Scanner s=new Scanner(System.in);
		 System.out.print(msg);
		 System.out.print(" 입력하다. ");
		 return s.nextLine();
	}
	
	// 인트 입력
	int getInputInt(String msg) {
		 Scanner s=new Scanner(System.in);
		 System.out.print(msg);
		 System.out.print(" 입력하다. ");
		 return s.nextInt();
	}
	
}

public class 메서드ATM {

	public static void main(String[] args) {

		Scanner s=new Scanner(System.in);
		BankNoReturn woori=new BankNoReturn();
		woori.name="우리은행";

		int log=-1;
		while(true) {
			// 전체 회원정보 출력
			woori.showMember();
			// 메뉴 출력
			woori.showMenu(log);
			// 메뉴 선택
			System.out.print("메뉴를 선택해주세요 : ");
			int choice=s.nextInt();
			// 회원가입
			if(log==-1) {
				if(choice==1) {
					woori.joinMember();
				}
				// 로그인
				else if(choice==2) {
					log=woori.login(log);
				}
			}
			else if(log==1) {
				// 회원탈퇴
				if(choice==2) {
					log=woori.delMember(log);
				}
				// 로그아웃
				else if(choice==1) {
					log=woori.logOut(log);
				}
				// 입금
				else if(choice==3) {
					woori.income();
				}
				// 이체
				else if(choice==4) {
					woori.trans();
				}
			}
		}
		
	}

}
