package day37;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class Poker {
	
	Random r=new Random();
	Scanner s=new Scanner(System.in);
	
	int maxPlayer=2;
	
	String[][] deck= {
			{"♠A","♠2","♠3","♠4","♠5","♠6","♠7","♠8","♠9","♠10","♠J","♠Q","♠K"},
			{"◇A","◇2","◇3","◇4","◇5","◇6","◇7","◇8","◇9","◇10","◇J","◇Q","◇K"},
			{"♡A","♡2","♡3","♡4","♡5","♡6","♡7","♡8","♡9","♡10","♡J","♡Q","♡K"},
			{"♣A","♣2","♣3","♣4","♣5","♣6","♣7","♣8","♣9","♣10","♣J","♣Q","♣K"}
	};
	String[][] hand=new String[maxPlayer][7];
	int cnt=0;
	
	
	/*Views=====================================================================================*/
	
	/*Functions=================================================================================*/
	// 랜덤으로 카드 뽑기
	String pickCard() {
		int y=0;
		int x=0;
		while(true) {
			y=r.nextInt(4);
			x=r.nextInt(13);
			if(deck[y][x]!="taken") break;
		}
		return deck[y][x];
	}
	
	void takeCardFromDeck(String card) {
		for(int i=0;i<deck.length;i++) {
			for(int j=0;j<deck[i].length;j++) {
				if(deck[i][j].equals(card)) deck[i][j]="taken";
			}
		}
	}

	void addCard(int turn) {
		String card=pickCard();
		takeCardFromDeck(card);
		hand[turn][cnt]=card;
		System.out.print("player"+(turn+1)+"의 카드 : [ ");
		for(int i=0;i<=cnt;i++) {
			System.out.print(hand[turn][i]+" ");
		}
		System.out.println("]");
	}
	
	void shobu(int turn) {
		String[] shobu=null;
		System.out.println("[player"+(turn+1)+"]");
		System.out.println(Arrays.toString(hand[turn]));
		while(true) {
			int cnt=shobu==null?0:shobu.length;
			
			System.out.println("[1] 승부패를 추가하다. [2] 쇼부본다.");
			int sel=s.nextInt();
			if(sel==1) {
				System.out.println("넣을 패 번호선택");
				int num=s.nextInt()-1;
				if(num>7||num<0) {System.err.println("범위오류");}
				
				if(shobu==null) shobu=new String[1];
				else {
					String[] temp=new String[cnt+1];
					for(int j=0;j<cnt;j++) {
						temp[j]=shobu[j];
					}
					shobu=temp;
					temp=null;
				}
				shobu[cnt]=hand[turn][num];
				System.out.println(Arrays.toString(shobu));
			}
			else if(sel==2) {
				
				hand[turn]=new String[1];
				hand[turn]=shobu;
				break;
			}
		}
		System.out.println(Arrays.toString(hand[turn]));
	}
	
	void makeCombination(int turn, String[] a) {
		
		String combination="";
		
		// 원페어
		if(a.length==2) {
			if(findNumber(a[0]).equals(findNumber(a[1]))) combination+="["+findNumber(a[0])+"][원페어]";
			else combination+="뻥카";
		}
		
		// 트리플
		else if(a.length==3) {
			if(findNumber(a[0]).equals(findNumber(a[1]))&&findNumber(a[1]).equals(findNumber(a[2]))) combination+="["+findNumber(a[0])+"][트리플]";
			else combination+="뻥카";
		}
		
		// 투페어 포카드
		else if(a.length==4) {
			int check=0;
			for(int i=0;i<a.length-1;i++) {
				if(findNumber(a[i])!=findNumber(a[i+1])) check=1;
			}
			
			// 포카드
			int fcnt=0;
			if(check==0) {
				for(int i=0;i<a.length-1;i++) {
					if(findNumber(a[i]).equals(findNumber(a[i+1]))) fcnt++;
				}
				if(fcnt==3) combination+="["+findNumber(a[0])+"][포카드]";
			}
			
			// 투페어
			else {
				int checkCnt=0;
				for(int i=0;i<a.length;i++) {
					int cnt=0;
					for(int j=0;j<a.length;j++) {
						if(findNumber(a[i]).equals(findNumber(a[j]))) cnt++;
					}
					if(cnt==2) {
						combination+="["+findNumber(a[i])+"]";
						a[i]="checked";
						checkCnt++;
					}
				}
				if(checkCnt==2) combination+="투페어";
				else combination+="뻥카";
			}
		}
		
		// 플러시 스트레이트 풀하우스
		else if(a.length==5) {
			// 플러시
			int check=0;
			int cnt=0;
			for(int i=0;i<a.length;i++) {
				if(findMark(a[i]).equals(findMark(a[0]))) cnt++;
			}
			if(cnt==5) {combination+="["+findMark(a[0])+"][플러시]";check=1;}
			
			else {
				// 스트레이트
				cnt=0;
				int[] temp=new int[a.length];
				for(int i=0;i<a.length;i++) {
					if(findNumber(a[i]).equals("A")) temp[i]=1;
					else if(findNumber(a[i]).equals("J")) temp[i]=11;
					else if(findNumber(a[i]).equals("Q")) temp[i]=12;
					else if(findNumber(a[i]).equals("K")) temp[i]=13;
					else temp[i]=Integer.parseInt(findNumber(a[i]));
				}
				
				int lastNum=temp[0]+a.length-1;
				if(lastNum>=5&&lastNum<=13) {
					if(lastNum==temp[a.length-1]) {
						combination+="[ ";
						for(int i=0;i<a.length;i++) {
							combination+=findNumber(a[i])+" ";
						}
						combination+="][스트레이트]";
					}
				}
				
				// 풀하우스
				check=1;
			}
			if(check==0) {combination+="뻥카";}
			
		}
		
		
		
		System.out.println("[player"+(turn+1)+"] : ["+combination+"]");
//		return ;
	}
	
	/*Exceptions================================================================================*/
	
	/*Tools=====================================================================================*/
	String findNumber(String a) {
		a=a.substring(1,a.length());
		return a;
	}
	String findMark(String a) {
		a=a.substring(0,1);
		return a;
	}
	
	/*Operator==================================================================================*/
	void run() {
		
		while(true) {
			if(cnt<7) {
//				System.out.println("카드선택");
//				String st=s.next();
				for(int i=0;i<maxPlayer;i++) {
					addCard(i);
				}
				cnt++;
				System.out.println(cnt);
			}
			else {
				for(int i=0;i<maxPlayer;i++) {
					shobu(i);
				}
				for(int i=0;i<maxPlayer;i++) {
					makeCombination(i,hand[i]);
				}
			}
//			for(int i=0;i<deck.length;i++) System.out.println(Arrays.toString(deck[i]));
			
		}
	}
	
	
}

public class self_practice {

	public static void main(String[] args) {
		Poker p=new Poker();
		p.run();
	}

}
