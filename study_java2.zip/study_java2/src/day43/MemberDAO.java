package day43;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class MemberDAO {
	Scanner s = new Scanner(System.in);
	
	int num; // 학번 1001 시작 
	Member[] memberList;
	
	MemberDAO(){
		num = 1001;
	}
	int getValueInt(String msg) {
	    // 예외처리 적용해보세요 
		System.out.println(msg +" 입력하다. : ");
		return s.nextInt();
	}
	
	String getValueString(String msg) {
		System.out.println(msg+" 입력하다. : ");
		return s.next();
	}
	
	void join() {
		int cnt=memberList==null?0:memberList.length;
		String name=getValueString("이름을");
		if(memberList==null) memberList=new Member[1];
		else {
			Member[] temp=new Member[cnt+1];
			for (int i=0;i<cnt;i++) {
				temp[i]=memberList[i];
			}
			memberList=temp;
			temp=null;
		}
		memberList[cnt]=new Member(name,num);
		num++;
		System.out.println("["+memberList[cnt].id+" 추가완료.]");
	}
	
	void remove() {
		if(memberList==null) {System.out.println("[삭제할 멤버가 없다.]");}
		int stuNo=getValueInt("학번을");
		Member[] temp=new Member[memberList.length-1];
		int idx=-1;
		for(int i=0;i<memberList.length-1;i++) {
			if(stuNo==memberList[i].num) {
				idx=i;
			}
		}
		for(int i=0;i<idx;i++) {
			temp[i]=memberList[i];
		}
		for(int i=idx;i<temp.length;i++) {
			temp[i]=memberList[i+1];
		}
		memberList=temp;
	}
	
	void printMember() {
		if(memberList==null) {System.err.println("[멤버가 존재하지 않는다.]");}
		for(int i=0;i<memberList.length;i++) {
			System.out.println("["+memberList[i].id+" : "+memberList[i].num+"]");
		}
	}
	void loadData() {
		// 저장패턴 
		// 첫줄은 총몇명인지 저장 memberList.length
		// 아이디,학번\n 이렇게 한줄로 저장 
		
		// 저장예시
		// 2\n 1001,test1 \n l002,test2  
		String fileName="src/예외처리/memberList.txt";
		FileWriter fw=null;
		try {
			 fw = new FileWriter(fileName);
			 fw.write("멤버는 총 "+memberList.length+"명\n");
			 for(int i=0;i<memberList.length;i++) {
				 fw.write(memberList[i].num+","+memberList[i].id+"\n");
			 }
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			try {
				fw.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("파일" + fileName +" 생성 완료");
		}
		
		
	}
	void readData() {
		String fileName="src/예외처리/memberList.txt";
		FileReader fr=null;
		String data="";
		try {
			fr=new FileReader(fileName);
			int read=0;
			while(read!=-1) {
				read=fr.read();
				data+=(char)read;
			}
		} catch (FileNotFoundException e) {
			System.out.println("파일이 존재하지 않습니다.");
			e.printStackTrace();
		} catch(IOException e) {
			e.printStackTrace();
		} finally {
			try {
				fr.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println(data);
	}
}