package day43;

public class _MemberMain {

	public static void main(String[] args) {

		MemberController mc = new MemberController();
		mc.mainMenu();
		
	}

}
