package day41;

import java.util.Random;
import java.util.Scanner;

class Setting {
	
	// InputTools==================================================================
	Scanner s=new Scanner(System.in);
	
	/*Int반환입력*/
	int getValueInt(String msg) {
		System.out.print(msg+" 입력하다. : ");
		return s.nextInt();
	}
	
	/*String반환입력*/
	String getValueString(String msg) {
		System.out.print(msg+" 입력하다. : ");
		return s.next();
	}
	
	// RandomTool==================================================================
	Random r=new Random();
	
	/*난수받아오기*/
	int returnRandomNumbers(int range) {
		int rn=r.nextInt(range);
		return rn;
	}
	
	// Settings====================================================================
	int size;
	int[][] board;
	int hy;
	int hx;
	int berryLimitation;
	Setting(){
		size=10;
		board=new int[size][size];
		hy=returnRandomNumbers(size);
		hx=returnRandomNumbers(size);
		berryLimitation=0;
	}
	
	/*게임판*/
	void makeGameBoard() {
		for(int i=0;i<size;i++) {
			for(int j=0;j<size;j++) {
				if(board[i][j]==0) {System.out.print("[ ]");}
				else if(board[i][j]==9) {System.out.print("[♠]");}
				else System.out.print("[■]");
			}System.out.println();
		}
	}
	
	/*뱀머리*/
	void designateSnakeHeadLocation() {
		board[hy][hx]=1;
	}
	
	/*뱀꼬리*/
	void designateSnakeTailLocation() {
		
	}
	
	/*열매*/
	void designateBerriesLocations() {
		if(berryLimitation<3) {
			while(true) {
				int bx=returnRandomNumbers(size-1);
				int by=returnRandomNumbers(size-1);
				if(board[by][bx]==0) {board[by][bx]=9;berryLimitation++;break;}
			}
		}
	}
	
	/*독벌레*/
	void designatePoisonousCentipedeLocation() {
		
	}
}

class Play {
	
	Setting s;
	Play(){
		s=new Setting();
	}
	// Systems=====================================================================
	/*게임승리조건*/
	boolean winSys() {
		return true;
	}
	
	/*게임판초기화*/
	void cleanBoard() {
		for(int i=0;i<s.board.length;i++) {
			for(int j=0;j<s.board[i].length;j++) {
				if(s.board[i][j]!=0&&s.board[i][j]!=9) {
					s.board[i][j]=0;
				}
			}
		}
	};
	
	/*뱀의움직임*/
	void moveSnake() {
		String directions=s.getValueString("[ADWS] 방향을");

		cleanBoard();
		if(directions.equalsIgnoreCase("d")) {
			if(s.hx+1>s.size-1) {
				System.err.println("[LOSE]");
			    return;
			}
			s.hx++;
	
		}
		if(directions.equalsIgnoreCase("a")) {
			if(s.hx-1<0) {
				System.err.println("[LOSE]");
				return;
			}
			s.hx--;
			
		}
		if(directions.equalsIgnoreCase("w")) {
			if(s.hy-1<0) {
				System.err.println("[LOSE]");
				return;
			}
			s.hy--;
		}
		if(directions.equalsIgnoreCase("s")) {
			if(s.hy+1>s.size-1) {
				System.err.println("[LOSE]");
			    return;
			}
			s.hy++;
		}
		s.designateSnakeHeadLocation();
	}
	
	// Run=========================================================================
	void run() {

		s.designateSnakeHeadLocation();
		
		while(true) {
			System.out.println(s.hy);
			System.out.println(s.hx);
			s.designateBerriesLocations();
			s.makeGameBoard();
			moveSnake();
		}
		
	}
	
}

public class 클배스네이크 {

	public static void main(String[] args) {

		Play p=new Play();
		System.out.println("★[SNAKE GAME]★");
		p.run();
		
		
	}

}
