package 제네릭클래스;

import java.util.ArrayList;
import java.util.Arrays;

class MyArrayList{
	
	boolean tryCatch(int idx,int[] list) {
		
		try {
			if(idx>list.length-1||idx<0) {
				throw new ArrayIndexOutOfBoundsException();
			}
		}
		catch(ArrayIndexOutOfBoundsException e) {
			System.err.println("인덱스범위오류");
		}
		
		return true;
	}
	
	//size() :int 길이출력
	int size(int[] list) {
		if(list==null) return 0;
		return list.length;
	}
	
	//add(int idx) :void 값 추가
	int[] add(int num, int[] list) {
		int cnt=list==null?0:size(list);
		if(list==null) list=new int[1];
		else {
			int[] temp=new int[cnt+1];
			for(int i=0;i<cnt;i++) {
				temp[i]=list[i];
			}
			list=temp;
			temp=null;
		}
		list[cnt]=num;
		System.out.println(Arrays.toString(list));
		return list;
	};
	
	//add(int idx, int val) :void  값 삽입
	int[] add(int idx,int val,int[] list) {
		if(tryCatch(idx, list)) {
			int cnt=list==null?0:size(list);
			if(list==null) list=new int[1];
			else {
				int[] temp=new int[cnt+1];
				for(int i=0;i<idx;i++) {
					temp[i]=list[i];
				}
				temp[idx]=val;
				for(int i=idx;i<cnt;i++) {
					temp[i+1]=list[i];
				}
				list=temp;
				temp=null;
			}
			System.out.println(Arrays.toString(list));
		}
		return list;
		
	}
	
	//set(int idx, int val): void 값 수정  
	int[] set(int idx,int val,int[] list) {
		if(tryCatch(idx, list)) {
			for(int i=0;i<list.length;i++) {
				if(i==idx) {
					list[idx]=val;
					break;
				}
			}
			System.out.println(Arrays.toString(list));
		}
		return list;
	}
	
	
	
	//remove(int idx): void 값 삭제 
	int[] remove(int idx,int[] list) {
		if(tryCatch(idx, list)) {
			int[] temp=new int[list.length-1];
			for(int i=0;i<idx;i++) {
				temp[i]=list[i];
			}
			for(int i=idx;i<temp.length;i++) {
				temp[i]=list[i+1];
			}
			list=temp;
			System.out.println(Arrays.toString(list));
		}
		return list;
	}
	
	//clear() :void 값 전부 삭제
	int[] clear(int[] list) {
		list=new int[0];
		System.out.println(Arrays.toString(list));
		return list;
	}
}


class MyArrayListG <T>{
	// size() add() add() set() remove() clear()
	Object[] list;
	void add(T d) {
		if(list == null) {
			list = new Object[1];
		}else {
			Object[] temp = list;
			list = new Object[list.length+1];
			for(int i = 0; i < temp.length; i++) {
				list[i] = temp[i];
			}
			
		}
		list[list.length-1] = (T)d;
	}
	void add(int idx , T val) {
		if(idx <0 || idx > list.length) {
			throw new IndexOutOfBoundsException();
		}
		Object[] temp = list;
		list = new Object[list.length+1];
		int index =0;
		for(int i =0; i < list.length; i++) {
			if(idx== i) {
				list[i] = (T)val;
			}else {
				list[i] = temp[index];
				index++;
			}
		}
	}
	void set(int idx, T val) {
		if(idx <0 || idx >= list.length) {
			throw new IndexOutOfBoundsException();
		}
		list[idx] = (T)val;
	}
	void remove(int idx) {
		if(idx <0 || idx >= list.length) {
			throw new IndexOutOfBoundsException();
		}
		Object[] temp = list;
		list = new Object[list.length-1];
		int index =0;
		for(int i =0; i < temp.length; i++) {
			if(idx!=i) {
				list[index] = temp[i];
				index++;
			}
		}
	}
	int size() {
		if(list == null) {
			return 0;
		}
		return list.length;
	}
	
	
	@Override
	public String toString() {
		String data="";
		if(list != null) {
			for(Object val : list) {
				data+= val +",";
			}
			data = data.substring(0,data.length()-1);
		}
		return "[" + data +"]";
	}
	void clear() {
		list = null;
	}
}


public class 어레이리스트 {

	public static void main(String[] args) {
		// 래퍼 클래스 원시타입의 자료형을 감싼 클래스 
		// int 하는 원시타입 : 순수하게 값만 저장 
		// Interger 클래스 : 값 저장 + 기능
		int num = 10;
	
      // 고정된 배열을 가변배열로 활요할 수 있게 하는 클래스다 
		ArrayList<Integer> numlist = new ArrayList<Integer>();
		System.out.println(numlist.size()); // length : 길이값을 출력
		numlist.add(10);
		numlist.add(20);
		System.out.println(numlist.size()); // length : 길이값을 출력
		numlist.add(30);
		numlist.add(40);
		System.out.println(numlist.size()); // length : 길이값을 출력
		System.out.println(numlist);
		// 삭제 
		numlist.remove(0);
		System.out.println(numlist);
		// 수정 
		numlist.set(1, 10000);
		System.out.println(numlist);
		// 삽입
		numlist.add(2, 100);
		System.out.println(numlist);
		numlist.clear(); // 초기화 
		System.out.println(numlist);
		
		
		System.out.println("=========");
		MyArrayList myList = new MyArrayList();
		int[] arr = null;
		//사이즈
		System.out.println(myList.size(arr));
		//애드
		arr=myList.add(10,arr); // [10]
		arr=myList.add(20,arr); // [10, 20]
		arr=myList.add(30,arr); // [10, 20, 30]
		//애드삽입
		arr=myList.add(1, 1000,arr);
		arr=myList.add(0,7678,arr);
		//수정
		arr=myList.set(2,4667,arr);
		//삭제
		arr=myList.remove(1, arr);
		arr=myList.remove(3, arr);
		//초기화
		arr=myList.clear(arr);
		
		System.out.println(myList.size(arr));
		
		
		
//		double num = 12.32;
//	    int num2 = (int)num; // 12 : 강제 형변환 
//
//		MyArrayListG myList = new MyArrayListG();
//		System.out.println(myList.size());
//		myList.add(10.0); // [10]
//		myList.add(20.4); // [10, 20]
//		System.out.println(myList);
//		System.out.println(myList.size());
//		myList.add(0, 100);
//		System.out.println(myList);
//		myList.set(1, 1000);
//		System.out.println(myList);
//		myList.remove(0);
//		System.out.println(myList.size());
//		myList.clear();
//		System.out.println(myList.size());
		
		
	}

}