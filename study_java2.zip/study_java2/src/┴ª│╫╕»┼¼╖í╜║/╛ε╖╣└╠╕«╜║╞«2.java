package 제네릭클래스;

public class 어레이리스트2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
