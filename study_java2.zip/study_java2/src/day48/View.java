package day48;

public class View {

	
	void view1() {
		System.out.println("----------------------");
		System.out.println("〓〓〓〓SOKOBAN〓〓〓〓");
		System.out.println("----------------------");
	}
	
	void view2() {
		System.out.println("======================");
	}
	
	void view3() {
		System.out.println(" 유저번호   아이디   최고기록    랭킹\n------------------------------");
	}
}
