package day31;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 모두의마블 {

	public static void main(String[] args) {

		/*
		[문제]
			아래 그림을 참고해 배열을 생성하한다.
			2인용 게임으로 서로 번갈아가며 주사위를 던진다.(입력받거나 랜덤으로)
			주사위의 숫자만큼 이동하여, 3바퀴를 먼저 돌면 
			승리하는 게임이다.
			단, 이동할 때 외곽으로만 이동할 수 있다.

			p1 = 0[0바퀴]
			p2 = 0[0바퀴]
			   *    □    □    □    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p1]차례 주사위 입력(1 ~ 6) : 3
			p1 = 3[0바퀴]
			p2 = 0[0바퀴]
			   홋    □    □    솟    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p2]차례 주사위 입력(1 ~ 6) : 5
			p1 = 3[0바퀴]
			p2 = 5[0바퀴]
			   □    □    □    솟    □ 
			   □    ■    ■    ■    홋 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p1]차례 주사위 입력(1 ~ 6) : 2
			p1 = 5[0바퀴]
			p2 = 5[0바퀴]
			   □    □    □    □    □ 
			   □    ■    ■    ■    솟홋
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    □ 
		
			[p2]차례 주사위 입력(1 ~ 6) : 3
			p1 = 5[0바퀴]
			p2 = 8[0바퀴]
			   □    □    □    □    □ 
			   □    ■    ■    ■    솟 
			   □    ■    ■    ■    □ 
			   □    ■    ■    ■    □ 
			   □    □    □    □    홋
		 */
		
		Scanner s=new Scanner(System.in);
		Random r=new Random();
		
		int[][] moma=new int[5][5];
		int[][] temp=new int[1][1];
		int[] win=new int[10];
		
		int turn=1;
		int x=0;
		int y=0;
		int xIdx=0;
		int yIdx=0;
		int edge=0;
		int dir=1;
		
		int wc=0;
		int c1=0;
		int c2=0;
		
		
		

		while(true) {
			moma[y][x]=1;
			for(int i=0;i<moma.length;i++) {
				for(int j=0;j<moma[i].length;j++) {
					if(moma[i][j]==1) {
						y=i;x=j;
						break;
					}
				}
			}
			for(int i=0;i<moma.length;i++) {
				for(int j=0;j<moma[i].length;j++) {
					if(i>0&&i<moma[i].length-1&&j>0&&j<moma[i].length-1) {System.out.print("■  ");}
					else {
						if(moma[i][j]==1) {System.out.print("옷  ");}
						else {System.out.print("□  ");}
					}
				}System.out.println();
			}System.out.println();
			
			System.out.println("플레이어"+turn+" 차례");
			System.out.println("게임 시작");
			String g=s.nextLine();
			int dice=r.nextInt(6)+1;
			System.out.println("주사위 수 : "+dice);
			
			for(int i=0;i<moma.length;i++) {
				for(int j=0;j<moma[i].length;j++) {
					if(moma[i][j]==1) {moma[i][j]=0;}
				}
			}
				
				if(dir==1) {
					if(x+dice>moma.length-1) {
						edge=(moma.length-1)-x;
						dice-=edge;
						x+=edge;
						if(dice<moma.length) {
							y=dice;
							dir++;
						}
						else {
							y=moma.length-1;
							edge=dice-moma.length;
							x-=edge;
							dir+=2;
						}
					}
					else {yIdx=y;xIdx=x+=dice;}
				}
				else if(dir==2) {
					if(y+dice>moma.length-1) {
						edge=(moma.length-1)-y;
						dice-=edge;
						y+=edge;
						if(dice<moma.length) {
							x-=dice;
							dir++;
						}
						else {
							x=0;
							edge=dice-moma.length;
							y-=edge;
							dir+=2;
						}
					}
					else{yIdx=y+=dice;xIdx=x;}
				}
				else if(dir==3) {
					if(x-dice<0) {
						edge=x-0;
						dice-=edge;
						x-=edge;
						if(dice<moma.length) {
							y-=dice;
							dir++;
						}
						else {
							y=0;
							edge=dice-moma.length;
							x+=edge;
							dir+=2;
						}
					}
					else {yIdx=y;xIdx=x-=dice;}
				}
				else if(dir==4) {
					if(y-dice<0) {
						edge=y-0;
						dice-=edge;
						y-=edge;
						if(dice<moma.length) {
							x+=dice;
							dir=1;
						}
						else {
							x=moma.length-1;
							edge=dice-moma.length;
							y+=edge;
							dir=2;
							if(turn==1) {win[wc]=1;c1++;}
							else if(turn==2) {win[wc]=2;c2++;}
							wc++;
						}
					}
					else {yIdx-=dice;xIdx=x;}
				}
			
			System.out.printf("[y : %d][x : %d]\n",y,x);
			if(c1==3) {System.out.println("player1 승리");break;}
			if(c2==3) {System.out.println("player2 승리");break;}
			turn=turn==1?2:1;
			
			
		}
	}

}
