package day42;

public class _MemberMain {

	public static void main(String[] args) {

		MemberController controller=new MemberController();
		controller.init();
		controller.run();
	}

}
