package day42;

import java.util.Scanner;

public class MemberDAO {

	Scanner s;
	int max;
	int memberCount;
	Member[] memberList;
	
	/*초기화*/
	MemberDAO(){
		s=new Scanner(System.in);
		memberCount=0;
		init(100);
	}
	
	void init(int size) {
		memberList=new Member[size];
		max=size;
	}
	
	/*Tools and Exceptions*/
	String getValueString(String msg) {
		System.out.print(msg+" 입력하다. : ");
		return s.next();
	}
	
	int findIdx(String id) {
		int idx=-1;
		for(int i=0;i<memberCount;i++) {
			if(memberList[i].id.equals(id)) {idx=i;break;}
		}
		return idx;
	}
	
	boolean isValidatePwd(int idx, String pwd) {
		if(memberList[idx].pw.equals(pwd)) return true;
		return false;
	}
	
	/*CRUD구현*/
	void join() {
		s=new Scanner(System.in);
		String id=getValueString("아이디를");
		String pwd=getValueString("패스워드를");
		String name=getValueString("이름을");
		
		memberList[memberCount]=new Member(id,pwd,name);
		
		System.out.println("["+name+"회원가입 완료.]");
		memberCount++;
	}
	
	void delete() {
		if(memberCount==0) {System.err.println("삭제할 멤버가 없다.");return;}
		String id=getValueString("삭제할 아이디를");
		int idx=findIdx(id);
		if(idx==-1) {System.err.println("없는 아이디.");return;}
		
		String pwd=getValueString("패스워드를");
		if(!isValidatePwd(idx, pwd)) {System.err.println("비밀번호 오류.");return;}
		
		for(int i=idx;i<memberCount-1;i++) {
			memberList[i]=memberList[i+1];
		}
		memberList[memberCount-1]=null;
		
		System.out.println("["+id+"삭제 완료.]");
		memberCount--;
	}
	
	void update() {
		if(memberCount==0) {System.err.println("수정할 멤버가 없다.");return;}
		String id=getValueString("패스워드 수정할 아이디를");
		int idx=findIdx(id);
		if(idx==-1) {System.err.println("없는 아이디.");return;}
		
		String pwd=getValueString("패스워드를");
		if(!isValidatePwd(idx, pwd)) {System.err.println("비밀번호 오류.");return;}
		
		String newPwd=getValueString("새로운 패스워드를");
		memberList[idx].pw=newPwd;
		System.out.println("[패스워드 수정 완료.]");
	}
	
	void printAll() {
		if(memberCount==0) {System.err.println("보여줄 멤버가 없다.");return;}
		for(int i=0;i<memberCount;i++) {
			System.out.println("["+memberList[i].id+"] | ["+memberList[i].name+"]");
		}
	}
	
	

}