package day42;

public class Member {
 
	String id;
	String pw;
	String name;
	
	public Member(String id, String pw, String name) {
		this.id = id;
		this.pw = pw;
		this.name = name;
	}

	void printMember() {
		System.out.println(id+" : "+pw+" : "+ name);
	}

}
