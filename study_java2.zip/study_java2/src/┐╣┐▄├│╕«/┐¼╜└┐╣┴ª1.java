package 예외처리;

import java.util.InputMismatchException;
import java.util.Scanner;

class Ex001{
	int getValue(String msg ,int start, int end) {
		Scanner sc = new Scanner(System.in);
		
		int num=0;
		
		try {
			System.out.printf("%s[%d-%d] 입력: ",msg, start,end );
			num = sc.nextInt();
			if(num < 0 || num > 100) {
				// 위에것 한줄로 처리 
				throw new Exception("1~100사이 숫자만 입력하다.");
			}
		} catch(InputMismatchException e) {
			// 숫자값 입력 : 숫자 아닌 값 에외처리 
			System.err.println("숫자만 입력해 주세요");
//			e.printStackTrace();
		} catch(Exception e) {
			// start end 범위 벗어난 숫자값 에외처리
			num=0;
			System.err.println("1~100사이 숫자만 입력하다.");
//			e.printStackTrace();
		} finally {
			sc.close();
		}
		return num;
			
		
		
	}
}
public class 연습예제1 {

	public static void main(String[] args) {

		Ex001 e1 = new Ex001();
		System.out.println("num =" + e1.getValue("숫자값 입력 ", 1, 100));
		
	}

}
