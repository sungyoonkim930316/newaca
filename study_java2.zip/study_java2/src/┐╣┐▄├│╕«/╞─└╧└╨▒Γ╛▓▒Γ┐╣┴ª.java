package 예외처리;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Arrays;
import java.util.Scanner;

public class 파일읽기쓰기예제 {

	public static void main(String[] args) {

		// ctrl + shift + o 
		Scanner scan = new Scanner(System.in);

		String nameData = "김철수,이만수,이영희";
		String ageData ="20,30,40";
		String fileName = "src/예외처리/file03.txt";
		String data = "";		
		
		String[] nameList = null;
		nameList=nameData.split(",");
		int [] ageList = null;	
		String[] temp=ageData.split(",");
		ageList=new int[temp.length];
		for(int i=0;i<ageList.length;i++) {
			ageList[i]=Integer.parseInt(temp[i]);
		}
		System.out.println(Arrays.toString(ageList));
		
		FileWriter fw  = null;
		FileReader fr = null;
		
		while(true) {
						
			System.out.println("[0] 종료 [1] 저장 [2] 로드");
			int sel = scan.nextInt();
			if(sel == 0) {
				break;
			}
			else if(sel == 1) {
//				[저장] 김철수/20\n이만수/30\n이영희/40 이렇게 데이터를 만들어 파일 생성후 저장하시오. 
				try {
					fw=new FileWriter(fileName);
					for(int i=0;i<nameList.length;i++) {
						fw.write(nameList[i]+","+String.valueOf(ageList[i])+"\n");
					}
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					try {
						fw.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
					System.out.println("파일"+fileName+" 생성 완료");
				}
			}
			else if(sel == 2) {
//				[로드] 파일을 불러와서 nameList, ageList 배열에 저장하시오 
				try {
					fr=new FileReader(fileName);
					int read=0;
					while(read!=-1) {
						read=fr.read();
						data+=(char)read;
					}
				} catch (FileNotFoundException e) {
					System.out.println("파일이 존재하지 않습니다");
//					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				} finally {
					if(fr!=null) {
						try {
							fr.close();
						} catch (IOException e) {
							e.printStackTrace();
						}
					}
				}
				System.out.println(data);
			}
			
		}
		
	}

}
