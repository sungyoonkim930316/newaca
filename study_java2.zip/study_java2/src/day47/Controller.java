package day47;

public class Controller {

	SkbDAO sd=new SkbDAO();
	UserDAO ud=new UserDAO();
	
	void run() {
		int control=0;
		while(true) {
			control=ud.loginMenu();
			
			if(control==-1) continue;
			else if(control==-2) return;
			else control=ud.playMenu(control);
			
			if(control==-1) continue;
			else if(control==-2) return;
			else break;
		}
		
		sd.setMap();
		sd.playGame(control);
	}
	
}
