package day47;

public class Skb {

	private int[][] map=new int[7][7];
	private int[] info=new int[4];
	private int win=0;
	
	
	public int[][] getMap() {
		return map;
	}
	public void setMap(int[][] map) {
		this.map = map;
	}
	public int[] getInfo() {
		return info;
	}
	public void setInfo(int[] info) {
		this.info = info;
	}
	public int getWin() {
		return win;
	}
	public void setWin(int win) {
		this.win = win;
	}
	
	
	
}
