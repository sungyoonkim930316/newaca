package day47;

import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;

public class GameDAO {

	ArrayList<Game> gameList=new ArrayList<Game>();
	Skb el=new Skb();
	
//	int gameMenu() {
//		int sel=-1;
//		System.out.println("\n[1]진행 [2]저장 [3]뒤로가기 [4]종료");
//		while(sel==-1) {
//			sel=Input.getValue("메뉴선택. ", 1, 4);
//		}
//		
//		if(sel==1) return sel;
//		if(sel==2) {saveGameData(el.getMap()); return sel;}
//		if(sel==3) {}
//		if(sel==4) {System.out.println("[프로그렘 종료.]"); return -1;}
//		return -1;
//	}
	
	void saveGameData(int[][] map) {
		String fileName = "src/day47/sokobansavefile.txt";
		FileWriter fw = null;
		try {
			 fw = new FileWriter(fileName);
			 for(int[] i:map) {
				 for(int j:i) {
					 String text=String.valueOf(j);
					 fw.write(text);
				 }
//				 fw.write("\n");
			 }
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				fw.close();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
			System.out.println("현재 게임 저장완료");
		}
	}
	
}
