package ATM;

import java.util.ArrayList;
import java.util.Random;

public class AccountDAO {
	
	static ArrayList<Account> accountList=new ArrayList<Account>();
	
	/*연습용으로 제시된 기존 고정 데이터 넣는 메서드*/
	void addAccount(String data) {
		String[] temp=data.split("\n");
		int size=temp.length;
		for(int i=0;i<size;i++) {
			String[] info=temp[i].split("/");
			Account a=new Account(info[0],info[1],Integer.parseInt(info[2]));
			accountList.add(a);
		}
	}
	
//	void plusNewAccount() {
//		String acc=Util.getValue("가입할 아이디를 입력하다.");
//		Client c=checkId(id);
//		if(c==null) {
//			String pwd=Util.getValue("패스워드를 입력하다.");
//			String name=Util.getValue("이름을 입력하다.");
//			c=new Client(id,pwd,name);
//			clientList.add(c);
//			System.out.print("["+id+"] 회원가입 완료.\n");
//		}
//		else {System.out.println("[이미 존재하는 아이디.]");}
//	}
	
	void getRandomAccountNumber() {
		Random r=new Random();
		String acc="0000-0000-0000";
		
		String[] temp=new String[3];
		int[] newAcc=new int[temp.length];
		for(int i=0;i<newAcc.length;i++) {
			newAcc[i]=r.nextInt(10000)+1000;
		}
		
	}

}
