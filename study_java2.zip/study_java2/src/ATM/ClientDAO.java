package ATM;

import java.util.ArrayList;

public class ClientDAO {
	static ArrayList<Client> clientList=new ArrayList<Client>();
	static ArrayList<Account> accountList=new ArrayList<Account>();
	
	/*User Section-----------------------------------------------------------------------*/

	/*연습용으로 제시된 기존 고정 데이터 넣는 메서드*/
	void addClient(String data) {
		String[] temp=data.split("\n");
		int size=temp.length;
		for(int i=0;i<size;i++) {
			String[] info=temp[i].split("/");
			Client c=new Client(info[0],info[1],info[2]);
			clientList.add(c);
		}
	}
	
	void join() {
		String id=Util.getValue("가입할 아이디를 입력하다.");
		Client c=checkId(id);
		if(c==null) {
			String pwd=Util.getValue("패스워드를 입력하다.");
			String name=Util.getValue("이름을 입력하다.");
			c=new Client(id,pwd,name);
			clientList.add(c);
			System.out.print("["+id+"] 회원가입 완료.\n");
		}
		else {System.out.println("[이미 존재하는 아이디.]");}
	}
	
	String login() {
		String id=Util.getValue("아이디를 입력하다.");
		Client c=checkId(id);
		if(c!=null) {
			while(true) {
				String pwd=Util.getValue("패스워드를 입력하다.");
				if(c.getpwd().equals(pwd)) {
					System.out.println("["+id+"] 로그인 성공.");
					return c.getId();
				}
				else {System.out.println("패스워드 입력 오류.");continue;}
			}
		} 
		else {
			System.out.println("존재하지 않는 아이디.");
			return "fail";
		}
	}
	
	void showMyPage(String userId) {
		int idx=findClientIdxByIdFromClientList(userId, clientList);;
		System.out.println(clientList.get(idx));
		for(int i=0;i<AccountDAO.accountList.size();i++) {
			if(AccountDAO.accountList.get(i).getId().equals(userId)) {
				System.out.println("[계좌 : "+AccountDAO.accountList.get(i).getAccount()+"] [잔엑 : "+AccountDAO.accountList.get(i).getMoney()+"]");
			}
		}
		System.out.println("================");
	}
	
	
	/*Admin Section-----------------------------------------------------------------------*/
	
	
	void showUserList() {
		System.out.println(clientList);
		System.out.println("================");
	}
	
	void updateUser() {
		int idx=-1;
		while(true) {
			String id=Util.getValue("수정할 회원의 아이디를 입력하다. ");
			boolean check=isId(id, clientList);
			if(check) {
				idx=findClientIdxByIdFromClientList(id, clientList);
				break;
			}
			else {System.out.println("존재하지 않는 아이디");continue;}
		}
		if(idx!=-1) {
			String ip="";
			while(true) {
				ip=Util.getValue("수정할 정보를 입력하다. ");
				if(ip.equals("id") || ip.equals("pwd") || ip.equals("name")) break;
				else System.out.println("입력오류");
			}
			if(ip.equals("id")) {
				String id=Util.getValue("새 아이디를 입력하다. ");
				clientList.set(idx, new Client(id, clientList.get(idx).getpwd(), clientList.get(idx).getName()));
				accountList.set(idx, new Account(id, accountList.get(idx).getAccount(), accountList.get(idx).getMoney()));
				System.out.println("아이디 변경 완료.");
			}
			else if(ip.equals("pwd")) {
				String pwd=Util.getValue("새 비번을 입력하다. ");
				clientList.set(idx, new Client(clientList.get(idx).getId(), pwd, clientList.get(idx).getName()));
				System.out.println("비번 변경 완료.");
			}
			else if(ip.equals("name")) {
				String name=Util.getValue("새 이름을 입력하다. ");
				clientList.set(idx, new Client(clientList.get(idx).getId(), clientList.get(idx).getpwd(), name));
				System.out.println("이름 변경 완료.");
			}
		}
	}
	
	void deleteUser() {
		int idx=-1;
		String id="";
		while(true) {
			id=Util.getValue("삭제할 회원의 아이디를 입력하다. ");
			boolean check=isId(id, clientList);
			if(check) {
				idx=findClientIdxByIdFromClientList(id, clientList);
				break;
			}
			else {System.out.println("존재하지 않는 아이디");continue;}
		}
		if(idx!=-1) {
			clientList.remove(idx);
			System.out.println("["+id+"] 삭제완료.");
		}
		else System.out.println("삭제실패.");
	}
	
	
	/*ETC Section-----------------------------------------------------------------------*/
	
	
	boolean isId(String id, ArrayList<Client> clientList) {
		for(int i=0;i<clientList.size();i++) {
			if(clientList.get(i).getId().equals(id)) return true;
		}
		return false;
	}
	
	int findClientIdxByIdFromClientList(String id, ArrayList<Client> clientList) {
		int idx=-1;
		for(int i=0;i<clientList.size();i++) {
			if(clientList.get(i).getId().equals(id)) idx=i;
		}
		return idx;
	}
	
	Client checkId(String id) {
		for(Client c:clientList) {
			if(c.getId().equals(id)) return c;
		}
		return null;
	}
	
}
