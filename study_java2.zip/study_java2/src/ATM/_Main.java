package ATM;

public class _Main {

	public static void main(String[] args) {

		BankController bct=new BankController();
		bct.setSampleData();
		bct.run();
		
	}

}
