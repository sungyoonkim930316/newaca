package ATM;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class File {
	
	void saveUserInfo() {
		String fileName="src/ATM/userDataFile.txt";
		FileWriter fw=null;
		try {
			 fw=new FileWriter(fileName);
			 fw.write("[");
			 for(int i=0;i<ClientDAO.clientList.size();i++) {
				 String text="";
				 text+="[아이디 : "+ClientDAO.clientList.get(i).getId()+", 비번 : "+ClientDAO.clientList.get(i).getpwd()+", 이름 : "+ClientDAO.clientList.get(i).getName()+"],";
				 fw.write(text);
			 }
			 fw.write("]");
		} 
		catch (IOException e) {
			e.printStackTrace();
		}
		finally {
			try {
				fw.close();
			} 
			catch (IOException e) {
				e.printStackTrace();
			}
		}
		System.out.println("유저정보 파일 생성 완료.");
		System.out.println("================");
	}
	
	void loadUserInfo() {
		String fileName="src/ATM/userDataFile.txt";
		FileReader fr=null;
		String data="";
		try {
			fr=new FileReader(fileName);
			int read=0;
			while(read!=-1) {
				read=fr.read();
				data+=(char)read;
			}
			
		} catch (FileNotFoundException e) { 
		} catch (IOException e) {
			e.printStackTrace();
		}finally {
			if(fr!=null) {
				try {
					fr.close();
				} 
				catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		System.out.println(data);
		System.out.println("================");
	}

}
