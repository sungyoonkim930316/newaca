package day36;

import java.util.Arrays;
import java.util.Scanner;

class User{
	String id;
}
class Seat{
	int y;
	int x;
	String userId;
	boolean check;
	int price;
}

public class 시험5 {

	public static void main(String[] args) {
		int seatPrice=12000;
		
		String[] userIdList={"aaa" , "bbb" , "ccc"};
		String[][] seatUserIdList={
			{null	,"aaa"	,"aaa"  ,null},
			{null   ,null 	,"bbb" 	,null},
			{"ccc" 	,"bbb" 	,null 	,"bbb"}
		};
		
		User[] userList=null;
		userList=new User[userIdList.length];
		for(int i=0;i<userList.length;i++) {
			User us=new User();
			us.id=userIdList[i];
			userList[i]=us;
		}
		
		
		Seat[] seatList=null;
		int seatSize=12;
		seatList=new Seat[seatSize];
		int a=0;
		int b=0;
		for(int i=0;i<seatList.length;i++) {
			Seat st=new Seat();
			st.y=a;
			st.x=b;
			st.userId=seatUserIdList[a][b];
			st.check=seatUserIdList[a][b]==null?false:true;
			st.price=seatUserIdList[a][b]==null?0:12000;
			seatList[i]=st;
			b++;
			if(b%4==0) {a++;b=0;}
		}
		
		Scanner s=new Scanner(System.in);
		
		while(true) {
			System.out.println("[0] 종료\n"
					+ "[1] 전체출력\n"
					+ "[2] 회원 aaa가 예약한 자리와 요금출력\n"
					+ "[3] 예약가능한자리 위치출력 \n"
					+ "[4] 예약을 가장많이한 회원출력");
			int sel=s.nextInt();
			if(sel==0) break;
			else if(sel==1) {
				System.out.println("===[좌석예매]===");
				for(int i=0;i<seatSize;i++) {
					if(seatList[i].check) System.out.printf("[%5s]", seatList[i].userId);
					else System.out.printf("[%5s]","");
					if(i%4==3) System.out.println();
				}
			}
			else if(sel==2) {
				int sum=0;
				for(int i=0;i<seatList.length;i++) {
					if(seatList[i].userId!=null) {
						if(seatList[i].userId.equalsIgnoreCase("aaa")) {
							System.out.printf("[%5s]", seatList[i].userId);
							sum+=seatList[i].price;
						}
						else System.out.printf("[%5s]","XXX");
					}
					else System.out.printf("[%5s]","");
					if(i%4==3) System.out.println();
				}
				System.out.println("총 금액은 "+sum+"원 입니다.");
			}
			else if(sel==3) {
				for(int i=0;i<seatList.length;i++) {
					if(seatList[i].userId!=null) {
						if(seatList[i].userId.equalsIgnoreCase("aaa")) System.out.printf("[%5s]", "X");
						else System.out.printf("[%5s]","O");
					}
					else System.out.printf("[%5s]","");
					if(i%4==3) System.out.println();
				}
				String ans="예매 가능한 좌석 번호 : ";
				for(int i=0;i<seatList.length;i++) {
					if(seatList[i].check==false) ans+=(i+1)+", ";
				}
				System.out.println(ans.substring(0,ans.length()-2));
			}
			else if(sel==4) {
				int cnt=0;
				int[] count=new int[userList.length];
				for(int i=0;i<userList.length;i++) {
					for(int j=0;j<seatList.length;j++) {
						if(userList[i].id.equals(seatList[j].userId)) cnt++;
					}
					count[i]=cnt;
					cnt=0;
				}
				int max=0;
				int idx=0;
				for(int i=0;i<count.length;i++) {
					if(count[i]>max) {max=count[i];idx=i;}
				}
				System.out.println(userList[idx].id+"회원");
			}
		}
		
		
	}
}