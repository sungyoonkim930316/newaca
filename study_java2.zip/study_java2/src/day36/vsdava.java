package day36;

import java.util.Scanner;


public class vsdava {

	public static void main(String[] args) {

		int seatPrice = 12000;

		String[] userIdList = { "aaa", "bbb", "ccc" };
		String[][] seatUserIdList = { 
				{ null, "aaa", "aaa", null }, 
				{ null, null, "bbb", null },
				{ "ccc", "bbb", null, "bbb" } 
		};
		User[] userList = null;
		Seat[] seatList = null;
		int seatSize = 12;

		userList = new User[userIdList.length];

		int idx = 0;
		for (String u : userIdList) {
			User us = new User();
			us.id = u;
			userList[idx] = us;
			idx++;
		}
//		System.out.println(userList[0].id);

		seatList = new Seat[seatSize];

		idx = 0;
		for (int i = 0; i < seatUserIdList.length; i++) {
			Seat s = new Seat();
			s.y = i;
			for (int k = 0; k < seatUserIdList[i].length; k++) {
				s.x = k;
				if (seatUserIdList[i][k] != null) {
					s.check = true;
					s.userId = seatUserIdList[i][k];
				} else {
					s.check = false;
					s.userId = "";
				}
				seatList[idx] = s;
				System.out.println("-=-=-=-=-=-=-");
				System.out.println("채크 : "+seatList[idx].check);
				System.out.println("와이 : "+seatList[idx].y);
				System.out.println("액스 : "+seatList[idx].x);
				System.out.println("유저아이디 : "+seatList[idx].userId);
				idx++;
			}
			if(i==1) {
				System.out.println("중간점검=============="+idx);
				System.out.println("채크 : "+seatList[idx-1].check);
				System.out.println("와이 : "+seatList[idx-1].y);
				System.out.println("액스 : "+seatList[idx-1].x);
				System.out.println("유저아이디 : "+seatList[idx-1].userId);
				System.out.println("====================");
			}
			
		}
//		for(int i=0;i<12;i++) {
//			System.out.println("채크 : "+seatList[i].check);
//			System.out.println("와이 : "+seatList[i].y);
//			System.out.println("액스 : "+seatList[i].x);
//			System.out.println("유저아이디 : "+seatList[i].userId);
//		}

		Scanner scan = new Scanner(System.in);

		while (true) {
			System.out.println("[0] 종료\n" + "[1] 전체출력\n" + "[2] 회원 aaa가 예약한 자리와 요금출력\n" + "[3] 예약가능한자리 위치출력 \n"
					+ "[4] 예약을 가장많이한 회원출력");
			int sel = scan.nextInt();
			if (sel < 0 || sel > 4) {
				System.err.println("입력오류");
				continue;
			}
			if (sel == 0) {
				break;
			} else if (sel == 1) {

				System.out.println("===[좌석예매]===");
				for (int i = 0; i < seatSize; i++) {
					if (seatList[i].check) {
						System.out.printf("[%5s]", seatList[i].check);
					} else {
						System.out.printf("[%5s]", seatList[i].check);
					}
					if (i % 4 == 3) {
						System.out.println();
					}
				}

			} else if (sel == 2) {

				System.out.println("===[좌석예매]===");
				int cnt = 0;
				for (int i = 0; i < seatSize; i++) {
					if (seatList[i].userId.equals("aaa")) {
						System.out.printf("[%5s]", seatList[i].userId);
						cnt++;
					} else {
						System.out.printf("[%5s]", "X");
					}
					if (i % 4 == 3) {
						System.out.println();
					}
				}
				System.out.println("총 금액 : " + cnt * seatPrice + "\n");

			} else if (sel == 3) {

				System.out.println("===[좌석예매]===");
				for (int i = 0; i < seatSize; i++) {
					if (seatList[i].check) {
						System.out.printf("[%5s]", "x");
					} else {
						System.out.printf("[%5s]", "o");
					}
					if (i % 4 == 3) {
						System.out.println();
					}
				}

			} else {

			}
		}

		// 시작 9:42
    //
	}

}