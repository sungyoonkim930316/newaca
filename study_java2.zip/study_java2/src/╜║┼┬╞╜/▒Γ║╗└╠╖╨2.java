package 스태틱;

import java.util.ArrayList;

class Card{
	                        // new String[4]
	static String[] kinds= { "◇", "♡", "♣", "♠" };
	static int width=100;
	static int height=150;
	String shape;
	int number;
	
	public Card(String shape, int number) {
		super();
		this.shape = shape;
		this.number = number;
	}

	@Override
	public String toString() {
		return shape+number;
	}
	
}

public class 기본이론2 {

	public static void main(String[] args) {

		
		Card c1 = new Card(Card.kinds[0],8);
		Card c2 = new Card(Card.kinds[1],8);
		Card c3 = new Card(Card.kinds[2],8);
		
		ArrayList<Card> deck = new ArrayList<>();
		deck.add(c1);
		deck.add(c2);
		deck.add(c3);
		deck.add(new Card(Card.kinds[3],8));
		
		//System.out.println(deck.get(2));
		
		for(Card card : deck) {
			System.out.println(card);
		}
		
	}

}