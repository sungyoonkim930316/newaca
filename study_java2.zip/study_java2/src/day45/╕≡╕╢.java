package day45;

import java.util.Random;
import java.util.Scanner;

public class 모마 {

	public static void main(String[] args) {

		Random rd = new Random();
		Scanner sc = new Scanner(System.in);

		int[][] marble = new int[5][5];
		int a = 0;
		int b = 0;
		int a1 = 0;
		int b1 = 0;
		int trun = 1;
		int cnt = 0;
		int cnt1 = 0;

		for(int i=0;i<marble.length;i++) {
			for(int j=0;j<marble[i].length;j++) {
				
				if(i==b && j==a && i==b1 && j==a1) System.out.print("#$");
				else if(i==b && j==a) System.out.print("# ");
				else if(i== b1 && j==a1) System.out.print("$ ");
				else if(i<marble.length-1 && i>0 && j>0 && j<marble.length-1) System.out.print("■ ");
				else System.out.print("□ ");
				
			}
			System.out.println();
		}
		while(true) {

			System.out.println("p"+trun+"턴 [1.주사위 던지기] [2.종료] p1 => " + cnt + " p2 => "+ cnt1);
			int x=sc.nextInt();

			if(x==1) {
				x=rd.nextInt(6)+1;
				System.out.println("p"+trun+" 주사위 ==> "+x);
				
				if(trun==1) {
					for(int i=1;i<=x;i++) {
						
						if(b==0 && a<marble.length-1) a++;
						else if(b<marble.length-1 && a==marble.length-1) b++;
						else if(b==marble.length-1 && a>0) a--;
						else if(b>0 && a==0) b--;
						
						if(a==0 && b==0) cnt++;
						if(cnt==3) {
							System.out.println("p1 win!!!!!");
							break;
						}
					}
					trun++;
				} 
				else {
					for(int i=1;i<=x;i++) {
						if(b1==0 && a1<marble.length-1) a1++;
						else if (b1<marble.length-1 && a1==marble.length-1) b1++;
						else if (b1==marble.length-1 && a1>0) a1--;
						else if (b1>0 && a1==0) b1--;
						
						if(a1==0 && b1==0) cnt1++;
						if(cnt1==3) {
							System.out.println("p2 win!!!!!");
							break;
						}
					}
					trun --;
				}
				
				for (int i = 0; i < marble.length; i++) {
					for (int j = 0; j < marble[i].length; j++) {
						if (i == b && j == a && i == b1 && j == a1) {
							System.out.print("#$");
						} else if (i == b && j == a) {
							System.out.print("# ");
						} else if (i == b1 && j == a1) {
							System.out.print("$ ");
						} else if (i < marble.length - 1 && i > 0 && j > 0 && j < marble.length - 1) {
							System.out.print("■ ");
						} else {
							System.out.print("□ ");
						}
					}
					System.out.println();
				}
				
				if(cnt == 3|| cnt1 == 3) {
					break;
				}
				
//				System.out.println(a);
//				System.out.println(b);

			} else if (x == 2) {
				break;
			} else {
				System.err.println("error");
				continue;
			}

		}
		
	}

}
