package day33;

import java.util.Arrays;

class Member{
	int no;
	int point;
	String name;
	boolean best;
}

public class 클래스배열연습3 {
	public static void main(String[] args) {
		
		String data1 = "1001/3,1002/1,1001/3,1003/5,1004/1,1002/2";
		String data2 = "1001/이만수,1002/김철수,1003/신민아,1004/박상아";
		
		// data1 은 사원번호와 판매실적이다.
		// data2 는 사원번호와 이름이다.
		// 판매실적이 4이상인사원은 best를 true로 저장하세요.
		
		// 문제1) 위데이터를 참고해서 Member 클래스 배열을 완성후 전체출력해보세요.
		// 문제2) 판매실적이 best 인회원 이름출력 
		int king=0;

		Member m=new Member();
		Member[] memberList = null;
		
		String[] temp1=data1.split(",");
		int size1=temp1.length;
		Member[] sell=new Member[size1];
		
		String[] temp2=data2.split(",");
		int size2=temp2.length;
		Member[] name=new Member[size2];
		
		for(int i=0;i<sell.length;i++) {
			String[] info=temp1[i].split("/");
			Member sm=new Member();
			sm.no=Integer.parseInt(info[0]);
			sm.point=Integer.parseInt(info[1]);
			if(sm.point>=4) sm.best=true;
			else sm.best=false;
			sell[i]=sm;
		}
		for(int i=0;i<name.length;i++) {
			String[] info=temp2[i].split("/");
			Member nm=new Member();
			nm.no=Integer.parseInt(info[0]);
			nm.name=info[1];
			name[i]=nm;
		}
		System.out.println("===실적정보===");
		for(int i=0;i<sell.length;i++) {
			if(sell[i].best==true) {king=sell[i].no;}
			System.out.println(sell[i].no+" "+sell[i].point+" "+sell[i].best);
		}
		System.out.println("===사원정보===");
		for(int i=0;i<name.length;i++) {
			System.out.println(name[i].no+" "+name[i].name);
		}
		System.out.println("===========");
		
		for(int i=0;i<name.length;i++) {
			if(name[i].no==king) {System.out.println("우수사원 : "+name[i].name);break;}
		}
		
	}
}