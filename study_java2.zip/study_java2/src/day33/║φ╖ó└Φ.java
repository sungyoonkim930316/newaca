package day33;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 블랙잭 {

	public static void main(String[] args) {

		/* 블랙잭게임 
		자신이 받은 카드의 숫자 합이 21에 가까워야하고 그 숫자가 딜러 카드의 숫자 보다 높으면 이기는 게임이다.

		게임 규칙
		딜러와 게이머 단 2명 존재
		카드는 조커를 제외한 52장이다. (카드는 다이아, 하트, 스페이드, 클로버 무늬를 가진 A,2~10,K,Q,J으로 이루어져 있다.)
		2~13은 숫자 그대로 점수를 J,Q,K는 각 11, 12, 13점으로 A는 1로 계산한다.
		 (기존 규칙은 A는 1과 11 둘다 가능하지만 여기선 1로만 허용)
		딜러와 게이머는 순차적으로 카드를 하나씩 뽑아 각자 2개의 카드를 소지한다.
		게이머는 얼마든지 카드를 추가로 뽑을 수 있다.
		딜러는 2카드의 합계 점수가 16점 이하이면 반드시 1장을 추가로 뽑고, 17점 이상이면 추가 할 수 없다.
		양쪽 다 추가 뽑기 없이 카드를 오픈 하면 딜러와 게이머 중 소유한 카드의 합이 21에 가장 가까운 쪽이 승리한다.
		단 21을 초과하면 초과한 쪽이 진다.
		*/ 
		
		Random r=new Random();
		Scanner s=new Scanner(System.in);
		
		String[][] trump= {
				{"♠A","♠2","♠3","♠4","♠5","♠6","♠7","♠8","♠9","♠10","♠J","♠Q","♠K"},
				{"◇A","◇2","◇3","◇4","◇5","◇6","◇7","◇8","◇9","◇10","◇J","◇Q","◇K"},
				{"♡A","♡2","♡3","♡4","♡5","♡6","♡7","♡8","♡9","♡10","♡J","♡Q","♡K"},
				{"♣A","♣2","♣3","♣4","♣5","♣6","♣7","♣8","♣9","♣10","♣J","♣Q","♣K"}
		};
		int[][] game=new int[trump.length][trump[0].length];
		
		String[] dealer=new String[3];
		String[] player=new String[3];
		
		int cnt=0;
		while(true) {
			
			// 딜러가 카드를 뽑는다.
			while(true) {
				int mark=r.nextInt(trump.length-1);
				int card=r.nextInt(trump[0].length-1);
				if(trump[mark][card].equals("taken")) continue;
				else {
					dealer[cnt]=trump[mark][card];
					trump[mark][card]="taken";
					break;
				}
			}
			
			// 딜러가 카드를 뽑은 후 플레이어가 카드를 뽑는다.
			System.out.println("ENTER를 입력하여 카드 뽑기");
			String go=s.nextLine();
			
			while(true) {
				int mark=r.nextInt(trump.length-1);
				int card=r.nextInt(trump[0].length-1);
				if(trump[mark][card].equals("taken")) continue;
				else {
					player[cnt]=trump[mark][card];
					trump[mark][card]="taken";
					break;
				}
			}
			System.out.println("ㅇ내 카드는 ["+player[cnt]+"]");
			
			cnt++;
			if(cnt==3) break;
		}
		System.out.println("카드선택 완료");
		
		int num=0;
		while(true) {
			System.out.println("====================");
			System.out.println("[1] 내가 뽑은 카드 확인");
			System.out.println("[2] 카드 조합하기");
			System.out.println("[3] 쇼부");
			System.out.println("[4] 기권");
			System.out.println("====================");
			int sel=s.nextInt();
			if(sel==1) {
				System.out.println(Arrays.toString(player));
			}
			else if(sel==3) {
				if(num==0) {System.out.println("카드를 조합해야한다.");continue;}
			}
			else if(sel==4) break;
		
		}
	}
}
