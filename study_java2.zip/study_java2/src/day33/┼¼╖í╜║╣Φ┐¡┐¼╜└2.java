package day33;

import java.util.Arrays;

class Test{
	int num;
	int size;
	char[] data;
}

public class 클래스배열연습2 {
	public static void main(String[] args) {
		
		String data ="";
		data += "0/2/a/b\n";
		data += "1/3/a/b/c\n";
		data += "2/5/a/b/c/d/e\n";
		data += "3/4/a/b/c/d\n";
		data += "4/3/a/b/c\n";
		data += "5/1/a";

		Test[] t;	
        // data의 정보를 클래스배열에 저장.
		String[] temp=data.split("\n");
		int size=temp.length;
		t=new Test[size];
		
		for(int i=0;i<t.length;i++) {
			String[] info=temp[i].split("/");
			Test test=new Test();
			test.num=Integer.parseInt(info[0]);
			test.size=Integer.parseInt(info[1]);
			
			char[] tempor=new char[info.length-2];
			for(int j=2;j<info.length;j++) {
				char c=info[j].charAt(0);
				tempor[j-2]=c;
			}
			test.data=tempor;
			t[i]=test;
		}
		
		for(int i=0;i<t.length;i++) {
			System.out.print(t[i].num+" "+t[i].size+" ");
			System.out.println(Arrays.toString(t[i].data));
		}
		
	}
}
