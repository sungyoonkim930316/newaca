package day33;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class 블랙잭t_rule {

	public static void main(String[] args) {

		Random r=new Random();
		Scanner s=new Scanner(System.in);
		
		/* 블랙잭게임 
		자신이 받은 카드의 숫자 합이 21에 가까워야하고 그 숫자가 딜러 카드의 숫자 보다 높으면 이기는 게임이다.

		게임 규칙
		딜러와 게이머 단 2명 존재
		카드는 조커를 제외한 52장이다. (카드는 다이아, 하트, 스페이드, 클로버 무늬를 가진 A,2~10,K,Q,J으로 이루어져 있다.)
		2~13은 숫자 그대로 점수를 J,Q,K는 각 11, 12, 13점으로 A는 1로 계산한다.
		 (기존 규칙은 A는 1과 11 둘다 가능하지만 여기선 1로만 허용)
		딜러와 게이머는 순차적으로 카드를 하나씩 뽑아 각자 2개의 카드를 소지한다.
		게이머는 얼마든지 카드를 추가로 뽑을 수 있다.
		딜러는 2카드의 합계 점수가 16점 이하이면 반드시 1장을 추가로 뽑고, 17점 이상이면 추가 할 수 없다.
		양쪽 다 추가 뽑기 없이 카드를 오픈 하면 딜러와 게이머 중 소유한 카드의 합이 21에 가장 가까운 쪽이 승리한다.
		단 21을 초과하면 초과한 쪽이 진다.
		*/ 
		int[][] value= {
				{1,2,3,4,5,6,7,8,9,10,11,12,13},
				{1,2,3,4,5,6,7,8,9,10,11,12,13},
				{1,2,3,4,5,6,7,8,9,10,11,12,13},
				{1,2,3,4,5,6,7,8,9,10,11,12,13}
		};
		
		String[][] trump= {
				{"♠A","♠2","♠3","♠4","♠5","♠6","♠7","♠8","♠9","♠10","♠J","♠Q","♠K"},
				{"◇A","◇2","◇3","◇4","◇5","◇6","◇7","◇8","◇9","◇10","◇J","◇Q","◇K"},
				{"♡A","♡2","♡3","♡4","♡5","♡6","♡7","♡8","♡9","♡10","♡J","♡Q","♡K"},
				{"♣A","♣2","♣3","♣4","♣5","♣6","♣7","♣8","♣9","♣10","♣J","♣Q","♣K"}
		};
		String[] dealer=null;
		String[] player=null;
		
		int dcnt=0;
		int dsum=0;
		int pcnt=0;
		int psum=0;
		while(true) {
			dcnt=dealer==null?0:dealer.length;
			pcnt=player==null?0:player.length;
			// 딜러패 정하기
			while(true) {
				int mark=r.nextInt(trump.length-1);
				int card=r.nextInt(trump[0].length-1);
				if(trump[mark][card].equals("taken")) continue;
				else {
					if(dealer==null) {dealer=new String[1];}
					else {
						String[] temp=new String[dcnt+1];
						for(int i=0;i<dcnt;i++) {temp[i]=dealer[i];}
						dealer=temp;
						temp=null;
					}
					dealer[dcnt]=trump[mark][card];
					dsum+=value[mark][card];
					trump[mark][card]="taken";
					dcnt++;
				}
				if(dsum>16) break;
			}
//			System.out.println(dsum);
//			System.out.println(Arrays.toString(dealer));
			
			while(true) {
				System.out.println("[0 : 카드를 뽑다][1 : 쇼부]");
				int draw=s.nextInt();
				if(draw!=0&&draw!=1) {System.out.println("err");continue;}
				if(draw==0) {
					int mark=r.nextInt(trump.length-1);
					int card=r.nextInt(trump[0].length-1);
					if(trump[mark][card].equals("taken")) continue;
					else {
						if(player==null) {player=new String[1];}
						else {
							String[] temp=new String[pcnt+1];
							for(int i=0;i<pcnt;i++) {temp[i]=player[i];}
							player=temp;
							temp=null;
						}
						player[pcnt]=trump[mark][card];
						psum+=value[mark][card];
						trump[mark][card]="taken";
						pcnt++;
					}
					System.out.println(Arrays.toString(player));
				}
				else if(draw==1) break;
			}
			int dshow=21-dsum;
			int pshow=21-psum;
			if(dshow<0) {dshow=dshow-(dshow*2);}
			if(pshow<0) {pshow=pshow-(pshow*2);}
			System.out.println("딜러패");
			System.out.println(Arrays.toString(dealer));
			System.out.println("유저패");
			System.out.println(Arrays.toString(player));
			System.out.println("=============================");
			System.out.printf("[d쇼부 : %d][p쇼부 : %d]",dsum,psum);
			System.out.println();
			if(dshow>pshow) {System.out.println("유저 승리");}
			else if(dshow<pshow) {System.out.println("딜러 승리");}
			else if(dshow==pshow) {System.out.println("무승부");}
			break;
		}
//		System.out.println("카드선택 완료");
		
	}

}
