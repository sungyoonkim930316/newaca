package day33;

import java.util.Arrays;

class Student{
	String name;
	int score;
	
}

public class 클래스배열연습1 {
	public static void main(String[] args) {
		
		String data = ""; 
		data +="김영희/30\n";
		data += "이만수/40\n";
		data += "이철민/60";
		
		
		System.out.println(data);

		Student[] studentList;
		//문제1)data에 있는 내용을 잘라서  studentList 에 저장후 전체출력 
		String[] temp=data.split("\n");
		int size=temp.length;
		studentList=new Student[size];
		
		for(int i=0;i<studentList.length;i++) {
			String[] info=temp[i].split("/");
			Student s=new Student();
			
			s.name=info[0];
			s.score=Integer.parseInt(info[1]);
			studentList[i]=s;
		}
		for(int i=0;i<studentList.length;i++) {
			System.out.println(studentList[i].name+" "+studentList[i].score);
		}
	
		//문제2)꼴등 삭제후 다시 data에 저장	
		int idx=0;
		int min=studentList[0].score;
		for(int i=0;i<studentList.length;i++) {
			if(studentList[i].score<min) {
				min=studentList[i].score;
				idx=i;
			}
		}
		
		for(int i=idx;i<studentList.length-1;i++) {
			studentList[i]=studentList[i+1];
		}
		studentList[studentList.length-1]=null;
		
		String updateData="";
		for(int i=0;i<studentList.length-1;i++) {
			updateData+=studentList[i].name+"/"+studentList[i].score+"\n";
		}
		
		updateData=updateData.substring(0,updateData.length()-1);
		
		System.out.println(updateData);
	}
}
