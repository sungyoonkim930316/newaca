package day39;

import java.util.Arrays;
import java.util.Random;

class Player {
	String name;
	Card c1;
	Card c2;
	boolean win; 
}

class Card {
	String shape;
	int num;
	int score;
}

class CardGame{
	Card deck[] = new Card[40];
	String shapes[] = {"♠", "◇", "♡", "♣"};
	
	void init() {
		int ncnt=1;
		int scnt=0;
		for(int i=0;i<deck.length;i++) {
			deck[i]=new Card();
			deck[i].num=ncnt;
			deck[i].shape=shapes[scnt];
			
			if(deck[i].shape.equals("♠")) deck[i].score=4;
			if(deck[i].shape.equals("◇")) deck[i].score=3;
			if(deck[i].shape.equals("♡")) deck[i].score=2;
			if(deck[i].shape.equals("♣")) deck[i].score=1;
			
			ncnt++;
			if(i%10==9) {scnt++;ncnt=1;}
		}
	}
	
	void shuffle() {
		Random r=new Random();
		Card[] temp=new Card[deck.length];
		for(int i=0;i<50;i++) {
			int sf=r.nextInt(deck.length);
			temp[0]=deck[0];
			deck[0]=deck[sf];
			deck[sf]=temp[0];
		}
	}
	
	void pickCard() {
		Player[] pc= {new Player(), new Player()};
		
		for(int i=0;i<2;i++) {
			pc[i].name="p"+String.valueOf(i+1);
			Card c1=deck[i];
			pc[i].c1=c1;
			Card c2=deck[i+2];
			pc[i].c2=c2;
			System.out.println(pc[i].name+"|["+pc[i].c1.shape+":"+pc[i].c1.num+"]["+pc[i].c2.shape+":"+pc[i].c2.num+"]");
		}
		doShobu(pc);
	}
	
	void doShobu(Player[] a) {
		int s1=a[0].c1.num+a[0].c2.num;
		int s2=a[1].c1.num+a[1].c2.num;
		if(s1==s2) {
			s1=a[0].c1.score+a[0].c2.score;
			s2=a[1].c1.score+a[1].c2.score;
			if(s1==s2) {System.out.println("무승부.");return;}
		}
		System.out.println(s1>s2?a[0].name+" 승리.":a[1].name+" 승리.");
	}
	
	void run() {
		init();
		shuffle();
		pickCard();
	}
}

public class 클래스배열카드게임 {
	
	public static void main(String[] args) {
		CardGame cg=new CardGame();
		cg.run();
	}

}
