package day40;

class Item{
	int itemNumber;
	String itemName;
	
	Item(int itemNumber, String itemName) {
		this.itemNumber = itemNumber;
		this.itemName = itemName;
	}
}

class ItemDAO{
	Item[] itemList;
	
	void createItemList(String[] list) {
		int size=list.length;
		itemList=new Item[size];
		for(int i=0;i<size;i++) {
			String[] temp=list[i].split("/");
			itemList[i]=new Item(Integer.parseInt(temp[0]),temp[1]);
		}
	}
}

class User{
	int userNumber;
	String userName;
	
	User(int userNumber, String userName) {
		this.userNumber = userNumber;
		this.userName = userName;
	}
}

class UserDAO{
	User[] userList;
	
	void createUserList(String[] list) {
		int size=list.length;
		userList=new User[size];
		for(int i=0;i<size;i++) {
			String[] temp=list[i].split("/");
			userList[i]=new User(Integer.parseInt(temp[0]),temp[1]);
		}
	}
}

class Cart{
	int userNumber;
	int itemNumber;
	
	Cart(int userNumber, int itemNumber) {
		this.userNumber = userNumber;
		this.itemNumber = itemNumber;
	};
}

class CartDAO{
	Cart[] cartList;
	
	void createCartList(String[] list) {
		int size=list.length;
		cartList=new Cart[size];
		for(int i=0;i<size;i++) {
			String[] temp=list[i].split("/");
			cartList[i]=new Cart(Integer.parseInt(temp[0]),Integer.parseInt(temp[1]));
		}
	}
}

class Functions{
	String[] devideString(String data) {
		String temp[]=data.split(",");
		return temp;
	}
	
	void solveQ1(User[] user, Item[] item, Cart[] cart) {
		
		for(int i=0;i<user.length;i++) {
			System.out.printf("%s==> ",user[i].userName);
			int[] itemCnt=new int[item.length];
			int idx=0;
			for(int j=0;j<item.length;j++) {
				for(int k=0;k<cart.length;k++) {
					if(item[j].itemNumber==cart[k].itemNumber && user[i].userNumber==cart[k].userNumber) itemCnt[idx]++;
				}
				if(itemCnt[idx]>0) System.out.printf("%s%d ",item[j].itemName,itemCnt[idx]);
				
				idx++;
			}
			if(i<user.length-1) System.out.print("/ ");
		}
	}
	
	void solveQ2(User[] user, Item[] item, Cart[] cart) {
		for(int i=0;i<item.length;i++) {
			System.out.printf("%s==> ",item[i].itemName);
			for(int j=0;j<user.length;j++) {
				for(int k=0;k<cart.length;k++) {
					if(item[i].itemNumber==cart[k].itemNumber && user[j].userNumber==cart[k].userNumber) {
						System.out.print(user[j].userName+" ");
						break;
					}
				}
			}
			if(i<user.length-1) System.out.print("/ ");
		}
	}
}

public class 클배장바구니 {
	public static void main(String[] args) {
		
		ItemDAO id=new ItemDAO();
		UserDAO ud=new UserDAO();
		CartDAO cd=new CartDAO();
		
		Functions f=new Functions();
		
		String itemData = "1001/고래밥,1002/새우깡,1003/칸쵸";
		String[] itemTemp=f.devideString(itemData);
		id.createItemList(itemTemp);
		
		String userData = "3001/이만수,3002/김철민,3003/이영희";
		String[] userTemp=f.devideString(userData);
		ud.createUserList(userTemp);
		
		String cartData = "";
		cartData += "3001/1001\n";
		cartData += "3001/1001\n";
		cartData += "3003/1002\n";
		cartData += "3001/1001\n";
		cartData += "3001/1003\n";
		cartData += "3003/1002\n";
		cartData += "3003/1001\n";
		cartData += "3002/1001";
		String[] cartTemp=cartData.split("\n");
		cd.createCartList(cartTemp);
		
		// [문제1] 회원별 아이템 구매목록 출력 
		// [정답1] 이만수==> 고래밥3,칸쵸1 / 김철민 ==> 고래밥1 / 이영희 ==> 고래밥1,새우깡2
		
		f.solveQ1(ud.userList,id.itemList,cd.cartList);
		System.out.println();
		System.out.println("====================");
		
		// [문제2] 아이템별로 구입한 회원이름 출력 
		// [정답2] 고래밥==> 이만수,김철민,이영희 / 새우깡==> 이영희 / 칸쵸==> 이만수
		
		f.solveQ2(ud.userList, id.itemList, cd.cartList);
		
	}
}