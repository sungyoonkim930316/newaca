package day40;

import java.util.Arrays;

class Subject {
	String name;
	String stuNo;
	int score;

	String getInfo() {
		return name + "\t" + score + "\t\n";
	}

//	@Override
//	public String toString() {
//		return "Subject [name=" + name + ", stuNo=" + stuNo + ", score=" + score + "]";
//	}
	
}

class Student {


	String stuNo;
	Subject[] subjects;
	String name;

	String getData() {
		String data = name + " \n";
		for (Subject sub : subjects) {
			if (sub == null)
				return data;
			data += sub.getInfo();
		}
		return data;
	}

	void printInfo() {
		System.out.println(getData());
	}
	
//	@Override
//	public String toString() {
//		return "Student [stuNo=" + stuNo + ", subjects=" + Arrays.toString(subjects) + ", name=" + name + "]";
//	}

}

class StudentDAO {
	Student[] list;
	Subject[] subList;

	void printAllStudent() {
		for (Student stu : list) {
			stu.printInfo();
		}
	}

	void init() {

		String subData = "";
		subData += "1001/국어/10\n";
		subData += "1001/수학/32\n";
		subData += "1002/국어/23\n";
		subData += "1002/수학/35\n";
		subData += "1002/영어/46\n";
		subData += "1003/수학/60\n";
		subData += "1003/영어/100\n";
		String[] temp = subData.split("\n");

		Student s = new Student();
		for (int i = 0; i < temp.length; i++) {
			int cnt = subList == null ? 0 : subList.length;

			String[] info = temp[i].split("/");
			Subject sub = new Subject();
			sub.name = info[1];
			sub.stuNo = info[0];
			sub.score = Integer.parseInt(info[2]);

			if (subList == null)
				subList = new Subject[1];
			else {
				Subject[] t = new Subject[cnt + 1];
				for (int j = 0; j < cnt; j++)
					t[j] = subList[j];

				subList = t;
			}
			subList[i] = sub;
		}

		String stuData = "1001/이만수\n";
		stuData += "1002/김철만\n";
		stuData += "1003/오수정\n";
		temp = stuData.split("\n");

		for (int i = 0; i < temp.length; i++) {
			int cnt = list == null ? 0 : list.length;

			String[] info = temp[i].split("/");
			Student stu = new Student();
			stu.name = info[1];
			stu.stuNo = info[0];

			stu.subjects = null;
			for (int j = 0; j < subList.length; j++) {
				int scnt = stu.subjects == null ? 0 : stu.subjects.length;
				
				if (stu.stuNo.equals(subList[j].stuNo)) {
					if (stu.subjects == null) {
						stu.subjects = new Subject[1];
						}else {
						Subject[] t = new Subject[scnt + 1];
						for (int k = 0; k < scnt; k++) {
							t[k] = stu.subjects[k];
						}
						stu.subjects = t;
					}
					Subject su = new Subject();
					su.name = subList[j].name;
					su.score = subList[j].score;
					su.stuNo = subList[j].stuNo;
					stu.subjects[scnt] = su;
					
					System.out.println(stu.name);
					for(Subject sub : stu.subjects) {
						System.out.println(sub);
					}
				}
			}
			System.out.println("====");

			if (list == null)
				list = new Student[1];
			else {
				Student[] t = new Student[cnt + 1];
				for (int j = 0; j < cnt; j++)
					t[j] = list[j];

				list = t;
			}
			list[i] = stu;
		}

	}

	void run() {
		init();
		printAllStudent();
	}
}

public class 학생컨트롤러3단계 {

	public static void main(String[] args) {
		StudentDAO dao = new StudentDAO();
		dao.run();
	}

}
