package 싱글톤;

import java.util.ArrayList;

class TestDAO2{
	private String name;
	private ArrayList<String> list;
	
	//1. 생성자를 private로 막아준다 
	private TestDAO2(String name){
		list = new ArrayList<String>();
		setName(name);
	}
	//2. 자기 클래스 내부에서 static 변수로 자신 객체를 만든다 => private 직접적으로 변경 불가능하게 막기 
	private static TestDAO2 instance = new TestDAO2("testDAO2");
	//3. 내부 인스턴스를 캡슐화를 통해서 클래스 외부에서 주소값 참조만 해올수 있도록 getter만 생성 => 간접 접근 
	static TestDAO2 getInstance() {
		return instance;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	void PrintAll() {
		System.out.println(list);
	}

	 ArrayList<String> getList(){
		return list;
	}

	void addList(String name) {
		list.add(name);
	}
	
}

public class 싱글톤사용후 {

	public static void main(String[] args) {
		
       // 외부에서 생성자 호출 안됨 => 외부클래스에서 새로운 객체 생성 불가능 
		
		//TestDAO2 t2 = new TestDAO2();
		
		TestDAO2 t2 = TestDAO2.getInstance();
		t2.addList("고양이");
		t2.addList("강아지");
		TestDAO2.getInstance().addList("사자");
		
		TestDAO2.getInstance().PrintAll();
		TestDAO2.getInstance().PrintAll();
	}

}