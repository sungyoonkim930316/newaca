package 싱글톤;

import java.util.ArrayList;

class TestDAO{
	private String name;
	private static ArrayList<String> list;
	TestDAO(String name){
		list = new ArrayList<String>();
		setName(name);
	}
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	static void PrintAll() {
		System.out.println(list);
	}

	static ArrayList<String> getList(){
		return list;
	}

	static void addList(String name) {
		list.add(name);
	}
	
	
}

public class 싱글톤사용전 {

	public static void main(String[] args) {
// 싱글톤 패턴 이란? ==> DAO static 사용: DAO 객체들의 공유자원 1개만 사용하기 위해서 
// 여러 DAO들이 같은 공유자원을 가질 수 있도록 staic 통해서 만들어 줬던것을 ->
		// 단 한개의 DAO 객체만 만들게 고정 
		
		TestDAO t1 = new TestDAO("test1");
		System.out.println(t1.getName());
		ArrayList<String> t1List = t1.getList();
		t1List.add("강아지");
		
		TestDAO t2 = new TestDAO("test2");
		ArrayList<String> t2List = TestDAO.getList();
		TestDAO.addList("말");
		t2.addList("사자");
		t1.addList("호랑이");
		
		TestDAO.PrintAll();
		
		
	}

}