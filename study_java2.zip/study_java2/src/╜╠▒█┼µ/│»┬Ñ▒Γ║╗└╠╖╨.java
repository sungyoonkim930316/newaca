package 싱글톤;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class 날짜기본이론 {
	public static void main(String[] args) {
		Date date = new Date();
		System.out.println(date);
		                                                       // 날자 fommatter 
		SimpleDateFormat sdf1 = new SimpleDateFormat("yyyy년 MM월 dd일 E요일 a hh시 mm분 ss초 ");
		String myDate = sdf1.format(date);
		System.out.println(myDate);
		
		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy.MM.dd(E) hh:mm");
		long time = System.currentTimeMillis();
		System.out.println(time);
		System.out.println(sdf2.format(time));
		
// 대표적인 싱글톤 패턴객체가 캘린더 
		Calendar now = Calendar.getInstance(); 
		
		System.out.println(now.MONDAY);
		
	}
}