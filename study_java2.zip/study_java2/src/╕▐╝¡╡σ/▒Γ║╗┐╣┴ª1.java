package 메서드;

class Ex001{
	
	void q1(int a) {
		System.out.println(a%2==0?"짝수":"홀수");
		System.out.println("======");
	}
	
	void q2(int x,int y) {
		int sum=0;
		for(int i=x;i<=y;i++) sum+=i;
		System.out.println(sum);
		System.out.println("======");
	}
	
	void q3(int primeNumber) {
		int z=2;
		for(int i=z;i<=primeNumber;i++) {
			int cnt=0;
			for(int j=1;j<=i;j++) {
				if(i%j==0) cnt++;
			}
			if(cnt==2){System.out.println(i+" ");}
		}
		System.out.println("======");
	}
	
}

public class 기본예제1 {

	public static void main(String[] args) {

		Ex001 e = new Ex001();

		// 문제 1) a 가 홀수인지 짝수인지 출력 
		int a = 19;
		e.q1(a);

		// 문제 2) x부터 y까지의 합을 출력하는 메서드
		int x = 1;
		int y = 10;
		e.q2(x,y);

		// 문제3) 숫자 1개를 인자로 사용해서 2부터 인자 20까지의  소수 전부 출력 
		int primeNumber = 20;
		e.q3(primeNumber);
		
	}

}