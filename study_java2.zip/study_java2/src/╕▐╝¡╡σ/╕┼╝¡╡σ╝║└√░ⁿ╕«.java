package 메서드;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

class ScoreMng{
	
	Random r=new Random();
	Scanner s=new Scanner(System.in);
	
    
	
	void answerQ1(int[] a) {
		for(int i=0;i<a.length;i++) a[i]=r.nextInt(100);
		System.out.println(Arrays.toString(a));
	}
	
	void answerQ2(int[] a) {
		int sum=0;
		for(int i=0;i<a.length;i++) sum+=a[i];
		double avg=sum/a.length;
		System.out.println("총점 : "+sum+"점, 평군 : "+avg);
	}
	
	void answerQ3(int[] a) {
		int cnt=0;
		for(int i=0;i<a.length;i++) if(a[i]>=60) cnt++;
		System.out.println("합격셍 수 : "+cnt+"명");
	}
	
	void answerQ4(int[] a) {
		while(true) {
			System.out.print("인덱스를 입력하다 : ");
			int idx=s.nextInt();
			if(idx<0||idx>a.length) {System.err.println("err");continue;}
			else {System.out.println("인댁스 "+idx+"번 학생의 성적은 "+a[idx]+"점");break;}
		}
	}
	
	void answerQ5(int[] a) {
		while(true) {
			System.out.print("성적을 입력하다 : ");
			int scor=s.nextInt();
			boolean err=false;
			int idx=0;
			for(int i=0;i<a.length;i++) if(scor==a[i]) {idx=i;err=true;}
			if(err==false) {System.err.println("err");continue;}
			else {System.out.println(scor+"점 받은 학생의 인덱스넘버는 "+idx);break;}
		}
	}
	
	void answerQ6(int[] a, int[] b) {
		while(true) {
			System.out.print("학번을 입력하다 : ");
			int hbun=s.nextInt();
			boolean err=false;
			int idx=0;
			for(int i=0;i<b.length;i++) if(hbun==b[i]) {System.out.println(b[i]);idx=i;err=true;}
			if(err==false) {System.err.println("err");continue;}
			else {System.out.println("학번 "+hbun+"학생의 점수는 "+a[idx]+"점");break;}
		}
	}
	
	void answerQ8(int[] a, int[] b) {
		int max=0;
		int idx=0;
		for(int i=0;i<a.length;i++) if(max<a[i]) {idx=i;max=a[i];}
		System.out.println("가장 높은 점수를 받은 학생의 점수는 "+max+"점이고 학번은"+b[idx]+"이다.");
	}

}


public class 매서드성적관리 {

	public static void main(String[] args) {
		
		int[] scores = new int[5];
		int[] hakbuns = { 1001, 1002, 1003, 1004, 1005 };
		
		ScoreMng sco=new ScoreMng();

		// 문제1) scores배열에 1~100점 사이의 랜덤 정수를 5개 저장
		// 예 1) 87, 11, 92, 14, 47
		sco.answerQ1(scores);

		// 문제2) 전교생의 총점과 평균 출력
		// 예 2) 총점(251) 평균(50.2)
		sco.answerQ2(scores);

		// 문제3) 성적이 60점 이상이면 합격. 합격생 수 출력
		// 예 3) 2명
		sco.answerQ3(scores);

		// 문제4) 인덱스를 입력받아 성적 출력
		// 정답4) 인덱스 입력 : 1 성적 : 11점
		sco.answerQ4(scores);

		// 문제5) 성적을 입력받아 인덱스 출력
		// 정답5) 성적 입력 : 11 인덱스 : 1
		sco.answerQ5(scores);

		// 문제6) 학번을 입력받아 성적 출력
		sco.answerQ6(scores,hakbuns);

		// 문제7) 학번을 입력받아 성적 출력
		// 단, 없는학번 입력 시 예외처리
		// 예 7)
		// 학번 입력 : 1002 성적 : 11점
		// 학번 입력 : 1000 해당학번은 존재하지 않습니다.
		sco.answerQ6(scores,hakbuns);

		// 문제8) 1등학생의 학번과 성적 출력
		sco.answerQ8(scores,hakbuns);
		
	}

}
