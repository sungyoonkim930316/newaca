package day46;

public class _SkbMain {

	public static void main(String[] args) {

		SkbController sctl=new SkbController();
		sctl.run();
		
	}

}
