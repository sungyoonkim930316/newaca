package day44;

import java.util.Random;
import java.util.Scanner;

public class onlymain {

	public static void main(String[] args) {

		Scanner s=new Scanner(System.in);
		Random r=new Random();
		
		int win=0;
		int[][] map=new int[7][7];
		
		//벽
		System.out.print("설치할 벽의 갯수를 입력하다 : ");
		int inputWall=s.nextInt();
		int wy=0;
		int wx=0;
		int wcnt=0;
		while(true) {
			wy=r.nextInt(7);
			wx=r.nextInt(7);
			if(map[wy][wx]==0) {
				map[wy][wx]=9;
				wcnt++;
			}
			if(wcnt==inputWall) break;
		}
		
		//플레이어
		int cy=0;
		int cx=0;
		while(true) {
			cy=r.nextInt(7);
			cx=r.nextInt(7);
			if(map[cy][cx]!=9) break;
		}
		
		//공
		int by=0;
		int bx=0;
		while(true) {
			by=r.nextInt(5)+1;
			bx=r.nextInt(5)+1;
			if(map[by][bx]!=2&&map[cy][cx]!=9) break;
		}
		
		//골대
		int py=0;
		int px=0;
		while(true) {
			py=r.nextInt(7);
			px=r.nextInt(7);
			if(map[py][px]!=2&&map[py][px]!=3&&map[cy][cx]!=9) {
				break;
			}
		}
		
		System.out.println("  [★ 소 코 반 게 임 ★]\n======================");
		while(true) {
			
			map[cy][cx]=2;
			map[by][bx]=3;
			map[py][px]=7;
			
			for(int[] i:map) {
				for(int j:i) {
					if(j==0) System.out.print("[ ]");
					if(j==2) System.out.print("[옷]");
					if(j==3) System.out.print("[o]");
					if(j==7) System.out.print("[=]");
					if(j==9) System.out.print("[■]"); 
				}System.out.println();
			}
			
			if(win==1) {System.out.println("======================\n[★CLEAR★]\n======================");break;}
			System.out.print("======================\n[1]← [2]→ [3]↑ [4]↓\n이동할 방향을 입력하다. : ");
			int dir=s.nextInt();
			System.out.println("======================");
			
			map[cy][cx]=0;
			
			if(dir==1&&cx-1>=0) {
				if(map[cy][cx-1]==9) continue;
				else if(map[cy][cx-1]==3) {
					if(bx-1<0 || map[by][bx-1]==9) continue;
					else if(map[by][bx-1]==7) win=1;
					map[by][bx]=0;
					bx--;cx--;
				} 
				else cx--;
			}
			if(dir==2&&cx+1<=map.length-1) {
				if(map[cy][cx+1]==9) continue;
				else if(map[cy][cx+1]==3) {
					if(bx+1>map.length-1 || map[by][bx+1]==9) continue;
					else if(map[by][bx+1]==7) win=1;
					map[by][bx]=0;
					bx++;cx++;
				} 
				else cx++;
			}
			if(dir==3&&cy-1>=0) {
				if(map[cy-1][cx]==9) continue;
				else if(map[cy-1][cx]==3) {
					if(by-1<0 || map[by-1][bx]==9) continue;
					else if(map[by-1][bx]==7) win=1;
					map[by][bx]=0;
					by--;cy--;
				} 
				else cy--;
			}
			if(dir==4&&cy+1<=map.length-1) {
				if(map[cy+1][cx]==9) continue;
				else if(map[cy+1][cx]==3) {
					if(by+1>map.length-1 || map[by+1][bx]==9) continue;
					else if(map[by+1][bx]==7) win=1;
					map[by][bx]=0;
					by++;cy++;
				} 
				else cy++;
			}
		}
		
//		System.out.println("엔터를 눌러서 게임을 시작하다.");
//		String starter=s.nextLine();
//
//		long beforeTime = System.currentTimeMillis(); //코드 실행 전에 시간 받아오기 : 밀리세컨드 단위 1초 ==  1000
//		for(int z =0; z < 1000000;z++){
//			
//			
//			break;
//		}
//		long afterTime = System.currentTimeMillis(); // 코드 실행 후에 시간 받아오기
//		double secDiffTime = (afterTime - beforeTime) / 1000.0; //두 시간에 차 계산
//
//		System.out.println("[소요시간 : " + secDiffTime+"초.]");
	}
}
