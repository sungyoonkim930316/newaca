package day44;

import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;

class Exceptions {
	Scanner s=new Scanner(System.in);
	
	// 게임보드 사이즈 예외처리
	int isSize(int size) {
		while(true) {
			try {
				System.out.print("[최소 7] GameBoard의 사이즈를 입력하다. : ");
				size = s.nextInt();
				if(size<7) throw new Exception();
			} 
			catch (InputMismatchException e) {
				s=new Scanner(System.in);
				System.err.println("[숫자만 입력할 수 있다.]");
			} 
			catch (Exception e) {
				System.err.println("[GameBoard의 사이즈는 7이상이어야 한다.]");
			}
			if(size>=7) break;
		}
		return size;
	}
	
	int isWall(int wcnt, int size) {
		while(true) {
			s=new Scanner(System.in);
			try {
				System.out.print("설치할 벽의 갯수를 입력하다. : ");
				wcnt = s.nextInt();
				if(wcnt<7) throw new Exception();
				if(wcnt>(size*size)/4) {
					System.out.println("test");
					throw new RangeOutOfBoundsExcepiton();
				}
			} 
			catch (InputMismatchException e) {
				s=new Scanner(System.in);
				System.err.println("[숫자만 입력할 수 있다.]");
			} 
			catch (RangeOutOfBoundsExcepiton e) {
				s=new Scanner(System.in);
			
				System.err.println("[벽의 갯수가 너무 많다.]");
			}
			catch (Exception e) {
				s=new Scanner(System.in);
				System.err.println("[벽의 갯수가 너무 적다.]");
			}
			if(wcnt>=7) break;
		}
		return wcnt;
	}
	
}

class Settings {
	Exceptions e;
	Settings(Exceptions e){
		this.e = e;
	}
	
	int makeRN(int length) {
		Random r=new Random();
		int num=r.nextInt(length);
		return num;
	}
	
	void setWalls(int size) {
	
		int wcnt=e.isWall(0,size);
		
	}
	
	int[][] initializeBoard(int[][] board){
		setWalls(board.length);
		
		return board;
	}
	
}

class Play {
	
	String[][] showBoard(int[][] board) {
		String[][] temp=new String[board.length][board.length];
		for(int[] i:board) {
			for(int j:i) {
				if(j==0) System.out.print("[ ]");
				if(j==2) System.out.println("[옷]");
				if(j==3) System.out.println("[o]");
				if(j==7) System.out.println("[=]");
				if(j==9) System.out.println("[■]");
			}System.out.println();
		}
		return temp;
	}
	
}


public class 소코반그냥만들어보기 {

	public static void main(String[] args) {
		
		
		
		Exceptions e=new Exceptions();
		Settings set=new Settings(e);
		Play p=new Play();
		
		int size=e.isSize(0);
		int board[][]=new int[size][size];
		set.initializeBoard(board);
		
		
		
		while(true) {
			p.showBoard(board);
			break;
		}

	}

}
