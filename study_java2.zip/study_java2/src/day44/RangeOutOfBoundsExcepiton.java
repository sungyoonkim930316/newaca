package day44;

public class RangeOutOfBoundsExcepiton extends Exception {
    @java.io.Serial
    private static final long serialVersionUID = 8811230760997066428L;

    public RangeOutOfBoundsExcepiton() {
        super();
    }

    public RangeOutOfBoundsExcepiton(String s) {
        super(s);
    }
}