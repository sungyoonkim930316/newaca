package day46;

import java.util.Scanner;

public class SkbController {
	Scanner s=new Scanner(System.in);
	SkbDAO sd=new SkbDAO();
	
	void run() {
		
//		int sel=sd.choiceMenu();
//		
//		if(sel==1) {
			sd.setMap();
			double record=sd.game();
//		}
//		if(sel==-1) {System.out.println("[프로그램이 종료되다.]");return;}
	}

}
