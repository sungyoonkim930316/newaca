package day46;

public class User {
	
	String id;
	int[][] savedGame;
	int record;
	int rank;

}
