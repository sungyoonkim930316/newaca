package day46;

import java.util.Scanner;

public class UserDAO {
	Scanner s=new Scanner(System.in);
	UserDAO ud=new UserDAO();
	
	void login() {
		System.out.print("아이디를 입력하다. : ");
		
	}

}
