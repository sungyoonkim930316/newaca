package 시험6;

public class MyFile {

}
