package 시험6;

import java.util.ArrayList;
import java.util.Scanner;

public class StudentDAO {
	static final int MINMUM = 1001;
	static ArrayList<Student> studentList = new ArrayList<Student>();
	private static int num = 1000;
	public static int getNum() {
		return num;
	}

	Student checkId(String id) {
		for(Student s :studentList) {
			if(s.studentId.equals(id)) {
				return s;
			}
		}
		return null;
	}
	
	public void join() {
		System.out.println("[ 회원가입 ]");
		String id = MyUtil.getValue("ID 입력>>");
		Student stu = checkId(id);
		if(stu == null) {
			stu = new Student(++num,id);
			System.out.println(stu +" 학생 등록 성공 ");
			studentList.add(stu);
		}else {
			System.out.println("이미 존재하는 ID 입니다");
		}
		
	}
	public void deleteStudent() {
		
	}
	public void printStudentList() {
		System.out.println("[ 학생 목록 ]");
		for(Student stu : studentList) {
			System.out.print(stu);
			ArrayList<Subject> subList = SubjectDAO.getAStuSubjests(stu);
			for(Subject sub : subList) {
				System.out.print(sub);
			}
			System.out.println();
		}
	}
	public void saveStudentList() {
		
	}
	public void loadStudentList() {
		
	}
}
