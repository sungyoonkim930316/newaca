package 시험6;

public class _main {
	
	public static void main(String[] args) {
			
			Controller cont = new Controller();
			cont.run();
			
			
	}
}
