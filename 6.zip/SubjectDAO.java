package 시험6;

import java.util.ArrayList;
import java.util.Scanner;

public class SubjectDAO {
	static ArrayList<Subject> subjectList = new ArrayList<Subject>();

	static ArrayList<Subject> getAStuSubjests(Student stu) {
		ArrayList<Subject> subList = new ArrayList<Subject>();
		for (Subject sub : subjectList) {
			if (sub.getStudentNum() == stu.studentNum) {
				subList.add(sub);
			}
		}
		return subList;
	}

	public void insertSubject() {
		if (StudentDAO.studentList.size() == 0) {
			System.out.println("[ 학생 데이터가 존재하지 않습니다 ]");
			return;
		}
		int hakbun = MyUtil.getValue("[과목 추가 : 학번]", StudentDAO.MINMUM, StudentDAO.getNum());
		if (hakbun == -1) {
			System.out.println("없는 학생 번호");
			return;
		}

		String name = "";

		while (true) {
			name = MyUtil.getValue("[과목 추가 : 과목 이름] ");
			boolean check = true;
			for (Subject sub : subjectList) {
				if (sub.getStudentNum() == hakbun && name.equals(sub.getSubject())) {
					System.out.println("이미 존재하는 과목 이름 입니다");
					check = false;
					break;
				}
			}
			if (check) {
				break;
			}
		}

		int score = -1;
		while (score == -1) {
			score = MyUtil.getValue("[과목 추가 : 과목 점수]", 0, 100);
		}
		Subject subData = new Subject(hakbun, name, score);
		subjectList.add(subData);

	}

	public void deleteSubject() {

	}
}
