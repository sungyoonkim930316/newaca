package ATM;

public class BankMenu {
	
	int choiceUserAdmin() {
		int c=-1;
		System.out.println("[메인 화면]\n[1] 관리자\n[2] 사용자\n[0] 종료");
		while(c==-1) {
			c=Util.getValue("메뉴를 선택하다 ", 0, 2);
		}
		return c;
	}
	
	int adminMenu() {
		int c=-1;
		System.out.println("[관리자 화면]\n[1] 회원목록 - 전체회원 목록\n[2] 회원정보 수정\n[3] 회원정보 삭제\n[4] 회원정보 저장\n[5] 회원정보 불러오기\n[0] 뒤로가기");
		while(c==-1) {
			c=Util.getValue("메뉴를 선택하다 ", 0, 5);
		}
		return c;
	}
	
	int userMenu1() {
		int c=-1;
		System.out.println("[사용자 화면]\n[1] 회원가입\n[2] 로그인\n[0] 뒤로가기");
		while(c==-1) {
			c=Util.getValue("메뉴를 선택하다 ", 0, 2);
		}
		return c;
	}
	
	int userMenu2() {
		int c=-1;
		System.out.println("[사용자 화면]\n[1] 계좌 추가\n[2] 계좌 삭제\n[3] 입금\n[4] 출금\n[5] 이체\n[6] 탈퇴\n[7] 마이페이지: 전체 계좌, 금액 (회원정보: 비밀번호 수정)\n[0] 뒤로가기");
		while(c==-1) {
			c=Util.getValue("메뉴를 선택하다 ", 0, 7);
		}
		return c;
	}

}
