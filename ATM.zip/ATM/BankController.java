package ATM;

public class BankController {
	AccountDAO ad=new AccountDAO();
	ClientDAO cd=new ClientDAO();
	File f=new File();
	BankMenu bm=new BankMenu();
	String name="우리은행";
	
	public void setSampleData() {
		String clientData = "test01/1111/김철수\n";
		clientData += "test02/2222/이영희\n";
		clientData += "test03/3333/신민수\n";
		clientData += "test04/4444/최상민";
				
		String accountdata = "test01/1111-1111-1111/8000\n";
		accountdata += "test02/2222-2222-2222/5000\n";
		accountdata += "test01/3333-3333-3333/11000\n";
		accountdata += "test03/4444-4444-4444/9000\n";
		accountdata += "test01/5555-5555-5555/5400\n";
		accountdata += "test02/6666-6666-6666/1000\n";
		accountdata += "test03/7777-7777-7777/1000\n";
		accountdata += "test04/8888-8888-8888/1000";
		
		// 1) test01 김철수는 계좌를 3개 가지고있다.
		// 2) test02 이영희는 계좌를 2개 가지고있다.
		// 3) test03 신민수는 계좌를 2개 가지고있다.
		// 4) test04 최상민은 계좌를 1개 가지고있다. 
		
		cd.addClient(clientData);
		ad.addAccount(accountdata);
	}
	
	void run() {
		while(true) {
			int choice=bm.choiceUserAdmin();
			if(choice==0) {System.out.println("[프로그램 종료.]");break;}
			if(choice==1) {
				while(true) {
					int admc=bm.adminMenu();
					if(admc==0) break;
					if(admc==1) cd.showUserList();
					if(admc==2) cd.updateUser();
					if(admc==3) cd.deleteUser();
					if(admc==4) f.saveUserInfo();
					if(admc==5) f.loadUserInfo();
				}
			}
			if(choice==2) {
				while(true) {
					int urc1=bm.userMenu1();
					if(urc1==0) break;
					if(urc1==1) cd.join();
					if(urc1==2) {
						String userId=cd.login();
						if(userId.equals("fail")) continue;
						while(true) {
							int urc2=bm.userMenu2();
							if(urc2==0) break;
							if(urc2==1) {}
							if(urc2==2) {}
							if(urc2==3) {}
							if(urc2==4) {}
							if(urc2==5) {}
							if(urc2==6) {break;}
							if(urc2==7) cd.showMyPage(userId);
						}
					}
				}
			}
		}
	}
	
}