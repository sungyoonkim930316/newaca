package ATM;

public class Client {
	
	private String id;
	private String pwd;
	private String name;
	
	public Client(String id, String pwd, String name) {
		super();
		this.id = id;
		this.pwd = pwd;
		this.name = name;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getpwd() {
		return pwd;
	}
	public void setpwd(String pwd) {
		this.pwd = pwd;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "[아이디 : "+id+", 비번 : "+pwd+", 이름 : "+name+"]";
	}
	
	

}
