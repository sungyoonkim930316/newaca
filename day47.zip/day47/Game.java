package day47;

public class Game {
	
	private int[][] savedGame;
	private double bestRecord;
	private int rank;
	
	public Game(int[][] savedGame, double bestRecord, int rank) {
		super();
		this.savedGame = savedGame;
		this.bestRecord = bestRecord;
		this.rank = rank;
	}
	
	public int[][] getSavedGame() {
		return savedGame;
	}
	public void setSavedGame(int[][] savedGame) {
		this.savedGame = savedGame;
	}
	public double getBestRecord() {
		return bestRecord;
	}
	public void setBestRecord(double bestRecord) {
		this.bestRecord = bestRecord;
	}
	public int getRank() {
		return rank;
	}
	public void setRank(int rank) {
		this.rank = rank;
	}
	
	

}
