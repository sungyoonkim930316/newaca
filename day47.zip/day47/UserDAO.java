package day47;

import java.util.ArrayList;

public class UserDAO {

	ArrayList<User> userList=new ArrayList<User>();
	int userCnt=1;
	
	int loginMenu() {
		System.out.println("[1]로그인 [2]회원가입 [3]랭킹보기 [4]종료");
		int sel=-1;
		while(sel==-1) {
			sel=Input.getValue("메뉴를 선택하다. ", 1, 4);
		}
		
		if(sel==1) {
			int idx=-1;
			if(userList.size()==0) {
				System.out.println("가입한 회원이 존재하지 않는다.");
				return -1;
			}
			String id=Input.getValue("아이디를 입력하다.");
			String pwd=Input.getValue("패스워드를 입력하다.");
			for(int i=0;i<userList.size();i++) {
				if(userList.get(i).getUserId().equals(id)) idx=i;
			}
			System.out.println("["+id+"] 로그인 완료.\n");
			
			return userList.get(idx).getUserNum();
		}
		else if(sel==2) {
			join();
			return -1;
		}
		else if(sel==3) {
			if(userList.size()==0) {
				System.out.println("가입한 회원이 존재하지 않는다.");
				return -1;
			}
			else {
				for(int i=0;i<userList.size();i++) {
					System.out.print("["+userList.get(i).getUserNum()+"]["+userList.get(i).getUserId()+"]\n");
				}
			}
			System.out.println();
			return -1;
		}
		else {
			System.out.println("[프로그램 종료.]");
			return -2;
		}
	}
	
	void join() {
		String id=Input.getValue("아이디를 입력하다.");
		String pwd=Input.getValue("패스워드를 입력하다.");
		User u=new User(userCnt,id,pwd);
		userList.add(u);
		userCnt++;
		System.out.println("["+id+"] 회원가입 완료.\n");
	}
	
	int playMenu(int userNum) {
		System.out.println("[1]게임시작 [2]저장된 게임 불러오기 [3]로그아웃 [4]종료");
		int sel=-1;
		while(sel==-1) {
			sel=Input.getValue("메뉴를 선택하다. ", 1, 4);
		}
		
		if(sel==1) {return userNum;}
		else if(sel==2) {
			
			int idx=-1;
			for(int i=0;i<userList.size();i++) {
				if(userList.get(i).getUserNum()==userNum) idx=i;
			}
			
			return userNum;
		}
		else if(sel==3) {System.out.println("[로그아웃 하다.]");return -1;}
		else {System.out.println("[프로그램 종료.]");return -2;}
	}
}
