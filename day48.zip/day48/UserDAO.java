package day48;

import java.util.ArrayList;

public class UserDAO {

	ArrayList<User> userList=new ArrayList<User>();
	int userCnt=1;
	
	int firstMenu() {
		while(true) {
			System.out.println("[1]로그인 [2]회원가입 [3]랭킹보기 [4]종료");
			int sel=-1;
			while(sel==-1) {sel=Input.getValue("메뉴를 선택하다. ", 1, 4);}
			
			if(sel==1) {
				if(userList.size()==0) {System.err.println("가입한 회원이 존재하지 않는다."); continue;}
				
				int userNum=login();
				return userNum;
			}
			else if(sel==2) {
				join();
			}
			else if(sel==3) {
				if(userList.size()==0) {System.err.println("가입한 회원이 존재하지 않는다."); continue;}
				showRank();
			}
			else return -1;
		}
	}
	
	int secondMenu(int sel1) {
		while(true) {
			System.out.println("[1]게임시작 [2]저장된 게임 이어하기 [3]내 정보 [4]로그아웃 [5]종료");
			int sel=-1;
			while(sel==-1) {sel=Input.getValue("메뉴를 선택하다. ", 1, 5);}
			
			if(sel==1) return sel1;
			else if(sel==2) {return sel1;}
			else if(sel==3) {
				int curUser=sel1;
				showUserInfo(curUser);
				continue;
			}
			else if(sel==4) {System.out.println("[로그아웃 하다.]");return -1;}
			else return -1;
		}
	}
	
	void join() {
		String id=Input.getValue("아이디를 입력하다.");
		String pwd=Input.getValue("패스워드를 입력하다.");
		User u=new User(userCnt,id,pwd);
		userList.add(u);
		userCnt++;
		System.out.println("["+id+"] 회원가입 완료.\n");
	}
	
	int login() {
		int num=0;
		return num;
	}
	
	void showRank() {
		
	}
	
	void showUserInfo(int curUser) {
		for(int i=0;i<userList.size();i++) {
			if(userList.get(i).getUserNum()==curUser) {
				System.out.println(userList.get(i));
			}
		}
	}
	
}
