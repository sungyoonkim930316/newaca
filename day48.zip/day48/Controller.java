package day48;

public class Controller {

	SkbDAO sd=new SkbDAO();
	UserDAO ud=new UserDAO();
	
	void init() {
		//실행 전 파일에 저장된 정보를 객체에 집어넣어준다.
	}
	
	void run() {
		
		
		int sel1=0;
		int sel2=0;
		
		sel1=ud.firstMenu();
		if(sel1==-2) {
			//userList 저장 메서드 호출
			//gameList 저장 메서드 호출
			System.out.println("[프로그램 종료.]");
			return;
		}
		sel2=ud.secondMenu(sel1);
		
		sd.setMap();
		sd.playGame();
	}
	
}
