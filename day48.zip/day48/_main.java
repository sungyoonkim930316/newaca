package day48;

public class _main {

	public static void main(String[] args) {
		Controller ctrl=new Controller();
		ctrl.run();
	}
}
