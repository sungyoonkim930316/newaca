package day48;

import java.util.Random;

public class SkbDAO {

	Skb el=new Skb();
	int win=el.getWin();
	
	void setObjects(int[][] map, int obj, int ck) {
		Random r=new Random();
		int a=0;
		int b=0;
		int inputw=-1;
		if (ck==0) {
			while(inputw==-1) {
				inputw=Input.getValue("설치할 벽의 갯수를 입력하다. ", 1, ((map.length)*(map.length))/4);
			}
		}
		while(true) {
			if(obj==3) {
				a=r.nextInt(map.length-2)+1;
				b=r.nextInt(map.length-2)+1;
			}
			else {
				a=r.nextInt(map.length);
				b=r.nextInt(map.length);
			}
			if(map[a][b]==0) map[a][b]=obj; 
			
			if(obj==9) {
				inputw--;
				if(inputw==0) break;
			}
			else break;
		}
	}
	
	void setMap() {
		int ck=0;
		setObjects(el.getMap(), 9, ck);
		ck=1;
		
		setObjects(el.getMap(), 3, ck);
		setObjects(el.getMap(), 7, ck);
		setObjects(el.getMap(), 2, ck);
	}
	
	void showMap() {
		for(int[] i:el.getMap()) {
			for(int j:i) {
				if(j==0) System.out.print("[ ]");
				if(j==2) System.out.print("[옷]");
				if(j==3) System.out.print("[o]");
				if(j==7) System.out.print("[=]");
				if(j==9) System.out.print("[■]");
			}System.out.println();
		}
	}
	
	int[] findCharAndBall(int[][] map, int[] info) {
		for(int i=0;i<map.length;i++) {
			for(int j=0;j<map[i].length;j++) {
				if(map[i][j]==2) {info[0]=i; info[1]=j;}
				if(map[i][j]==3) {info[2]=i; info[3]=j;}
			}
		}
		return info;
	}
	
	void playGame() {
		while(true) {
			int[] info=findCharAndBall(el.getMap(), el.getInfo());
			showMap();
			if(win==1) {System.out.println("★CLEAR★");break;}
			moveObjects(info);
		}
	}
	
	void moveObjects(int[] info) {
		int dir=-1;
		System.out.println("\n[1]→ [2]← [3]↑ [4]↓");
		while(dir==-1) {
			dir=Input.getValue("이동할 방향을 입력하다. ", 1, 4);
		}
		
		int ncy=info[0];
		int ncx=info[1];
		int nby=info[2];
		int nbx=info[3];
		
		if(dir==1 || dir==2) ncx=findNextCell(dir,ncy,ncx);
		if(dir==3 || dir==4) ncy=findNextCell(dir,ncy,ncx);
		if(ncx==-1 || ncy==-1 || el.getMap()[ncy][ncx]==9) return;
		
		if(el.getMap()[ncy][ncx]==3) {
			if(dir==1 || dir==2) nbx=findNextCell(dir,nby,nbx);
			if(dir==3 || dir==4) nby=findNextCell(dir,nby,nbx);
			if(nbx==-1 || nby==-1 || el.getMap()[nby][nbx]==9) return;
			if(el.getMap()[nby][nbx]==7) win=1;
			
			el.getMap()[ info[2] ][ info[3] ]=0;
			info[2]=nby;
			info[3]=nbx;
			el.getMap()[ info[2] ][ info[3] ]=3;
		}
		
		el.getMap()[ info[0] ][ info[1] ]=0;
		info[0]=ncy;
		info[1]=ncx;
		el.getMap()[ info[0] ][ info[1] ]=2;
	}
	
	int findNextCell(int dir, int y, int x) {
		int changedValue=0;
		
		if(dir==1) changedValue=x+1;
		if(dir==2) changedValue=x-1;
		if(dir==3) changedValue=y-1;
		if(dir==4) changedValue=y+1;
		
		if(changedValue>el.getMap().length || changedValue<0) return -1;
		
		return changedValue;
	}
	
}
