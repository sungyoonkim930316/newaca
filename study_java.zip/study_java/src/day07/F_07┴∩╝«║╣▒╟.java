package day07;

import java.util.Scanner;

public class F_07�Ｎ���� {

	public static void main(String[] args) {

		Scanner scan = new Scanner(System.in);
		//int[] lotto = { 0, 0, 7, 7, 7, 0, 7, 7 }; // ��÷
		int[] lotto = {7, 0, 7, 7, 0, 7, 0, 7}; // �� 
		
		boolean run = true;
		boolean win = false;
		
		for(int i =0; i < lotto.length -2 ; i++) {
			if(lotto[i] ==7 && lotto[i+1] ==7 && lotto[i+2] == 7 ) {
				win = true;
			    break;
			}
		}
		System.out.println(win ? "��÷" : "��");
		
		System.out.println("=====================");
		win = false;
		int cnt =0;
		for(int i =0; i < lotto.length ; i++) {
			if(lotto[i] == 7) {
				cnt++;
			}else {
				cnt =0;
			}
			if(cnt == 3) {
				win = true;
				break;
			}
		}
		System.out.println(win ? "��÷" : "��");
		
	}
}
