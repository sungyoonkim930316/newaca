package day07;

import java.util.Arrays;
import java.util.Random;

public class F_08���� {

	public static void main(String[] args) {

		int arr[]= {10,20,30,40,50,60};
		int temp=0;
		
		Random r=new Random();
		
		for (int i=0;i<10;i++) {
			int num1=r.nextInt(arr.length);
			int num2=r.nextInt(arr.length);
			System.out.printf("[%d %d] => ",num1,num2);
			if(num1==num2) {System.out.print("�� ������ ���� ");System.out.println(Arrays.toString(arr));}
			else {
				temp = arr[num1];
				arr[num1] = arr[num2];
				arr[num2] = temp;
				System.out.println(Arrays.toString(arr));
			}
		}
		
	}

}
