package day11;

import java.util.Arrays;

public class G_02�������迭����2 {

	public static void main(String[] args) {

		int[][] arr = {
				{101, 102, 103, 104},
				{201, 202, 203, 204},
				{301, 302, 303, 304}
			}; 
			
			int[] garo = new int[3];
			int[] sero = new int[4];
			
		// ���� 1) ���� �� ���
		// ���� 1) 410, 810, 1210
		int sum1=0;
		for(int i=0; i<arr.length; i++) {
			for(int j=0; j<arr[i].length; j++) {
				sum1+=arr[i][j];
				garo[i]=sum1;
			}sum1=0;
			
		}
		System.out.println(Arrays.toString(garo));
			
		// ���� 2) ���� �� ���
		// ���� 2) 603, 606, 609, 612
		// arr[0,0] arr[1,0] arr[2,0] arr[3,0]
		// arr[0,1] arr[1,1] arr[2,1] arr[3,1] 
		// arr[0,2] arr[1,2] arr[2,2] arr[3,2] 
		// arr[0,3] arr[1,3] arr[2,3] arr[3,3] 
		
		int idx=0;
		int sum2=0;
		for(int i=0; i<arr.length+1; i++) {
			for(int j=0; j<arr.length; j++) {
				idx=i;
				sum2+=arr[j][idx];
				sero[i]=sum2;
				idx++;
			}sum2=0;
		}
		System.out.println(Arrays.toString(sero));
	}

}
