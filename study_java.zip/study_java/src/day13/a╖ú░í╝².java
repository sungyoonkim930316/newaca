package day13;

import java.util.Random;
import java.util.Scanner;

public class a������ {

	public static void main(String[] args) {

		//	159~300
		
		Random r=new Random();
		Scanner s=new Scanner(System.in);
		int num=r.nextInt(200)+101;
		System.out.println(num);
		System.out.print("���ڸ� �Է��ϴ�.");
		int x=s.nextInt();
		
		boolean err=x>9||x<0;
		
		if(!err) {
			num=(num%100)/10;
			if(num==x) System.out.println(num==x);
			else {System.out.println(num);System.out.println(num==x);}
			
		} else System.err.println("err");
	}

}
