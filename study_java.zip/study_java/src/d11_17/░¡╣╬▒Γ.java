package d11_17;

public class ���α� {

	public static void main(String[] args) {
		/*
		�ݺ����� ����ؼ� �Ʒ��� ���� ����غ�����.
		[����]
				0 0
				1 1
				2 3
				3 6
				4 10
				5 15
				6 21
				7 28
				8 36
				9 45
	 */
           for(int i=0; i<10; i++ ) {
        	   System.out.print(i+" ");
        	   int hap=i;
        	   for(int j=0; j<i; j++) {
        		   hap+=j;
        	   }
        	   System.out.print(hap);
        	   System.out.println();
           }
           System.out.println();
           System.out.println("=============");
           
           for(int i=0; i<10; i++) {
        	   int hap=i+1;
        	   System.out.print(i+" ");
        	   System.out.print((hap*i)/2);
        	   System.out.println();
           }
        	
        	   System.out.println();
               System.out.println("=============");
               
        	   
        	   int sum=0;
        	   for(int i=0; i<10; i++) {
        		   sum+=i;
        		   System.out.printf("%d %d\n",i,sum);
        	   }
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
        	   
           
	}

}
