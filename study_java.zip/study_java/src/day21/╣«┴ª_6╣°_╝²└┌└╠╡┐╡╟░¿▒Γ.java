package day21;

import java.util.Arrays;
import java.util.Scanner;

public class ����_6��_�����̵��ǰ��� {

	public static void main(String[] args) {

		/*
		 * [�����̵��ǰ���]
		    	     
			[1) left 2)right 3)up 4)down 5)�ǰ���]
			 
			0 �� �÷��̾��̴� .
			��ȣ�� �Է¹ް� �ش���ġ�� �̵� ==> 
			�̵��Ҷ� ���� ���� ��ȯ�Ѵ�. 

			 ��) 1 ==>  left
		    {1,2,3,4},
			{5,6,7,8},
			{9,10,11,12},
			{13,14,0,15}		

		  
		    ��) 1 ==>  left
		    {1,2,3,4},
			{5,6,7,8},
			{9,10,11,12},
			{13,0,14,15}		

			��ĭ��ĭ�̵��Ҷ����� yx �� �迭�� �̵��Ѱ�θ� �����ߴٰ�,
			5���Է½� ==> �Դ���� �ǵ��ư��� �Ѵ�. 
		
		 */
		
			Scanner s=new Scanner(System.in);
			
			int game[][] = {
					{1,2,3,4},
					{5,6,7,8},
					{9,10,11,12},
					{13,14,15,0}
			};
			int[][] temp=new int[1][1];
			int[][] yx=new int[10000][2];
			int y=0;
			int vertical=0;
			int horizon=0;
			int hIdx=0;
			int vIdx=0;
		
			while(true) {
				for(int i=0;i<game.length;i++) {
					for(int j=0;j<game[i].length;j++) {
						if(game[i][j]==0) {
							vertical=i;horizon=j;
							break;
						}
					}
				}
				for(int i=0;i<game.length;i++) {
					System.out.println(Arrays.toString(game[i]));
				}
				System.out.println();
				System.out.println("[1)left 2)right 3)up 4)down 5)�ǰ���]");
				System.out.print("�����ϴ� : ");
				int move=s.nextInt();
				System.out.println();
				if(move<1||move>5) {System.out.println("err");continue;}
				
				if(move==1) {vIdx=vertical;hIdx=horizon-1;}
				else if(move==2) {vIdx=vertical;hIdx=horizon+1;}
				else if(move==3) {vIdx=vertical-1;hIdx=horizon;}
				else if(move==4) {vIdx=vertical+1;hIdx=horizon;}
				
				if(move==1||move==2) {
					for(int i=0;i<game.length;i++) {
						for(int j=0;j<game[i].length;) {
							temp[0][0]=game[vertical][hIdx];
							yx[y][0]=vertical;
							yx[y][1]=horizon;
							y++;
							game[vertical][hIdx]=0;
							game[vertical][horizon]=temp[0][0];
							if(move==1) {horizon--;}
							else if(move==2) {horizon++;}
							i=game.length;break;
						}
					}
				}
				if(move==3||move==4) {
					for(int i=0;i<game.length;i++) {
						for(int j=0;j<game[i].length;) {
							temp[0][0]=game[vIdx][horizon];
							yx[y][0]=vertical;
							yx[y][1]=horizon;
							y++;
							game[vIdx][horizon]=0;
							game[vertical][horizon]=temp[0][0];
							if(move==3) {vertical--;}
							else if(move==4) {vertical++;}
							i=game.length;break;
						}
					}
				}
				hIdx=horizon;
				vIdx=vertical;;
				if(move==5) {
					for(int i=0;i<game.length;i++) {
						for(int j=0;j<game[i].length;) {
							temp[0][0]=game[yx[y-1][0]][yx[y-1][1]];
							game[yx[y-1][0]][yx[y-1][1]]=game[vIdx][hIdx];
							game[vIdx][hIdx]=temp[0][0];
							hIdx=yx[y-1][1];
							vIdx=yx[y-1][0];
							yx[y-1][0]=0;yx[y-1][1]=0;
							i=game.length;
							break;
						}
					}
					y--;
				}
			}
	}

}
