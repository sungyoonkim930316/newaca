package day21;

import java.util.Arrays;
import java.util.Scanner;

public class ����_5��_���� {

	public static void main(String[] args) {

		Scanner s=new Scanner(System.in);

		int size=10;
		int[][] omok={
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
			{0,0,0,0,0,0,0,0,0,0},
		};

		int player=1;
		int win=0;
		
		while(true) {
			System.out.println("==============================");
			for(int i=0;i<size;i++) {
				System.out.println(Arrays.toString(omok[i]));
			}
			System.out.println("==============================");
			if(win==1||win==2) {System.out.printf("[player%d �¸�]\n",win);break;}
			System.out.printf("[player%d�� ��.]\n\n",player);
			System.out.print("x��ǥ�� �Է��ϴ�.");
			int x=s.nextInt();
			System.out.print("y��ǥ�� �Է��ϴ�.");
			int y=s.nextInt();
			System.out.println();
			if(player==1) {
				for(int i=0;i<size;i++) {
					for(int j=0;j<size;j++) {
						if(i==x&&j==y&&omok[i][j]==0) omok[i][j]=1;
					}
				}
			}
			if(player==2) {
				for(int i=0;i<size;i++) {
					for(int j=0;j<size;j++) {
						if(i==x&&j==y&&omok[i][j]==0) omok[i][j]=2;
					}
				}
			}
			player=player==1?2:1;
			
			//���ν�.
			for(int i=0;i<omok.length;i++) {
				for(int j=0;j<omok[i].length;j+=5) {
					if(omok[i][j]==1&&omok[i][j+1]==1&&omok[i][j+2]==1&&omok[i][j+3]==1&&omok[i][j+4]==1) win=1;
					if(omok[i][j]==2&&omok[i][j+1]==2&&omok[i][j+2]==2&&omok[i][j+3]==2&&omok[i][j+4]==2) win=2;
				}
			}
			//���ν�.
			for(int i=0;i<omok.length;i+=5) {
				for(int j=0;j<omok[i].length;j++) {
					if(omok[i][j]==1&&omok[i+1][j]==1&&omok[i+2][j]==1&&omok[i+3][j]==1&&omok[i+4][j]==1) win=1;
					if(omok[i][j]==2&&omok[i+1][j]==2&&omok[i+2][j]==2&&omok[i+3][j]==2&&omok[i+4][j]==2) win=2;
				}
			}
			//��->�쵥���� ��.
			for(int i=0;i<omok.length;i+=5) {
				for(int j=0;j<omok[i].length;j+=5) {
					if(omok[i][j]==1&&omok[i+1][j+1]==1&&omok[i+2][j+2]==1&&omok[i+3][j+3]==1&&omok[i+4][j+4]==1) win=1;
					if(omok[i][j]==2&&omok[i+1][j+1]==2&&omok[i+2][j+2]==2&&omok[i+3][j+3]==2&&omok[i+4][j+4]==2) win=2;
				}
			}
			//��->�´밢�� ��.
			for(int i=0;i<omok.length;i+=5) {
				for(int j=omok[i].length-1;j>0;j-=5) {
					if(omok[i][j]==1&&omok[i+1][j-1]==1&&omok[i+2][j-2]==1&&omok[i+3][j-3]==1&&omok[i+4][j-4]==1) win=1;
					if(omok[i][j]==2&&omok[i+1][j-1]==2&&omok[i+2][j-2]==2&&omok[i+3][j-3]==2&&omok[i+4][j-4]==2) win=2;
				}
			}
		}
		s.close();
		
	}
}
