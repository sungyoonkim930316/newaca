package day23;

import java.util.Arrays;

public class minepractice {

	public static void main(String[] args) {

		/* 
		mine = {0,9,0},
			   {9,0,9},
			   {0,0,9}
				  
		�� mine�迭�� ���� 0�� �ڸ��� ���ڸ� �����ҷ����Ѵ�.
		�����Ҽ��ڴ� �ֺ� 8������ �˻��� 9�� ������ ���������.
				
		��) �Ʒ��� ���� ���  
			   {2,9,2},
			   {9,4,9},
			   {1,3,9}

		 */
//		int size = 3;
//		int[][] mine = {
//			{0,9,0},	
//		    {9,0,9},
//		    {0,0,9}
//		};
//		int cnt=0;
//		int[][] temp=new int[size+2][size+2];
//		int a=0;
//		int b=0;
//		
//		for(int i=0;i<temp.length;i++) {
//			for(int j=0;j<temp[i].length;j++) {
//				if(i>0&&j>0&&i<temp[i].length-1&&j<temp[i].length-1) {
//					temp[i][j]=mine[a][b];
//					b++;
//				}
//			}
//			if(i>0) {a++;b=0;}
//			if(i==3) {a=0;}
//		}
//		
//		for(int i=1;i<temp.length-1;i++) {
//			for(int j=1;j<temp[i].length-1;j++) {
//				int d1=temp[i-1][j-1];
//				int d2=temp[i-1][j];
//				int d3=temp[i-1][j+1];
//				int d4=temp[i][j-1];
//				int d5=temp[i][j+1];
//				int d6=temp[i+1][j-1];
//				int d7=temp[i+1][j];
//				int d8=temp[i+1][j+1];
//				
//				if(temp[i][j]==0) {
//					int[] d={d1,d2,d3,d4,d5,d6,d7,d8};
//					for(int k=0;k<d.length;k++) {
//						if(d[k]==9) {cnt++;}
//					}
//					temp[i][j]=cnt;
//					cnt=0;
//				}
//			}
//		}
//		
//		a=1;
//		b=1;
//		for(int i=0;i<mine.length;i++) {
//			for(int j=0;j<mine[i].length;j++) {
//				mine[i][j]=temp[a][b];
//				b++;
//				if(j==mine[i].length-1) {b=3;break;}
//			}
//			b=1;
//			a++;
//		}
//		
//		for(int i=0;i<mine.length;i++) {
//			for(int j=0;j<mine[i].length;j++) {
//				System.out.print(mine[i][j]+" ");
//			}
//			System.out.println();
//		}
		
//		int size=3;
//		int[][] mine= {
//				{0,9,0},
//				{9,0,9},
//				{0,0,9}
//		};
//		int a=0;
//		int b=0;
//		int cntNine=0;
//		
//		int[][] temp=new int[size+2][size+2];
//		
//		for(int i=0;i<temp.length;i++) {
//			for(int j=0;j<temp[i].length;j++) {
//				if(i>0&&j>0&&i<temp[i].length-1&&j<temp[i].length-1) {
//					temp[i][j]=mine[a][b];
//					b++;
//				}
//			}
//			if(i>0) {a++;b=0;}
//			if(i==3) {a=0;}
//		}
//
//		
//		for(int i=1;i<temp.length-1;i++) {
//			for(int j=1;j<temp[i].length-1;j++) {
//				int d1=temp[i-1][j-1]; // 0 -1
//				int d2=temp[i-1][j];
//				int d3=temp[i-1][j+1];
//				int d4=temp[i][j-1];
//				int d5=temp[i][j+1];
//				int d6=temp[i+1][j-1];
//				int d7=temp[i+1][j];
//				int d8=temp[i+1][j+1];
//				
//				if(temp[i][j]==0) {
//					int[] d={d1,d2,d3,d4,d5,d6,d7,d8};
//					for(int k=0;k<d.length;k++) {
//						if(d[k]==9) {cntNine++;}
//					}
//					temp[i][j]=cntNine;
//					cntNine=0;
//				}
//			}
//		}
//		
//		a=1;
//		b=1;
//		for(int i=0;i<mine.length;i++) {
//			for(int j=0;j<mine[i].length;j++) {
//				mine[i][j]=temp[a][b];
//				b++;
//				if(j==mine[i].length-1) break;
//			}
//			b=1;
//			a++;
//		}
//		
//		for(int i=0;i<mine.length;i++) {
//			System.out.println(Arrays.toString(mine[i]));
//		}
		
		
//		int [][]mine =	{
//				{0,9,0},
//				{9,0,9},
//				{0,0,9}
//		};
//		
//		int[] x={-1,0,1,-1,1,-1,0,1};
//		int[] y={-1,-1,-1,0,0,1,1,1};
//		int k=0;
//		int tx=0 ; 
//		int ty=0;
//		int cnt=0;
//		
//		for(int i=0;i<mine.length;i++) {
//				for(k=0;k<mine[i].length;k++) {
//					int mod=-1;
//					if(mine[i][k]==0) {
//						mod=1;
//					}
//					if(mod==1) {
//						cnt=0;
//					for (int m=0;m< x.length; m++) {
//							 tx=k+x[m];
//							 ty=i+y[m];
//					if(tx>-1&&ty>-1&&tx<mine.length&&ty<mine.length){	
//						if(mine[ty][tx] == 9) {
//							System.out.println(i+" "+k);
//							System.out.println("="+tx+" "+ty);
//							cnt++;
//						}
//					}
//					}	
//						mine[i][k] = cnt;
//				}
//			}
//		}
//		for(int i=0;i<mine.length;i++) {
//			System.out.println(Arrays.toString(mine[i]));
//		}
		
		int[][] mine = {
			{0,9,0},	
		    {9,0,9},
		    {0,0,9}
		};
//		int cnt=0;
//		
//		for(int i=0;i<mine.length;i++) {
//			for(int j=0;j<mine[i].length;j++) {
//				int x=j;
//				int y=i;
//				int[] d=new int[mine.length*mine.length-1];
//				
//				d[0]=y<=0||x<=0?-1:mine[y-1][x-1];
//                d[1]=y<=0?-1:mine[y-1][x];
//                d[2]=y<=0||x>=mine.length-1?-1:mine[y-1][x+1];
//                d[3]=x<=0?-1:mine[y][x-1];
//                d[4]=x>=mine.length-1?-1:mine[y][x+1];
//                d[5]=y>=mine.length-1||x<=0?-1:mine[y+1][x-1];
//                d[6]=y>=mine.length-1?-1:mine[y+1][x];
//                d[7]=y>=mine.length-1||x>=mine.length-1?-1:mine[y+1][x+1];
//				
//				System.out.println(Arrays.toString(d));
//				if(mine[i][j]==0) {
//					for(int k=0;k<d.length;k++) {
//						if(d[k]!=-1) {
//							if(d[k]==9) {
//								cnt++;	
//							}
//						}
//					}
//					mine[i][j]=cnt;
//					cnt=0;
//				}
//			}
//		}
//		
//		for(int i=0;i<mine.length;i++) {
//			System.out.println(Arrays.toString(mine[i]));
//		}
		
//		int size=mine.length;
//		int[][] temp=new int[size+2][size+2];
//		int a=0;
//		int b=0;
//		int cnt=0;
//		
//		for(int i=0;i<temp.length;i++) {
//			for(int j=0;j<temp[i].length;j++) {
//				if(i>0&&j>0&&i<temp.length-1&&j<temp.length-1) {
//					temp[i][j]=mine[a][b];
//					b++;
//				}
//			}
//			if(i>0) {a++;b=0;}
//			if(i==3) {a=0;}
//		}
//		
////		for(int i=0;i<temp.length;i++) {
////			System.out.println(Arrays.toString(temp[i]));
////		}
//		
//		for(int i=1;i<temp.length-1;i++) {
//			for(int j=1;j<temp[i].length-1;j++) {
//				int d1=temp[i-1][j-1];
//				int d2=temp[i-1][j];
//				int d3=temp[i-1][j+1];
//				int d4=temp[i][j-1];
//				int d5=temp[i][j+1];
//				int d6=temp[i+1][j-1];
//				int d7=temp[i+1][j];
//				int d8=temp[i+1][j+1];
//				
//				if(temp[i][j]==0) {
//					int[] d= {d1,d2,d3,d4,d5,d6,d7,d8};
//					for(int k=0;k<d.length;k++) {
//						if(d[k]==9) {
//							cnt++;
//						}
//					}
//					temp[i][j]=cnt;
//					cnt=0;
//				}
//			}
//		}
//		
////		for(int i=0;i<temp.length;i++) {
////			System.out.println(Arrays.toString(temp[i]));
////		}
//		
//		a=1;
//		b=1;
//		for(int i=0;i<mine.length;i++) {
//			for(int j=0;j<mine[i].length;j++) {
//				mine[i][j]=temp[a][b];
//				b++;
//				if(j==mine[i].length-1) {b=3;break;}
//			}
//			b=1;
//			a++;
//		}
//		
//		for(int i=0;i<mine.length;i++) {
//			System.out.println(Arrays.toString(mine[i]));
//		}
		
//		int cnt=0;
//		for(int i=0;i<mine.length;i++) {
//			for(int j=0;j<mine[i].length;j++) {
////				int x=j;
////				int y=i;
////				int[] d=new int[mine.length*mine.length-1];
////				
////				d[0]=y<=0||x<=0?-1:mine[y-1][x-1];
////                d[1]=y<=0?-1:mine[y-1][x];
////                d[2]=y<=0||x>=mine.length-1?-1:mine[y-1][x+1];
////                d[3]=x<=0?-1:mine[y][x-1];
////                d[4]=x>=mine.length-1?-1:mine[y][x+1];
////                d[5]=y>=mine.length-1||x<=0?-1:mine[y+1][x-1];
////                d[6]=y>=mine.length-1?-1:mine[y+1][x];
////                d[7]=y>=mine.length-1||x>=mine.length-1?-1:mine[y+1][x+1];
////				
////				System.out.println(Arrays.toString(d));
////				if(mine[i][j]==0) {
////					for(int k=0;k<d.length;k++) {
////						if(d[k]!=-1) {
////							if(d[k]==9) {
////								cnt++;	
////							}
////						}
////					}
////					mine[i][j]=cnt;
////					cnt=0;
////				}
//				int x=j;
//				int y=i;
//				int[] d=new int[mine.length*mine.length-1];
//				d[0]=y<=0||x<=0?-1:mine[y-1][x-1];
//				d[1]=y<=0?-1:mine[y-1][x];
//				d[2]=y<=0||x>=mine.length-1?-1:mine[y-1][x+1];
//				d[3]=x<=0?-1:mine[y][x-1];
//				d[4]=x>=mine.length-1?-1:mine[y][x+1];
//				d[5]=y>=mine.length-1||x<=0?-1:mine[y+1][x-1];
//				d[6]=y>=mine.length-1?-1:mine[y+1][x];
//				d[7]=y>=mine.length-1||x>=mine.length-1?-1:mine[y+1][x+1];
//				
//				if(mine[i][j]==0) {
//					for(int k=0;k<d.length;k++) {
//						if(d[k]!=-1) {
//							if(d[k]==9) {
//								cnt++;
//							}
//						}
//					}
//					mine[i][j]=cnt;
//					cnt=0;
//				}
//			}
//		}
//		
//		for(int i=0;i<mine.length;i++) {
//			System.out.println(Arrays.toString(mine[i]));
//		}
		
//		int cnt=0;
//		
//		for(int i=0;i<mine.length;i++) {
//			for(int j=0;j<mine[i].length;j++) {
//				
//				int y=i;
//				int x=j;
//				int[] d=new int[mine.length*mine.length-1];
//				
//				d[0]=y<=0||x<=0?-1:mine[y-1][x-1];
//				d[1]=y<=0?-1:mine[y-1][x];
//				d[2]=y<=0||x>=mine.length-1?-1:mine[y-1][x+1];
//				d[3]=x<=0?-1:mine[y][x-1];
//				d[4]=x>=mine.length-1?-1:mine[y][x+1];
//				d[5]=y>=mine.length-1||x<=0?-1:mine[y+1][x-1];
//				d[6]=y>=mine.length-1?-1:mine[y+1][x];
//				d[7]=y>=mine.length-1||x>=mine.length-1?-1:mine[y+1][x+1];
//				
////				System.out.println(Arrays.toString(d));
//				if(mine[i][j]==0) {
//					for(int k=0;k<d.length;k++) {
//						if(d[k]!=-1) {
//							if(d[k]==9) {
//								cnt++;
//							}
//						}
//					}
//					mine[i][j]=cnt;
//					cnt=0;
//				}
//			}
//		}
//		
//		for(int i=0;i<mine.length;i++) {
//			System.out.println(Arrays.toString(mine[i]));
//		}
//		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
	}

}
