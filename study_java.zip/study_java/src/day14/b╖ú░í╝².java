package day14;

import java.util.Random;
import java.util.Scanner;

public class b������ {

	public static void main(String[] args) {

		Random r=new Random();
		Scanner s=new Scanner(System.in);
		
		int a=r.nextInt(200)+101;
		System.out.println(a);
		System.out.print("������ �Է��ϴ�.");
		int x=s.nextInt();
		
		boolean err=x<0||x>9;
		if(!err) {
			a=a%100/10;
			if(x==a)System.out.println("����");
			else {System.out.println("���� : "+a);System.out.println("����");}
		} else {System.err.println("err");}
		s.close();
		
	}

}
