package day14;

import java.util.Random;
import java.util.Scanner;

public class c������ {

	public static void main(String[] args) {

		
		
		Random rd = new Random();
		int cnt = 0;
		int a=0;
		int temp = 0;
		int max = 0;
		for(int i = 0 ; i < 10 ; i++) {
			
			temp = a;
			System.out.print(a = rd.nextInt(8)+1);
			
			if(temp < a &&temp!=0 && temp != a) {
				
				cnt++;
				
			}else {
				cnt = 0;
			}
	
			if(max < cnt) {
				max = cnt;
			}
			
			
			System.out.print("  ");
			
			
			
			}
			
		System.out.println(">>>>>>>>>"+ max);
		
	}

}
