package day14;

import java.util.Random;
import java.util.Scanner;

public class j������ {

	public static void main(String[] args) {

		
		Random r=new Random();
		Scanner s=new Scanner(System.in);
		
		int a=r.nextInt(142)+159;
		System.out.println(a);
		System.out.print("��� ���ڸ� ���纸����");
		int x=s.nextInt();
		
		boolean err=x>9||x<0;
		if(!err) {
			
		}
		else {System.err.println("err");}
	}

}
