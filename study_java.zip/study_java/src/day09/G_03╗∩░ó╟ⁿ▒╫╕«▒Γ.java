package day09;

public class G_03�ﰢ���׸��� {

	public static void main(String[] args) {
		
		/*
		 * 		(1,0)(1,1)(1,2)
		 * 		(2,0)(2,1)(2,2)
		 * 		(3,0)(3,1)(3,2)
		 * */

		/*
		 * ���� 1)
		 * #
		 * ##
		 * ###
		 */
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(j>i) {
					System.out.print(" ");
				} else {System.out.print("#");}
			}
			System.out.println();
		}
		System.out.println("======");

		/*
		 * ���� 2)
		 * ###
		 * ##
		 * #
		 * 
		 */
		
		for(int i=3;i>=1;i--) {
			for(int j=0;j<=3;j++) {
				if(j<i) {
					System.out.print("#");
				} else {System.out.print(" ");}
			}
			System.out.println();
		}
		System.out.println("======");

		/*
		 * ���� 3)
		 * @##
		 * @@#
		 * @@@
		 */
		
		for(int i=0;i<3;i++) {
			for(int j=0;j<3;j++) {
				if(j>i) {
					System.out.print("#");
				} else {System.out.print("@");}
			}
			System.out.println();
		}
		System.out.println("======");

		/*
		 * ���� 4)
		 *   #
		 *  ###
		 * #####
		 */
		
		for(int i=0;i<3;i++) {
			for(int j=2;j>=0;j--) {
				if(j>i) {
					System.out.print(" ");
				} else {System.out.print("#");}
			} for(int k=0;k<3;k++) {
				if(k<i) {
					System.out.print("#");
				} else {System.out.print(" ");}
			} 
			System.out.println();
		}
		System.out.println("======");
		
		
	}

}
