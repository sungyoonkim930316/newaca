package day24;

import java.util.Arrays;
import java.util.Random;
import java.util.Scanner;

public class �渶 {

	public static void main(String[] args) {

		/*
		 [�渶 ����]
		 [1] 5 * 20 �� �迭�� �ִ�.
		 [2] �� ���� ���� �޸� Ʈ���� �ǹ��Ѵ�.
		 [3] �� �ϴ� �������� 1~4ĭ�� �Ÿ��� �̵��Ҽ��ִ�.
		 [4] ���� ���� �����ϸ� ������ ������. �������� ������ ����Ѵ�. 
		 [5] ��, ���� ���ÿ� �����ϸ� ����� ����. 
		 */

		Random r=new Random();
		Scanner s=new Scanner(System.in);
		int horse[][] = new int[5][20];
		int breaker=0;
		int cnt=0;
		int rank=0;
		
		int[] ranking=new int[horse.length];
		
		while(true) {
			int num=0;
			for(int i=0;i<horse.length;i++) {
				for(int j=0;j<horse[i].length;j++) {
					if(horse[i][j]!=0) {
						System.out.print("[��]");
					}
					else {System.out.print("[ ]");}
				}System.out.println();
			}System.out.println();
			
			System.out.print("���͸� ������ test");
			String t=s.nextLine();
			int[] move=new int[horse.length];
			for(int i=0;i<move.length;i++) {
				int elements=r.nextInt(5)+1;
				move[i]=elements;
			}
			System.out.println(Arrays.toString(move));
			
			if(breaker==0) {
				for(int i=0;i<horse.length;i++) {
					for(int j=0;j<horse[i].length;j++) {
						if(j==move[num]-1) {horse[i][j]=1;num++;break;}
					}
				}
				breaker=1;continue;
			}
			
			for(int i=0;i<horse.length;i++) {
				for(int j=0;j<horse[i].length;j++) {
					if(horse[i][j]==1&&j==horse[i].length-1) {
						System.out.printf("[num = %d]\n",num);
						num++;
						break;
					}
					else if(horse[i][j]==1&&j!=horse[i].length-1) {
						horse[i][j]=0;
						if(j+move[num]>horse[i].length-1) {j=horse[i].length-1;}
						else {j+=move[num];}
						horse[i][j]=1;
						if(j==horse[i].length-1) {System.out.println((num+1)+"�� ����.");ranking[rank]=num+1;rank++;cnt++;}
						System.out.printf("[num = %d]\n",num);
						num++;
						break;
					}
				}
			}
			if(cnt==5) {break;}
		}
		
		for(int i=0;i<horse.length;i++) {
			for(int j=0;j<horse[i].length;j++) {
				if(horse[i][j]!=0) {
					System.out.print("[��]");
				}
				else {System.out.print("[ ]");}
			}System.out.println();
		}System.out.println();
		
		
		for(int i=0;i<ranking.length;i++) {
			System.out.println((i+1)+"�� : "+ranking[i]+"�� ����");
		}
		
		//�ߺ� ����� �ƹ��� �����ص� ���ϰڽ��ϴ�
		
		
//		Random r=new Random();
//		Scanner s=new Scanner(System.in);
//		int horse[][] = new int[5][20];
//		int temp[][] = new int[5][20];
//		int[] ranking=new int[horse.length];
//		
//		int[] breaker=new int[5];
//		
//		int tVal=0;
//		int controler=0;
//		int sum=0;
//		
//		int lx=0;
//		int ly=0;
//		
//		while(true) {
////			for(int i=0;i<horse.length;i++) {
////				for(int j=0;j<horse[i].length;j++) {
////					if(horse[i][j]!=0) {System.out.print("[��]");}
////					else {System.out.print("[ ]");}
////				}System.out.println();
////			}System.out.println();
//			
//			System.out.print("���͸� ������ test");
//			String t=s.nextLine();
//			int[] move=new int[horse.length];
//			for(int i=0;i<move.length;i++) {
//				int elements=r.nextInt(5)+1;
//				move[i]=elements;
//			}
//			System.out.println(Arrays.toString(move));
//			
//			for(int i=0;i<temp.length;i++) {
//				temp[i][tVal]=move[i];
//				for(int j=0;j<tVal+1;j++) {
//					sum+=temp[i][j];
//				}
////				System.out.println(sum);
//				if(tVal>0&&sum>horse[i].length-1) {
//					for(int j=0;j<tVal;j++) {
//						controler+=temp[i][j];
//					}
//					temp[i][tVal]=horse[i].length-1-controler;
//					controler=0;
//				}
////				System.out.println(controler);
//				for(int j=0;j<temp[i].length;j++) {
//					System.out.print(temp[i][j]+" ");
//				}
//				System.out.print(" sum : "+sum);
//				System.out.println();
//				sum=0;
//			}
//			
//			
//			for(int i=0;i<horse.length;i++) {
//				for(int j=0;j<horse[i].length;j++) {
//					for(int k=0;k<tVal+1;k++) {
//						sum+=temp[i][k];
//					}
////					System.out.println(sum);
//					if(tVal>0&&j==temp[i][tVal-1]-1) {
//						horse[i][j]=0;
//					}
//					j=sum;
//					horse[i][j]=1;
//					if(horse[i][j]!=0) {System.out.print("[��]");}
//					else {System.out.print("[ ]");}
//					sum=0;
//				}
//				System.out.println();
//			}System.out.println();
//			tVal++;
//		}
		

		
		
		
	}

}
