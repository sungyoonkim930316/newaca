package day08;

import java.util.Scanner;

public class D_02�Ϲٲٱ� {

	public static void main(String[] args) {

		Scanner s=new Scanner(System.in);
		int cnt=0;
		boolean turn=true;
		while(cnt>10) {
			if(turn) {
				System.out.println("p1��");
			} else {System.out.println("p2��");}
		}
		turn=!turn;
		cnt++;
		
		s.close();
	}

}
