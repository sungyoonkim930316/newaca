package day10;

import java.util.Arrays;

public class G_06���� {

	public static void main(String[] args) {

		/*
		 * # ���� ���
		 * . ���� ������ �̸� ���
		 */

		String[] name = {"������", "��ȫö", "���缮", "�ڸ���", "����"};
		int[] score   = {    87,    42,    100,     11,     98};
		
		for(int i=0;i<score.length;i++) {
			int maxIdx=i;
			int max=score[i];
			for(int j=i;j<score.length;j++) {
				if(max<score[j]) {
					maxIdx=j;
					max=score[j];
				}
			}
			if(i!=maxIdx) {
				int temp1=score[i];
				score[i]=score[maxIdx];
				score[maxIdx]=temp1;
				String temp2=name[i];
				name[i]=name[maxIdx];
				name[maxIdx]=temp2;
			}
		}
		System.out.println(Arrays.toString(name));
		System.out.println(Arrays.toString(score));
		
//		for(int i=0;i<score.length;i++) {
//			for(int j=i;j<score.length;j++) {
//				if(score[i]<score[j]) {
//					int temp1=score[i];
//					score[i]=score[j];
//					score[j]=temp1;
//					String temp2=name[i];
//					name[i]=name[j];
//					name[j]=temp2;
//				}
//			}
//		}
//		System.out.println(Arrays.toString(name));
//		System.out.println(Arrays.toString(score));
		
	}

}
