package day18;

import java.util.Arrays;

public class test {

	public static void main(String[] args) {

		int test[] = {1,2,3,2,1} ;				
		int temp[] = new int[5];
		
		for(int i=0;i<test.length;i++) {
			for(int j=i+1;j<test.length;j++) {
				if(test[i]==test[j]) {temp[i]=test[i];temp[j]=test[j];System.out.printf("[i = %d][j = %d]\n",i,j);}
			}
		}
		
		int a=0;
		int[] ans=null;
		
		for(int i=0;i<temp.length;i++) {
			a=ans==null?0:ans.length;
			if(temp[i]!=0) {
				if(ans==null) {ans=new int[1];}
				else {
					int[] temp2=new int[a+1];
					for(int j=0;j<a;j++) {temp2[j]=ans[j];}
					ans=temp2;
					temp2=null;
				}
				ans[a]=temp[i];
			}
		}
		System.out.println(Arrays.toString(ans));
		
	}

}
