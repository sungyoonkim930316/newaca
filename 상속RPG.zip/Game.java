package 상속RPG;

import java.util.Scanner;

public class Game {

	Scanner sc = new Scanner(System.in);
	
	final int BOSS = 9;
	final int MONSTER =8;
	final int SIZE = 10;
	
	int map[];
	Player player;
	int px;
	void init() {
		map = new int[SIZE];
		player= new Player(100, 10, "전사");
		map[3] = MONSTER;
		map[5] = MONSTER;
		map[7] = MONSTER;
		map[SIZE-1] = BOSS;
	}
	
	void printGameMap() {
		for(int game : map) {
			if(game == px) {
				System.out.println("[옷]");
			}
			else if(game == 0) {
				System.out.print("[ ]");
			}else if(game == MONSTER) {
				System.out.print("[M]");
			}else {
				System.out.print("[B]");
			}
		}
	}
	
	void movePlayer() {
		
	}
	void mainMenu() {
		System.out.println("[0]종료[1]한칸이동[2]체력회복");
	}
	void battleMonster() {
		System.out.println("========= [ 전투 ]==========");
		boolean turn = false;
		if(turn) {
			System.out.println("[플레이어 차례]");
			System.out.println("[1]공격 [2]스킬");
		}else {
			System.out.println("[몬스터 차례]");
		}
	}
	
	void run() {
		init();
		printGameMap();
	}
	
	
}
