package 상속RPG;

public class _Main {

}
